extends Node
# Loading screen: checks every script, builds the world in stages and shows progress.
const SCRIPTS := ["cfg", "shaders", "models", "story", "city", "shops", "vehicle", "ped", "player", "hud", "main"]
const TIPS := [
	"Tap the phone icon to call a mechanic, order a helicopter or erase your wanted level.",
	"Walk into the glowing door markers to shop for guns, clothes, food, cars and apartments.",
	"Lose the cops by hiding out of sight for a while, or drive into Pay and Spray.",
	"Stay out of the military base unless you want a very bad day.",
	"Tanks sit inside Fort Harbor. Helicopters can be bought on the phone.",
	"Traffic lights are real. Running red lights with cops around is a bad idea.",
	"Set a GPS waypoint on the phone map and follow the yellow arrow.",
	"Sleep in your apartment to save the game and skip to morning.",
	"Upgrade your brakes and engine at the Auto Mods garage.",
]

var layer: CanvasLayer
var screen: Control
var prog := 0.0
var shown := 0.0
var status := "Starting..."
var err := ""
var t := 0.0
var last_change := 0.0
var done := false
var tip_i := 0
var main_node: Node = null
var buildings: Array = []
var stars: Array = []

func _ready() -> void:
	randomize()
	layer = CanvasLayer.new()
	layer.layer = 100
	add_child(layer)
	screen = Control.new()
	screen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen.draw.connect(_draw_screen)
	layer.add_child(screen)
	tip_i = randi() % TIPS.size()
	var x := 0.0
	while x < 1.0:
		var w := randf_range(0.02, 0.06)
		buildings.append([x, w, randf_range(0.08, 0.34), randi() % 1000])
		x += w + randf_range(0.0, 0.012)
	for i in range(70):
		stars.append(Vector3(randf(), randf() * 0.5, randf_range(0.6, 2.0)))
	await get_tree().process_frame
	await get_tree().process_frame
	await _boot()

func _on_progress(p: float, text: String) -> void:
	prog = p
	status = text
	last_change = t

func _boot() -> void:
	status = "Checking game files..."
	last_change = t
	await get_tree().process_frame
	var loaded := {}
	for s in SCRIPTS:
		var path = "res://scripts/%s.gd" % s
		var res = load(path)
		if res == null or not (res is GDScript) or not res.can_instantiate():
			err = "Script error in scripts/" + s + ".gd"
			return
		loaded[s] = res
		prog = 0.01 + 0.01 * SCRIPTS.find(s)
		await get_tree().process_frame
	var ms: GDScript = loaded["main"]
	main_node = ms.new()
	add_child(main_node)
	await main_node.build_world(Callable(self, "_on_progress"))
	done = true
	status = "Ready"

func _process(delta: float) -> void:
	t += delta
	screen.position = Vector2.ZERO
	screen.size = get_viewport().get_visible_rect().size
	shown = move_toward(shown, prog, delta * 0.6)
	if int(t / 5.0) != int((t - delta) / 5.0):
		tip_i = (tip_i + 1) % TIPS.size()
	if done and shown >= 0.99:
		screen.modulate.a = maxf(0.0, screen.modulate.a - delta * 1.6)
		if screen.modulate.a <= 0.0:
			layer.queue_free()
			set_process(false)
			return
	screen.queue_redraw()

func _draw_screen() -> void:
	var s := screen.size
	var u := maxf(0.5, s.y / 720.0)
	var font := ThemeDB.fallback_font
	# sunset sky
	var top := Color(0.05, 0.05, 0.14)
	var mid := Color(0.55, 0.22, 0.28)
	var bot := Color(0.98, 0.55, 0.25)
	var hy := s.y * 0.72
	screen.draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(s.x, 0), Vector2(s.x, hy * 0.6), Vector2(0, hy * 0.6)]), PackedColorArray([top, top, mid, mid]))
	screen.draw_polygon(PackedVector2Array([Vector2(0, hy * 0.6), Vector2(s.x, hy * 0.6), Vector2(s.x, hy), Vector2(0, hy)]), PackedColorArray([mid, mid, bot, bot]))
	for st in stars:
		screen.draw_circle(Vector2(st.x * s.x, st.y * hy * 0.6), st.z * u, Color(1, 1, 1, 0.5 + 0.4 * sin(t * 2.0 + st.x * 20.0)))
	screen.draw_circle(Vector2(s.x * 0.74, hy - 40 * u), 110 * u, Color(1.0, 0.8, 0.45, 0.9))
	# skyline
	for b in buildings:
		var bx: float = float(b[0]) * s.x
		var bw: float = float(b[1]) * s.x
		var bh: float = float(b[2]) * s.y
		screen.draw_rect(Rect2(bx, hy - bh, bw, bh), Color(0.06, 0.06, 0.1))
		var seed_i: int = int(b[3])
		for wy in range(int(bh / (14 * u))):
			for wx in range(maxi(1, int(bw / (10 * u)))):
				if ((seed_i + wy * 7 + wx * 13) % 5) < 2:
					screen.draw_rect(Rect2(bx + 4 * u + wx * 10 * u, hy - bh + 6 * u + wy * 14 * u, 4 * u, 6 * u), Color(1.0, 0.85, 0.5, 0.75))
	# road and moving car
	screen.draw_rect(Rect2(0, hy, s.x, s.y - hy), Color(0.05, 0.05, 0.07))
	screen.draw_rect(Rect2(0, hy + (s.y - hy) * 0.5, s.x, 3 * u), Color(0.9, 0.7, 0.1, 0.8))
	var cx := fposmod(t * 160.0 * u, s.x + 300 * u) - 150 * u
	var cy := hy + (s.y - hy) * 0.28
	screen.draw_rect(Rect2(cx, cy - 26 * u, 110 * u, 22 * u), Color(0.75, 0.05, 0.08))
	screen.draw_rect(Rect2(cx + 26 * u, cy - 44 * u, 56 * u, 20 * u), Color(0.5, 0.04, 0.06))
	screen.draw_rect(Rect2(cx + 32 * u, cy - 40 * u, 44 * u, 14 * u), Color(0.1, 0.14, 0.2))
	screen.draw_circle(Vector2(cx + 24 * u, cy - 2 * u), 12 * u, Color(0.02, 0.02, 0.02))
	screen.draw_circle(Vector2(cx + 88 * u, cy - 2 * u), 12 * u, Color(0.02, 0.02, 0.02))
	screen.draw_polygon(PackedVector2Array([Vector2(cx + 110 * u, cy - 18 * u), Vector2(cx + 300 * u, cy - 50 * u), Vector2(cx + 300 * u, cy + 20 * u)]), PackedColorArray([Color(1, 0.95, 0.7, 0.35), Color(1, 0.95, 0.7, 0.0), Color(1, 0.95, 0.7, 0.0)]))
	# title
	screen.draw_string_outline(font, Vector2(40 * u, 110 * u), "IRON HARBOR", HORIZONTAL_ALIGNMENT_LEFT, -1, int(88 * u), int(10 * u), Color(0, 0, 0, 0.9))
	screen.draw_string(font, Vector2(40 * u, 110 * u), "IRON HARBOR", HORIZONTAL_ALIGNMENT_LEFT, -1, int(88 * u), Color(1.0, 0.8, 0.2))
	screen.draw_string(font, Vector2(46 * u, 150 * u), "Harbor City - the debt comes due", HORIZONTAL_ALIGNMENT_LEFT, -1, int(26 * u), Color(1, 1, 1, 0.9))
	# progress + status + tip
	var bw2 := s.x - 80 * u
	var by := s.y - 90 * u
	screen.draw_rect(Rect2(40 * u, by, bw2, 10 * u), Color(0, 0, 0, 0.6))
	screen.draw_rect(Rect2(40 * u, by, bw2 * clampf(shown, 0.0, 1.0), 10 * u), Color(1.0, 0.8, 0.2))
	screen.draw_string(font, Vector2(40 * u, by - 14 * u), status, HORIZONTAL_ALIGNMENT_LEFT, -1, int(24 * u), Color(1, 1, 1))
	screen.draw_string(font, Vector2(40 * u, by - 14 * u), str(int(shown * 100.0)) + "%", HORIZONTAL_ALIGNMENT_RIGHT, bw2, int(24 * u), Color(1, 0.8, 0.2))
	screen.draw_string(font, Vector2(40 * u, s.y - 40 * u), "TIP: " + TIPS[tip_i], HORIZONTAL_ALIGNMENT_LEFT, bw2, int(20 * u), Color(0.9, 0.9, 1.0, 0.9))
	# error / stall report
	var msg := err
	if msg == "" and not done and t - last_change > 20.0:
		msg = "Loading seems stuck at: " + status
	if msg != "":
		var r := Rect2(s.x * 0.1, s.y * 0.3, s.x * 0.8, 150 * u)
		screen.draw_rect(r, Color(0.35, 0.02, 0.02, 0.95))
		screen.draw_rect(r, Color(1, 0.3, 0.3), false, 3 * u)
		screen.draw_string(font, r.position + Vector2(20 * u, 50 * u), "COULD NOT START THE GAME", HORIZONTAL_ALIGNMENT_LEFT, -1, int(30 * u), Color(1, 0.8, 0.8))
		screen.draw_string(font, r.position + Vector2(20 * u, 95 * u), msg, HORIZONTAL_ALIGNMENT_LEFT, r.size.x - 40 * u, int(24 * u), Color(1, 1, 1))
		screen.draw_string(font, r.position + Vector2(20 * u, 132 * u), "Send a screenshot of this to the developer.", HORIZONTAL_ALIGNMENT_LEFT, r.size.x - 40 * u, int(20 * u), Color(1, 0.85, 0.85))
