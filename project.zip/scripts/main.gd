extends Node3D
# IRON HARBOR - main game: city, day/night, traffic, police, missions, shops, phone, camera.
const Cfg = preload("res://scripts/cfg.gd")
const Sh = preload("res://scripts/shaders.gd")
const Models = preload("res://scripts/models.gd")
const Story = preload("res://scripts/story.gd")
const City = preload("res://scripts/city.gd")
const Shops = preload("res://scripts/shops.gd")
const VehicleS = preload("res://scripts/vehicle.gd")
const PedS = preload("res://scripts/ped.gd")
const PlayerS = preload("res://scripts/player.gd")
const HudS = preload("res://scripts/hud.gd")

var player
var cur_car = null
var cam: Camera3D
var sun: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var hud
var time_h := 17.0
var vehicles: Array = []
var peds: Array = []
var money := 800
var heat := 0.0
var wanted := 0
var cop_seen_t := 99.0
var busted_t := 0.0
var chapter := 0
var quality_mode := 0
var quality := 2
var fps_t := 0.0
var cam_yaw := 0.0
var cam_pitch := 0.3
var look_idle := 5.0
var mat_build: ShaderMaterial
var mat_ground: ShaderMaterial
var mat_water: ShaderMaterial
var mat_neon: ShaderMaterial
var mat_sig: ShaderMaterial
var lamp_mat: StandardMaterial3D
var world_body: StaticBody3D
var sig_mm: MultiMeshInstance3D
var sig_axis: Array = []
var sig_last := Vector2i(-1, -1)
var weapons_owned := [true, false, false, false, false]
var weapon := 0
var fire_cd := 0.0
var game_t := 0.0
var shake := 0.0
var dead_t := -1.0
var engine_p: AudioStreamPlayer
var heli_p: AudioStreamPlayer
var siren_p: AudioStreamPlayer
var police_cd := 2.0
var traffic_cd := 1.0
var block_cd := 20.0
var heli_cd := 10.0
var env_t := 0.0
var save_t := 0.0
var last_hurt_t := 0.0
var night_v := 0.0
var base_rect := Rect2()
var base_gate := Vector3.ZERO
var base_alarm := 0.0
var shots: Array = []
# economy / world state
var owned: Array = []
var owned_outfits: Array = [0]
var properties: Array = []
var home_idx := -1
var waypoint := Vector3.ZERO
var waypoint_on := false
var in_interior := -1
var interiors := {}
var door_cd := 0.0
var mod_cd := 0.0
var pns_cd := 0.0
var mod_pos := Vector3.ZERO
var pns_pos := Vector3.ZERO
var prompt := ""
var menu_ctx := ""
var menu_stack: Array = []
var http: HTTPRequest
# mission state
var m_active := false
var m_def := {}
var m_step := 0
var m_cars: Array = []
var m_car = null
var m_targets: Array = []
var m_wanted_set := false
var m_step_t := 0.0
var m_title := ""
var m_text := ""
var m_race_i := 0
var m_race_t := 0.0
var m_lost_t := 0.0
var start_arm := 3.0
var marker: MeshInstance3D
var marker_pos := Vector3.ZERO
var marker_on := false
var marker_col := Color(1, 0.8, 0.1)
var story_done := false
var courier_def := {}

# ================================================================ setup
var ready_ok := false
var rep: Callable = Callable()

func prog(p: float, text: String) -> void:
	if rep.is_valid():
		rep.call(p, text)

func build_world(report: Callable) -> void:
	rep = report
	prog(0.02, "Setting up the sky...")
	await get_tree().process_frame
	randomize()
	Engine.max_fps = 60
	get_viewport().msaa_3d = Viewport.MSAA_DISABLED
	setup_env()
	prog(0.06, "Pouring the streets...")
	await get_tree().process_frame
	await City.build(self)
	prog(0.64, "Casting the characters...")
	await get_tree().process_frame
	cam = Camera3D.new()
	cam.far = 460.0
	cam.near = 0.12
	cam.fov = 68.0
	add_child(cam)
	cam.current = true
	player = PlayerS.new()
	add_child(player)
	player.setup(self)
	player.global_position = Cfg.ic(0, 0)
	cam_yaw = 0.0
	var layer := CanvasLayer.new()
	layer.layer = 5
	add_child(layer)
	hud = HudS.new()
	hud.main = self
	hud.title_t = 0.0
	layer.add_child(hud)
	prog(0.7, "Tuning engines and sirens...")
	await get_tree().process_frame
	make_audio()
	make_marker()
	make_world_markers()
	load_game()
	prog(0.74, "Parking the cars...")
	await get_tree().process_frame
	spawn_parked(18)
	prog(0.8, "Filling the roads with traffic...")
	await get_tree().process_frame
	for i in range(18):
		spawn_ai("ai")
		if i % 6 == 5:
			await get_tree().process_frame
	prog(0.9, "Waking up the city...")
	await get_tree().process_frame
	for i in range(30):
		spawn_ped()
		if i % 10 == 9:
			await get_tree().process_frame
	spawn_base_units()
	apply_quality(2)
	update_env(true)
	prog(0.97, "Checking for updates...")
	await get_tree().process_frame
	check_update()
	ready_ok = true
	prog(1.0, "Welcome to Iron Harbor")

func setup_env() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_curve = 0.12
	sky_mat.ground_curve = 0.05
	sky_mat.sun_angle_max = 25.0
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.6, 0.68, 0.8)
	env.ambient_light_energy = 1.0
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.0
	env.fog_enabled = true
	env.fog_density = 0.0018
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.08
	env.adjustment_saturation = 1.12
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 90.0
	sun.shadow_bias = 0.06
	add_child(sun)

func mm_inst(mesh: Mesh, mat: Material, xf: Array, cols: Array, shadow := true) -> MultiMeshInstance3D:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = cols.size() > 0
	mm.mesh = mesh
	mm.instance_count = xf.size()
	for i in range(xf.size()):
		mm.set_instance_transform(i, xf[i])
		if cols.size() > 0:
			mm.set_instance_color(i, cols[i])
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = mat
	if not shadow:
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	return mi

func mat_sig_lights() -> ShaderMaterial:
	mat_sig = ShaderMaterial.new()
	mat_sig.shader = Sh.get_shader("lights")
	mat_sig.set_shader_parameter("glow", 2.0)
	return mat_sig

func make_disc(pos: Vector3, radius: float, col: Color, text := "") -> void:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = 0.06
	mi.mesh = cm
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mt.albedo_color = Color(col.r, col.g, col.b, 0.55)
	mi.material_override = mt
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.position = pos + Vector3(0, 0.08, 0)
	add_child(mi)
	if text != "":
		var l := Label3D.new()
		l.text = text
		l.pixel_size = 0.03
		l.font_size = 48
		l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		l.modulate = col.lightened(0.4)
		l.outline_size = 8
		l.position = pos + Vector3(0, 3.2, 0)
		add_child(l)

func make_world_markers() -> void:
	for i in range(Cfg.SHOPS.size()):
		var s: Dictionary = Cfg.SHOPS[i]
		make_disc(Cfg.shop_door(i), 1.4, s["col"].lightened(0.3), "")
	mod_pos = Cfg.nd(3, -1) + Vector3(0, 0, 24)
	pns_pos = Cfg.nd(-3, 3) + Vector3(0, 0, 24)
	make_disc(mod_pos, 4.5, Color(1.0, 0.55, 0.1), "AUTO MODS")
	make_disc(pns_pos, 4.5, Color(0.2, 0.9, 0.4), "PAY AND SPRAY")

func spawn_base_units() -> void:
	var c := base_rect.get_center()
	spawn_vehicle(10, Color(1, 1, 1), "parked", Vector3(c.x - 10, 0, c.y + 8), 0.2)
	spawn_vehicle(10, Color(1, 1, 1), "parked", Vector3(c.x + 10, 0, c.y + 8), -0.2)
	spawn_vehicle(2, Color(0.25, 0.3, 0.18), "parked", Vector3(c.x - 22, 0, c.y - 10), 1.57)
	spawn_vehicle(2, Color(0.25, 0.3, 0.18), "parked", Vector3(c.x + 22, 0, c.y - 10), -1.57)
	for i in range(6):
		var p = spawn_ped(Vector3(c.x + randf_range(-24, 24), 0, c.y + randf_range(-18, 12)), "soldier")
		p.idle = true

# ================================================================ audio
func make_audio() -> void:
	engine_p = AudioStreamPlayer.new()
	engine_p.stream = Models.sound("engine")
	engine_p.volume_db = -12.0
	add_child(engine_p)
	heli_p = AudioStreamPlayer.new()
	heli_p.stream = Models.sound("heli")
	heli_p.volume_db = -6.0
	add_child(heli_p)
	siren_p = AudioStreamPlayer.new()
	siren_p.stream = Models.sound("siren")
	siren_p.volume_db = -80.0
	add_child(siren_p)
	siren_p.play()

func sfx(sname: String, vol := -4.0, pitch := 1.0) -> void:
	var p := AudioStreamPlayer.new()
	p.stream = Models.sound(sname)
	p.volume_db = vol
	p.pitch_scale = pitch * randf_range(0.93, 1.07)
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()

# ================================================================ spawning
func spawn_vehicle(kind: int, col: Color, md: String, pos: Vector3, yaw: float):
	var v = VehicleS.new()
	add_child(v)
	v.setup(self, kind, col, md)
	v.global_position = pos
	v.rotation.y = yaw
	vehicles.append(v)
	return v

func rand_car_color() -> Color:
	var pal := [Color(0.85, 0.85, 0.87), Color(0.08, 0.08, 0.1), Color(0.5, 0.5, 0.55), Color(0.6, 0.08, 0.08), Color(0.1, 0.25, 0.5), Color(0.9, 0.75, 0.1), Color(0.15, 0.4, 0.25), Color(0.7, 0.4, 0.15), Color(0.4, 0.1, 0.45)]
	return pal[randi() % pal.size()]

func rand_traffic_kind() -> int:
	var r := randf()
	if r < 0.30: return 0
	if r < 0.45: return 2
	if r < 0.52: return 3
	if r < 0.62: return 5
	if r < 0.72: return 6
	if r < 0.80: return 1
	if r < 0.86: return 7
	return 0

func spawn_parked(n: int) -> void:
	for i in range(n):
		var line := randi_range(-Cfg.GRID, Cfg.GRID)
		var t := randf_range(-300.0, 300.0)
		if absf(fposmod(t + Cfg.P * 0.5, Cfg.P) - Cfg.P * 0.5) < 18.0:
			continue
		var side := 6.4 if randf() < 0.5 else -6.4
		var pos := Vector3(line * Cfg.P + side, 0, t)
		var yaw := 0.0
		if randf() < 0.5:
			pos = Vector3(t, 0, line * Cfg.P + side)
			yaw = PI * 0.5
		if pos.distance_to(Cfg.ic(0, 0)) < 15.0:
			continue
		var k := rand_traffic_kind()
		if k == 7:
			k = 6
		spawn_vehicle(k, rand_car_color(), "parked", pos, yaw + (0.0 if randf() < 0.5 else PI))

func spawn_ai(md: String, near_player := false):
	var dirs := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	var pp: Vector3 = player_pos()
	for attempt in range(16):
		var n := Vector2i(randi_range(-Cfg.GRID, Cfg.GRID), randi_range(-Cfg.GRID, Cfg.GRID))
		var d: Vector2i = dirs[randi() % 4]
		var prev := n - d
		if not Cfg.inb(prev):
			continue
		var dv := Vector2(d)
		var p2 := Vector2(prev) * Cfg.P + dv * Cfg.P * randf_range(0.25, 0.75) + Cfg.lane_off(dv)
		var wp := Vector3(p2.x, 0, p2.y)
		var dist := wp.distance_to(pp)
		if near_player:
			if dist < 80.0 or dist > 150.0:
				continue
		elif dist < 45.0 or dist > 280.0:
			continue
		var kind := rand_traffic_kind()
		var col := rand_car_color()
		if md == "police":
			kind = 0
			col = Color(0.92, 0.92, 0.95)
		elif md == "tank":
			kind = 10
			col = Color(1, 1, 1)
		var vmode := md if (md == "police" or md == "ai") else "police"
		var v = spawn_vehicle(kind, col, vmode, wp, Cfg.yaw_of(dv))
		v.dirv = dv
		v.node = n
		v.choose_next()
		if md == "police" or md == "tank":
			v.make_police()
		return v
	return null

func spawn_ped(pos := Vector3.ZERO, kind := "civ"):
	var p = PedS.new()
	add_child(p)
	p.setup(self, kind, pos)
	peds.append(p)
	return p

func spawn_heli(kind: int, md: String, pos: Vector3):
	var col := Color(0.08, 0.1, 0.22) if kind == 21 else Color(0.7, 0.05, 0.05)
	if md == "parked":
		col = Color(0.9, 0.9, 0.92)
	var v = spawn_vehicle(kind, col, md, pos, randf() * TAU)
	return v

# ================================================================ helpers used by other scripts
func player_pos() -> Vector3:
	if cur_car != null and is_instance_valid(cur_car):
		return cur_car.global_position
	return player.global_position

func player_alive() -> bool:
	return player.health > 0.0

func player_heading() -> float:
	if cur_car != null and is_instance_valid(cur_car):
		return cur_car.rotation.y
	return player.rotation.y

func in_base() -> bool:
	var p := player_pos()
	return base_rect.has_point(Vector2(p.x, p.z)) and in_interior < 0

func obstacles() -> Array:
	var l: Array = []
	for v in vehicles:
		if is_instance_valid(v):
			l.append(v)
	if cur_car == null:
		l.append(player)
	return l

func drive_input() -> Dictionary:
	var m: Vector2 = hud.move
	var thr = 1.0 if hud.b_gas else clampf(m.y, 0.0, 1.0)
	var brk = 1.0 if hud.b_brake else clampf(-m.y, 0.0, 1.0)
	return {"thr": thr, "brk": brk, "steer": clampf(m.x * 1.3, -1.0, 1.0), "hand": hud.b_hand}

func boss_route() -> Array:
	return [Cfg.nd(-2, 3), Cfg.nd(1, 3), Cfg.nd(3, 1), Cfg.nd(3, 3), Cfg.nd(0, 2), Cfg.nd(-3, 1)]

func signal_state(ns: bool) -> int:
	var t := fposmod(game_t, 16.0)
	if ns:
		if t < 6.0: return 2
		if t < 8.0: return 1
		return 0
	if t < 8.0: return 0
	if t < 14.0: return 2
	return 1

func update_signals() -> void:
	if sig_mm == null:
		return
	var a := signal_state(true)
	var b := signal_state(false)
	var key := Vector2i(a, b)
	if key == sig_last:
		return
	sig_last = key
	var cols := [Color(1, 0.1, 0.1), Color(1, 0.8, 0.1), Color(0.1, 1, 0.25)]
	var mm: MultiMesh = sig_mm.multimesh
	for i in range(sig_axis.size()):
		mm.set_instance_color(i, cols[a] if sig_axis[i] == 1 else cols[b])

func night_amount() -> float:
	return night_v

func time_text() -> String:
	var hh := int(time_h)
	var mn := int((time_h - hh) * 60.0)
	return "%02d:%02d" % [hh, mn]

func quality_name() -> String:
	return ["AUTO", "LOW", "MEDIUM", "HIGH"][quality_mode] + " (" + ["LOW", "MED", "HIGH", "ULTRA"][quality] + ")"

func cycle_quality() -> void:
	quality_mode = (quality_mode + 1) % 4
	if quality_mode > 0:
		apply_quality(quality_mode - 1 if quality_mode < 3 else 3)
	save_game()

func apply_quality(q: int) -> void:
	quality = clampi(q, 0, 3)
	var vp := get_viewport()
	vp.scaling_3d_scale = [0.55, 0.7, 0.85, 1.0][quality]
	sun.shadow_enabled = quality >= 1
	sun.directional_shadow_max_distance = [60.0, 60.0, 90.0, 130.0][quality]
	env.glow_enabled = quality >= 3
	fog_base = [0.0028, 0.0024, 0.0018, 0.0014][quality]
	env.fog_density = fog_base

func weapon_name() -> String:
	return str(Cfg.WEAPONS[weapon]["n"]).to_upper()

func weapons_count() -> int:
	var n := 0
	for w in weapons_owned:
		if w:
			n += 1
	return n

func has_property(idx: int) -> bool:
	return properties.has(idx)

func spend(amount: int) -> bool:
	if money < amount:
		hud.toast("Not enough cash")
		return false
	money -= amount
	sfx("buy", -6.0)
	return true

# ---------------------------------------------------------------- GPS / map
func set_waypoint(p: Vector3) -> void:
	waypoint = Vector3(p.x, 0, p.z)
	waypoint_on = true

func gps_target():
	if in_interior >= 0:
		return null
	if waypoint_on:
		return waypoint
	if marker_on:
		return marker_pos
	return null

func gps_points() -> Array:
	var t = gps_target()
	if t == null or in_interior >= 0:
		return []
	var pp := player_pos()
	var n0 := Vector2i(clampi(roundi(pp.x / Cfg.P), -Cfg.GRID, Cfg.GRID), clampi(roundi(pp.z / Cfg.P), -Cfg.GRID, Cfg.GRID))
	var n1 := Vector2i(clampi(roundi(t.x / Cfg.P), -Cfg.GRID, Cfg.GRID), clampi(roundi(t.z / Cfg.P), -Cfg.GRID, Cfg.GRID))
	return [pp, Cfg.nd(n0.x, n0.y), Cfg.nd(n1.x, n0.y), Cfg.nd(n1.x, n1.y), t]

func map_icons() -> Array:
	var l: Array = []
	for i in range(Cfg.SHOPS.size()):
		var s: Dictionary = Cfg.SHOPS[i]
		l.append({"pos": Cfg.shop_door(i), "color": s["col"].lightened(0.3), "label": s["name"]})
	l.append({"pos": mod_pos, "color": Color(1, 0.55, 0.1), "label": "AUTO MODS"})
	l.append({"pos": pns_pos, "color": Color(0.2, 0.9, 0.4), "label": "PAY AND SPRAY"})
	var bc := base_rect.get_center()
	l.append({"pos": Vector3(bc.x, 0, bc.y), "color": Color(0.8, 0.2, 0.2), "label": "MILITARY BASE"})
	return l

func get_targets() -> Array:
	var l: Array = []
	if marker_on:
		l.append({"pos": marker_pos, "color": marker_col})
	if waypoint_on:
		l.append({"pos": waypoint, "color": Color(1, 0.3, 0.9)})
	return l

func prompt_hidden() -> bool:
	return hud.title_t > 3.5 or hud.menu_open

var fog_base := 0.0018

# ================================================================ environment / time
func update_env(force := false) -> void:
	var a := (time_h - 6.0) / 24.0 * TAU
	var e := sin(a)
	var dayf := smoothstep(-0.12, 0.28, e)
	night_v = 1.0 - dayf
	var elev := asin(clampf(absf(e), 0.0, 1.0))
	sun.rotation = Vector3(-elev, PI * 0.5 + a, 0)
	if e >= 0.0:
		sun.light_color = Color(1.0, 0.93, 0.82).lerp(Color(1.0, 0.6, 0.35), 1.0 - smoothstep(0.0, 0.35, e))
		sun.light_energy = clampf(e * 2.2, 0.0, 1.4) + 0.05
	else:
		sun.light_color = Color(0.5, 0.6, 1.0)
		sun.light_energy = 0.28 * smoothstep(-0.05, -0.4, e)
	var sunset := 1.0 - smoothstep(0.0, 0.35, absf(e))
	var top := Color(0.02, 0.03, 0.08).lerp(Color(0.22, 0.42, 0.78), dayf)
	var hor := Color(0.05, 0.06, 0.11).lerp(Color(0.72, 0.8, 0.9), dayf)
	hor = hor.lerp(Color(0.95, 0.5, 0.28), sunset * 0.6 * dayf if dayf > 0.05 else 0.0)
	sky_mat.sky_top_color = top
	sky_mat.sky_horizon_color = hor
	sky_mat.ground_horizon_color = hor
	sky_mat.ground_bottom_color = top.darkened(0.3)
	env.fog_light_color = hor
	if in_interior >= 0:
		sun.visible = false
		env.ambient_light_color = Color(0.85, 0.85, 0.9)
		env.ambient_light_energy = 1.0
		env.fog_density = 0.0003
	else:
		sun.visible = true
		env.ambient_light_color = Color(0.05, 0.07, 0.13).lerp(Color(0.62, 0.69, 0.8), dayf)
		env.ambient_light_energy = lerpf(0.9, 1.0, dayf)
		env.fog_density = fog_base
	mat_build.set_shader_parameter("night", night_v)
	mat_water.set_shader_parameter("night", night_v)
	mat_neon.set_shader_parameter("glow", 0.5 + night_v * 3.5)
	lamp_mat.emission_energy_multiplier = night_v * 3.0
	Models.light_mat().set_shader_parameter("glow", 0.5 + night_v * 2.5)
	if cur_car != null and is_instance_valid(cur_car) and cur_car.headlight != null:
		cur_car.headlight.light_energy = night_v * 5.0

# ================================================================ main loop
func _process(delta: float) -> void:
	if not ready_ok:
		return
	game_t += delta
	time_h = fposmod(time_h + delta / 100.0, 24.0)
	env_t += delta
	if env_t > 0.5:
		env_t = 0.0
		update_env()
		update_signals()
	camera_update(delta)
	audio_update(delta)
	if quality_mode == 0:
		fps_t += delta
		if fps_t > 3.0:
			fps_t = 0.0
			var f := Engine.get_frames_per_second()
			if f < 38 and quality > 0:
				apply_quality(quality - 1)
			elif f > 58 and quality < 2 and game_t > 20.0:
				apply_quality(quality + 1)

func camera_update(delta: float) -> void:
	var look: Vector2 = hud.take_look()
	if look.length() > 0.01:
		look_idle = 0.0
	else:
		look_idle += delta
	cam_yaw -= look.x * 0.0048
	cam_pitch = clampf(cam_pitch + look.y * 0.0036, -0.15, 1.1)
	var tgt: Node3D = player
	var dist := 5.2
	var height := 1.6
	if in_interior >= 0:
		dist = 3.6
	if cur_car != null and is_instance_valid(cur_car):
		tgt = cur_car
		dist = 8.2 + minf(cur_car.speed_kmh() * 0.012, 2.5)
		height = 1.4
		if cur_car.is_heli:
			dist = 17.0
			height = 2.6
		elif cur_car.is_tank:
			dist = 12.0
			height = 2.6
		elif cur_car.kind == 7:
			dist = 13.0
			height = 2.4
		if look_idle > 1.5 and not cur_car.is_tank:
			var want: float = cur_car.rotation.y
			if cur_car.spd < -1.0:
				want += PI
			cam_yaw = lerp_angle(cam_yaw, want, minf(1.0, 2.4 * delta))
			cam_pitch = lerpf(cam_pitch, 0.22, minf(1.0, 2.0 * delta))
	var focus := tgt.global_position + Vector3(0, height, 0)
	var back := Vector3(sin(cam_yaw), 0, cos(cam_yaw)) * cos(cam_pitch) + Vector3(0, sin(cam_pitch), 0)
	var right := Vector3(cos(cam_yaw), 0, -sin(cam_yaw))
	if cur_car == null:
		focus += right * 0.55
	var want_pos := focus + back * dist
	var q := PhysicsRayQueryParameters3D.create(focus, want_pos, 1)
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if hit:
		want_pos = focus + (want_pos - focus).normalized() * maxf(1.2, (hit.position - focus).length() - 0.4)
	if want_pos.y < 0.4:
		want_pos.y = 0.4
	shake = maxf(0.0, shake - delta * 2.5)
	var off := Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * shake * 0.15
	cam.global_position = want_pos + off
	cam.look_at(focus + off, Vector3.UP)
	var fov_t := 68.0
	if cur_car != null and is_instance_valid(cur_car) and not cur_car.is_heli:
		fov_t = 68.0 + minf(absf(cur_car.spd) * 0.35, 16.0)
	cam.fov = lerpf(cam.fov, fov_t, minf(1.0, 3.0 * delta))

func audio_update(delta: float) -> void:
	var driving: bool = cur_car != null and is_instance_valid(cur_car) and cur_car.mode == "player"
	if driving and not cur_car.is_heli:
		if not engine_p.playing:
			engine_p.play()
		var s: float = absf(cur_car.spd)
		var gear := floorf(s / 10.0)
		var rpm := fposmod(s, 10.0) / 10.0
		engine_p.pitch_scale = 0.7 + rpm * 0.9 + minf(gear, 5.0) * 0.18
		engine_p.volume_db = -14.0 + minf(s * 0.1, 5.0)
	elif engine_p.playing:
		engine_p.stop()
	# helicopter rotor sound (player heli or nearest police heli)
	var hd := 999.0
	for v in vehicles:
		if is_instance_valid(v) and v.is_heli and v.rotor_speed > 5.0:
			hd = minf(hd, v.global_position.distance_to(player_pos()))
	if hd < 220.0:
		if not heli_p.playing:
			heli_p.play()
		heli_p.volume_db = lerpf(heli_p.volume_db, -4.0 - hd * 0.1, minf(1.0, 4.0 * delta))
	elif heli_p.playing:
		heli_p.stop()
	var best := 999.0
	if wanted > 0:
		for v in vehicles:
			if is_instance_valid(v) and v.mode == "police" and not v.is_heli and not v.blocked:
				best = minf(best, v.global_position.distance_to(player_pos()))
	siren_p.volume_db = lerpf(siren_p.volume_db, -80.0 if best > 140.0 else -24.0 + (1.0 - best / 140.0) * 18.0, minf(1.0, 4.0 * delta))

func _physics_process(delta: float) -> void:
	if not ready_ok:
		return
	if hud.paused:
		return
	mod_cd = maxf(0.0, mod_cd - delta)
	pns_cd = maxf(0.0, pns_cd - delta)
	door_cd = maxf(0.0, door_cd - delta)
	base_alarm = maxf(0.0, base_alarm - delta)
	update_shots(delta)
	if dead_t >= 0.0:
		dead_t += delta
		if dead_t > 3.5:
			respawn(300)
		return
	prompt = ""
	if cur_car == null:
		var aiming: bool = hud.b_fire and in_interior < 0
		player.step(delta, hud.move, cam_yaw, aiming, hud.consume("jump"))
		try_shoot(delta)
		if hud.consume("swap"):
			cycle_weapon()
		if in_interior >= 0:
			interior_logic()
		else:
			door_logic()
			vehicle_prompt()
			if hud.consume("enter"):
				try_enter()
	else:
		hud.consume("jump")
		hud.consume("swap")
		if is_instance_valid(cur_car):
			if not cur_car.is_heli:
				check_ped_hits(delta)
			vehicle_weapons(delta)
			service_logic()
		if hud.consume("enter"):
			exit_car(false)
	update_wanted(delta)
	police_manage(delta)
	traffic_manage(delta)
	base_logic()
	update_mission(delta)
	if player.health <= 0.0 and dead_t < 0.0:
		on_player_dead("WASTED")
	save_t += delta
	if save_t > 60.0:
		save_t = 0.0
		save_game()

func cycle_weapon() -> void:
	for i in range(1, 6):
		var nw := (weapon + i) % 5
		if weapons_owned[nw]:
			weapon = nw
			hud.toast("Weapon: " + str(Cfg.WEAPONS[weapon]["n"]))
			return

# ================================================================ combat
func hit_ray(from: Vector3, dir: Vector3, dmg: float, rng_m: float, excl: Array, by_player: bool) -> Vector3:
	var to := from + dir * rng_m
	var q := PhysicsRayQueryParameters3D.create(from, to, 1 | 2 | 4 | 8)
	q.exclude = excl
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if not hit:
		return to
	var col = hit.collider
	if col != null:
		if col.has_method("hit"):
			col.hit(dmg, by_player)
		elif col.has_method("damage"):
			col.damage(dmg * 1.4)
			if by_player:
				if col.mode == "police":
					crime(18.0)
				elif col.mode != "wreck":
					crime(3.0)
	return hit.position

func try_shoot(delta: float) -> void:
	fire_cd -= delta
	if in_interior >= 0 or not hud.b_fire or fire_cd > 0.0 or player.health <= 0.0:
		return
	var wd: Dictionary = Cfg.WEAPONS[weapon]
	fire_cd = float(wd["cd"])
	var from := cam.global_position
	var fwd := -cam.global_transform.basis.z
	var excl: Array = [player.get_rid()]
	var mp: Vector3 = player.global_position + Vector3(0, 1.25, 0) + (-player.global_transform.basis.z) * 0.6
	if weapon == 4:
		var aimp := hit_target_point(from, fwd, excl)
		fire_projectile(mp, (aimp - mp).normalized(), 70.0, 280.0, 7.5, true, excl)
		sfx("boom", -8.0, 1.6)
	else:
		var pel := int(wd["pel"])
		for k in range(pel):
			var dir := (fwd + Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * float(wd["spread"])).normalized()
			var endp := hit_ray(from, dir, float(wd["dmg"]), 90.0, excl, true)
			if k < 3:
				tracer(mp, endp)
		sfx(["shot", "smg", "shotgun", "smg", "shot"][weapon], -6.0)
	cam_pitch = clampf(cam_pitch - 0.004, -0.15, 1.1)
	player.mat.set_shader_parameter("aim", 1.0)
	if wanted == 0:
		crime(1.5)
	for p in peds:
		if is_instance_valid(p) and not p.dead and p.kind == "civ" and p.global_position.distance_to(player.global_position) < 30.0:
			p.panic = 6.0

func hit_target_point(from: Vector3, dir: Vector3, excl: Array) -> Vector3:
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * 120.0, 1 | 2 | 4)
	q.exclude = excl
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if hit:
		return hit.position
	return from + dir * 120.0

func tracer(a: Vector3, b: Vector3) -> void:
	var m := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.04, 0.04, a.distance_to(b))
	m.mesh = bm
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.albedo_color = Color(1.0, 0.85, 0.4)
	m.material_override = mt
	m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(m)
	m.global_position = (a + b) * 0.5
	if a.distance_to(b) > 0.05:
		m.look_at(b, Vector3.UP)
	get_tree().create_timer(0.05).timeout.connect(m.queue_free)

func fire_projectile(pos: Vector3, dir: Vector3, speed: float, dmg: float, radius: float, by_player: bool, excl: Array) -> void:
	var n := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.22, 0.22, 1.0)
	n.mesh = bm
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.albedo_color = Color(1.0, 0.6, 0.15)
	n.material_override = mt
	n.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(n)
	n.global_position = pos
	n.look_at(pos + dir, Vector3.UP)
	shots.append({"node": n, "vel": dir * speed, "life": 4.0, "dmg": dmg, "radius": radius, "by": by_player, "excl": excl})

func update_shots(delta: float) -> void:
	var keep: Array = []
	for s in shots:
		var n: Node3D = s["node"]
		if not is_instance_valid(n):
			continue
		var p0 := n.global_position
		var p1 = p0 + (s["vel"] as Vector3) * delta
		var q = PhysicsRayQueryParameters3D.create(p0, p1, 1 | 2 | 4 | 8)
		q.exclude = s["excl"]
		var hit = get_world_3d().direct_space_state.intersect_ray(q)
		s["life"] = float(s["life"]) - delta
		if hit:
			explosion(hit.position, float(s["radius"]), float(s["dmg"]), bool(s["by"]))
			n.queue_free()
		elif float(s["life"]) <= 0.0 or p1.y < 0.1:
			explosion(p1, float(s["radius"]), float(s["dmg"]), bool(s["by"]))
			n.queue_free()
		else:
			n.global_position = p1
			keep.append(s)
	shots = keep

func explosion(pos: Vector3, radius: float, dmg: float, by_player: bool) -> void:
	sfx("boom", -2.0 if pos.distance_to(player_pos()) < 60.0 else -12.0)
	if pos.distance_to(player_pos()) < 40.0:
		shake = maxf(shake, 1.2)
	var fx := CPUParticles3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.5
	sm.height = 1.0
	sm.radial_segments = 6
	sm.rings = 3
	fx.mesh = sm
	fx.amount = 22
	fx.lifetime = 0.9
	fx.one_shot = true
	fx.explosiveness = 1.0
	fx.spread = 180.0
	fx.initial_velocity_min = 5.0
	fx.initial_velocity_max = 11.0
	fx.gravity = Vector3(0, 2.0, 0)
	fx.scale_amount_min = 0.8
	fx.scale_amount_max = radius * 0.35
	var fm := StandardMaterial3D.new()
	fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fm.albedo_color = Color(1.0, 0.5, 0.12, 0.85)
	fx.material_override = fm
	add_child(fx)
	fx.global_position = pos
	fx.emitting = true
	get_tree().create_timer(1.6).timeout.connect(fx.queue_free)
	var fl := OmniLight3D.new()
	fl.light_energy = 6.0
	fl.omni_range = radius * 2.5
	fl.light_color = Color(1.0, 0.65, 0.3)
	add_child(fl)
	fl.global_position = pos + Vector3(0, 1.5, 0)
	get_tree().create_timer(0.18).timeout.connect(fl.queue_free)
	for v in vehicles.duplicate():
		if is_instance_valid(v) and v.mode != "wreck":
			var d: float = v.global_position.distance_to(pos)
			if d < radius + 2.0:
				var f := 1.0 - d / (radius + 2.0)
				v.knock += (v.global_position - pos).normalized() * 9.0 * f
				v.damage(dmg * f)
				if by_player:
					if v.mode == "police":
						crime(15.0)
					elif v.mode == "ai":
						crime(4.0)
	for p in peds.duplicate():
		if is_instance_valid(p) and not p.dead and p.global_position.distance_to(pos) < radius:
			p.hit(dmg, by_player)
	var pd := player_pos().distance_to(pos)
	if pd < radius:
		hurt_player(dmg * 0.35 * (1.0 - pd / radius))
	if by_player:
		crime(6.0)

func enemy_shoot(p, dist: float) -> void:
	var chance := clampf(0.55 - dist / 70.0, 0.1, 0.5)
	if cur_car != null:
		chance *= 0.6
	var tp := player_pos() + Vector3(0, 1.1, 0)
	var mp: Vector3 = p.global_position + Vector3(0, 1.2, 0)
	var hit_it := randf() < chance
	var endp := tp
	if not hit_it:
		endp = tp + Vector3(randf_range(-2.5, 2.5), randf_range(-0.8, 1.5), randf_range(-2.5, 2.5))
	tracer(mp, endp)
	sfx("enemy", -10.0 + clampf(-dist * 0.2, -14.0, 0.0))
	if hit_it:
		var dm := randf_range(5.0, 9.0)
		if p.kind == "boss":
			dm = randf_range(8.0, 13.0)
		elif p.kind == "cop":
			dm = randf_range(4.0, 7.0)
		hurt_player(dm)

func heli_shoot(v, dist: float) -> void:
	var tp := player_pos() + Vector3(0, 1.0, 0)
	var hit_it := randf() < clampf(0.5 - dist / 250.0, 0.12, 0.45)
	var endp := tp
	if not hit_it:
		endp = tp + Vector3(randf_range(-4, 4), 0, randf_range(-4, 4))
	tracer(v.global_position + Vector3(0, 1, 0), endp)
	sfx("enemy", -9.0)
	if hit_it:
		hurt_player(randf_range(6.0, 11.0))

func fire_shell(v, by_player: bool) -> void:
	var d: Vector3 = v.turret_dir()
	var pos: Vector3 = v.muzzle_pos()
	if by_player:
		var excl: Array = [v.get_rid(), player.get_rid()]
		var aimp := hit_target_point(cam.global_position, -cam.global_transform.basis.z, excl)
		d = (aimp - pos).normalized()
	else:
		var tp := player_pos() + Vector3(0, 1.0, 0)
		d = (tp - pos).normalized()
	fire_projectile(pos, d, 85.0, 320.0, 8.5, by_player, [v.get_rid()])
	sfx("boom", -4.0, 1.3)
	shake = maxf(shake, 0.5)

func vehicle_weapons(delta: float) -> void:
	var c = cur_car
	if c.is_tank:
		if hud.b_fire and c.fire_cd <= 0.0:
			c.fire_cd = 1.5
			fire_shell(c, true)
	elif c.is_heli and c.global_position.y > 1.0:
		if hud.b_fire and c.fire_cd <= 0.0:
			c.fire_cd = 0.09
			var dir = (-c.global_transform.basis.z + Vector3(0, -0.1, 0)).normalized()
			var mp: Vector3 = c.global_position + Vector3(0, 1.2, 0) + dir * 3.0
			var endp = hit_ray(mp, dir, 26.0, 160.0, [c.get_rid(), player.get_rid()], true)
			tracer(mp, endp)
			sfx("smg", -8.0)
			crime(0.8)
		if hud.b_rkt and c.fire_cd <= 0.0:
			c.fire_cd = 1.1
			var dir2 = (-c.global_transform.basis.z + Vector3(0, -0.12, 0)).normalized()
			fire_projectile(c.global_position + Vector3(0, 1.0, 0) + dir2 * 3.0, dir2, 80.0, 260.0, 7.5, true, [c.get_rid(), player.get_rid()])
			sfx("boom", -6.0, 1.5)

func hurt_player(dmg: float) -> void:
	if cur_car != null and is_instance_valid(cur_car):
		cur_car.damage(dmg * 0.7)
		shake = maxf(shake, 0.5)
		return
	player.hurt(dmg)
	hud.flash = 1.0
	shake = maxf(shake, 0.6)

func check_ped_hits(delta: float) -> void:
	if absf(cur_car.spd) < 3.5:
		return
	for p in peds:
		if is_instance_valid(p) and not p.dead:
			var d: float = p.global_position.distance_to(cur_car.global_position)
			if d < 2.3:
				p.hit(200.0, true)
				crime(10.0)
				cur_car.vel *= 0.95 if cur_car.is_tank else 0.93
				sfx("crash", -8.0, 1.4)

func on_crash(loss: float, pos: Vector3) -> void:
	shake = maxf(shake, clampf(loss * 0.1, 0.3, 1.5))
	sfx("crash", -4.0 + minf(loss * 0.2, 4.0))
	if wanted == 0 and loss > 10.0:
		crime(2.0)

func on_bump(v, imp: Vector3, by) -> void:
	if by == cur_car and cur_car != null:
		if v.mode == "police":
			crime(12.0)
		elif v.mode == "ai":
			crime(3.0)

func on_explode(v, was_player: bool) -> void:
	explosion(v.global_position + Vector3(0, 1, 0), 6.0, 110.0, false)
	if was_player or v == cur_car:
		exit_car(true)
		player.hurt(55.0)
		hud.flash = 1.0
	if v.mission_car and m_active:
		fail_mission("The vehicle was destroyed")

func ped_died(p, by_player: bool) -> void:
	if p.cash > 0 and by_player:
		money += p.cash
		hud.toast("+$" + str(p.cash))
	if by_player and p.kind == "civ":
		crime(8.0)

# ================================================================ vehicles
func vehicle_prompt() -> void:
	var best = null
	var bd := 5.5
	for v in vehicles:
		if is_instance_valid(v) and v.mode != "wreck" and not (v.is_heli and v.global_position.y > 4.0):
			var d: float = v.global_position.distance_to(player.global_position)
			if d < bd:
				bd = d
				best = v
	if best != null:
		prompt = "ENTER: " + str(best.info["n"])

func try_enter() -> void:
	var best = null
	var bd := 5.5
	for v in vehicles:
		if is_instance_valid(v) and v.mode != "wreck" and not (v.is_heli and v.global_position.y > 4.0):
			var d: float = v.global_position.distance_to(player.global_position)
			if d < bd:
				bd = d
				best = v
	if best == null:
		return
	var was: String = best.mode
	if was == "police":
		crime(30.0)
	elif was == "ai":
		crime(12.0)
	elif best.kind == 10 and base_rect.has_point(Vector2(best.global_position.x, best.global_position.z)):
		crime(60.0)
	best.blocked = false
	best.set_player(true)
	if was == "parked":
		best.vel = Vector3.ZERO
	cur_car = best
	player.visible = false
	player.collision_layer = 0
	player.collision_mask = 0
	sfx("crash", -20.0, 2.0)
	update_env(true)

func exit_car(forced: bool) -> void:
	if cur_car == null or not is_instance_valid(cur_car):
		cur_car = null
		return
	var c = cur_car
	if c.is_heli and c.global_position.y > 3.5 and not forced:
		hud.toast("Land first!")
		return
	var side: Vector3 = c.global_transform.basis.x * (2.6 if not c.is_heli else 4.5)
	player.global_position = c.global_position + side
	player.global_position.y = 0.0
	player.rotation.y = c.rotation.y
	player.y = 0.0
	player.visible = true
	player.collision_layer = 8
	player.collision_mask = 1 | 2 | 4
	if c.mode == "player":
		c.set_player(false)
	cur_car = null
	hud.b_gas = false
	cam_yaw = c.rotation.y
	look_idle = 5.0
	sync_owned(c)

func service_logic() -> void:
	var c = cur_car
	if c.is_heli:
		return
	var p = c.global_position
	if xz_dist(p, mod_pos) < 5.0 and absf(c.spd) < 9.0 and mod_cd <= 0.0 and c.kind != 7:
		mod_cd = 4.0
		menu_stack.clear()
		menu_ctx = ""
		menu_go("mod", false)
	elif xz_dist(p, pns_pos) < 5.0 and absf(c.spd) < 9.0 and pns_cd <= 0.0 and not c.is_tank:
		pns_cd = 6.0
		if wanted > 0 and cop_seen_t < 3.0:
			hud.toast("The cops are watching - lose them first!")
		elif money < 300:
			hud.toast("Pay and Spray costs $300")
		else:
			spend(300)
			hud.start_fade(_do_pns)

func _do_pns() -> void:
	if cur_car != null and is_instance_valid(cur_car):
		cur_car.repair()
		cur_car.set_paint(Shops.PAINTS[randi() % Shops.PAINTS.size()][1])
		sync_owned(cur_car)
	if wanted > 0:
		heat = 0.0
		hud.toast("Wanted level cleared")
	else:
		hud.toast("Vehicle repainted and repaired")

func road_spawn_near(from: Vector3, fwd: Vector3, dist: float) -> Dictionary:
	var p := from + fwd * dist
	p.x = clampf(p.x, -360.0, 360.0)
	p.z = clampf(p.z, -360.0, 360.0)
	var lx := roundf(p.x / Cfg.P) * Cfg.P
	var lz := roundf(p.z / Cfg.P) * Cfg.P
	var yaw := 0.0
	if absf(p.x - lx) <= absf(p.z - lz):
		p.x = lx + 6.0
		yaw = 0.0
	else:
		p.z = lz + 6.0
		yaw = PI * 0.5
	return {"pos": Vector3(p.x, 0, p.z), "yaw": yaw}

func add_owned(kind: int, col: Color) -> void:
	owned.append({"kind": kind, "col": col, "eng": 0, "brk": 0, "arm": 0})

func spawn_owned(i: int) -> void:
	if i < 0 or i >= owned.size():
		return
	var o: Dictionary = owned[i]
	for v in vehicles:
		if is_instance_valid(v) and v.owned_idx == i:
			v.queue_free()
	var fwd := Vector3(-sin(cam_yaw), 0, -cos(cam_yaw))
	var rs := road_spawn_near(player_pos(), fwd, 22.0)
	var v = spawn_vehicle(int(o["kind"]), o["col"], "parked", rs["pos"], float(rs["yaw"]))
	v.owned_idx = i
	v.eng_lvl = int(o["eng"])
	v.brk_lvl = int(o["brk"])
	v.arm_lvl = int(o["arm"])
	v.apply_upgrades()
	hud.toast(str(v.info["n"]) + " delivered")

func spawn_owned_at_dealer(i: int) -> void:
	var o: Dictionary = owned[i]
	var door := Cfg.shop_door(3)
	var v = spawn_vehicle(int(o["kind"]), o["col"], "parked", Vector3(door.x - 4.5, 0, door.z), 0.0)
	v.owned_idx = i

func sync_owned(c) -> void:
	if c == null or not is_instance_valid(c):
		return
	if c.owned_idx >= 0 and c.owned_idx < owned.size():
		var o: Dictionary = owned[c.owned_idx]
		o["eng"] = c.eng_lvl
		o["brk"] = c.brk_lvl
		o["arm"] = c.arm_lvl
		o["col"] = c.paint

# ================================================================ interiors / doors
func xz_dist(a: Vector3, b: Vector3) -> float:
	return Vector2(a.x - b.x, a.z - b.z).length()

func door_logic() -> void:
	for i in range(Cfg.SHOPS.size()):
		var dp := Cfg.shop_door(i)
		if xz_dist(player.global_position, dp) < 2.0:
			prompt = "Entering " + str(Cfg.SHOPS[i]["name"])
			if door_cd <= 0.0:
				if wanted > 0:
					hud.toast("Closed - the police are after you")
					door_cd = 3.0
				else:
					door_cd = 3.0
					hud.start_fade(_do_enter.bind(i))
			return

func _do_enter(i: int) -> void:
	if not interiors.has(i):
		interiors[i] = Shops.build_interior(self, i)
	var d: Dictionary = interiors[i]
	player.global_position = d["spawn"]
	player.rotation.y = 0.0
	player.y = 0.0
	cam_yaw = 0.0
	cam_pitch = 0.25
	in_interior = i
	door_cd = 2.0
	update_env(true)

func interior_logic() -> void:
	var d: Dictionary = interiors[in_interior]
	var pp = player.global_position
	if xz_dist(pp, d["exit"]) < 1.7 and door_cd <= 0.0:
		door_cd = 3.0
		hud.start_fade(_do_exit)
		return
	if xz_dist(pp, d["service"]) < 2.4:
		prompt = "ENTER: " + str(Cfg.SHOPS[in_interior]["name"])
		if hud.consume("enter"):
			menu_stack.clear()
			menu_ctx = ""
			menu_go("shop:" + str(Cfg.SHOPS[in_interior]["id"]), false)

func _do_exit() -> void:
	var i := in_interior
	in_interior = -1
	var dp := Cfg.shop_door(i)
	player.global_position = dp + Vector3(-3.0, 0, 0)
	player.rotation.y = PI * 0.5
	cam_yaw = PI * 0.5
	door_cd = 3.0
	update_env(true)

# ================================================================ phone / menus
func open_phone() -> void:
	if in_interior >= 0 or dead_t >= 0.0 or hud.menu_open:
		return
	menu_stack.clear()
	menu_ctx = ""
	menu_go("phone", false)

func menu_go(ctx: String, push := true) -> void:
	if push and menu_ctx != "":
		menu_stack.append(menu_ctx)
	menu_ctx = ctx
	var d: Dictionary = Shops.menu(self, ctx)
	if hud.menu_open:
		hud.menu_title = d["title"]
		hud.refresh_menu(d["rows"], d["sub"])
	else:
		hud.open_menu(d["title"], d["rows"], Callable(), d["sub"])

func menu_pick(id) -> void:
	Shops.pick(self, menu_ctx, str(id))

func menu_back() -> void:
	if menu_stack.size() > 0:
		var c: String = menu_stack.pop_back()
		menu_go(c, false)
	else:
		menu_ctx = ""
		hud.close_menu()

func fast_travel(pos: Vector3) -> void:
	hud.start_fade(_do_travel.bind(pos))

func _do_travel(pos: Vector3) -> void:
	var lx := roundf(pos.x / Cfg.P) * Cfg.P
	var lz := roundf(pos.z / Cfg.P) * Cfg.P
	var p := Vector3(lx, 0, pos.z)
	if absf(pos.x - lx) > absf(pos.z - lz):
		p = Vector3(pos.x, 0, lz)
	if cur_car != null and is_instance_valid(cur_car):
		cur_car.global_position = p
		cur_car.vel = Vector3.ZERO
		cur_car.spd = 0.0
	else:
		player.global_position = p
	waypoint_on = false
	hud.toast("Arrived")

func sleep_and_save() -> void:
	hud.close_menu()
	menu_ctx = ""
	hud.start_fade(_do_sleep)

func _do_sleep() -> void:
	time_h = 8.0
	player.health = 100.0
	update_env(true)
	save_game()
	hud.toast("Good morning. Game saved.")

# ================================================================ wanted / police
func crime(amount: float) -> void:
	if in_interior >= 0:
		return
	heat = minf(100.0, heat + amount)

func update_wanted(delta: float) -> void:
	var lvl := 0
	if heat >= 5.0: lvl = 1
	if heat >= 28.0: lvl = 2
	if heat >= 48.0: lvl = 3
	if heat >= 68.0: lvl = 4
	if heat >= 88.0: lvl = 5
	if lvl > wanted:
		wanted = lvl
		hud.toast("WANTED LEVEL " + str(wanted))
		cop_seen_t = 0.0
	elif lvl < wanted and wanted > 0 and heat < float([0, 3, 24, 44, 64, 84][wanted]):
		wanted = maxi(lvl, 0)
	var pp := player_pos()
	var seen := false
	if wanted > 0:
		for v in vehicles:
			if is_instance_valid(v) and v.mode == "police" and not v.blocked:
				var rng_see = 220.0 if v.is_heli else 130.0
				if v.global_position.distance_to(pp) < rng_see:
					seen = true
		for p in peds:
			if is_instance_valid(p) and p.kind == "cop" and not p.dead and p.global_position.distance_to(pp) < 90.0:
				seen = true
		if seen:
			cop_seen_t = 0.0
		else:
			cop_seen_t += delta
		var need := 18.0 + 5.0 * wanted
		if cop_seen_t > need:
			heat -= 5.0 * delta
		elif cop_seen_t > need * 0.5:
			heat -= 0.5 * delta
		heat = maxf(0.0, heat)
		if heat < 3.0:
			heat = 0.0
			wanted = 0
			hud.toast("WANTED LEVEL LOST")
			cleanup_police()
	else:
		heat = maxf(0.0, heat - 0.8 * delta)
	# foot cops pile out of nearby police cars
	if wanted > 0 and cur_car == null:
		for v in vehicles:
			if is_instance_valid(v) and v.mode == "police" and not v.is_heli and not v.is_tank and not v.cops_out and v.global_position.distance_to(pp) < 30.0:
				v.cops_out = true
				for k in range(2):
					var c = spawn_ped(v.global_position + v.global_transform.basis.x * (2.5 + k * 1.2), "cop")
					c.mission_ped = false
	# busted
	if cur_car == null and wanted > 0:
		var near := false
		for v in vehicles:
			if is_instance_valid(v) and v.mode == "police" and not v.is_heli and v.global_position.distance_to(pp) < 6.5 and absf(v.spd) < 4.0:
				near = true
		for p in peds:
			if is_instance_valid(p) and p.kind == "cop" and not p.dead and p.global_position.distance_to(pp) < 2.6:
				near = true
		busted_t = busted_t + delta if near else maxf(0.0, busted_t - delta)
		if busted_t > 3.0:
			busted_t = 0.0
			on_player_dead("BUSTED")
	# police ram damage
	if cur_car != null and is_instance_valid(cur_car) and not cur_car.is_heli:
		for v in vehicles:
			if is_instance_valid(v) and v.mode == "police" and not v.is_heli and wanted > 0 and v.global_position.distance_to(cur_car.global_position) < 3.6:
				cur_car.damage(9.0 * delta)
				cur_car.vel += (cur_car.global_position - v.global_position).normalized() * 6.0 * delta
	elif wanted > 0 and cur_car == null:
		for v in vehicles:
			if is_instance_valid(v) and v.mode == "police" and not v.is_heli and absf(v.spd) > 3.0 and v.global_position.distance_to(player.global_position) < 2.2 and game_t - last_hurt_t > 0.8:
				last_hurt_t = game_t
				player.hurt(14.0)
				hud.flash = 1.0

func cleanup_police() -> void:
	for v in vehicles:
		if is_instance_valid(v) and v.mode == "police":
			if v.blocked:
				v.queue_free()
			elif v.is_heli or v.is_tank:
				v.mode = "ai" if not v.is_heli else "parked"
			else:
				v.mode = "ai"
				v.base_speed = 11.0

func police_manage(delta: float) -> void:
	police_cd -= delta
	if police_cd > 0.0:
		return
	police_cd = 2.0
	var pp := player_pos()
	var want_n: int = [0, 2, 3, 4, 6, 8][wanted]
	want_n = mini(want_n, [3, 4, 6, 8][quality])
	var cops := 0
	var helis := 0
	var tanks := 0
	var blocks := 0
	for v in vehicles:
		if not is_instance_valid(v) or v.mode != "police":
			continue
		if v.blocked:
			blocks += 1
			if wanted == 0 or v.global_position.distance_to(pp) > 260.0:
				v.queue_free()
		elif v.is_heli:
			helis += 1
		elif v.is_tank:
			tanks += 1
		else:
			cops += 1
			if wanted > 0 and v.global_position.distance_to(pp) > 270.0:
				v.queue_free()
	if wanted <= 0:
		return
	if cops < want_n:
		spawn_ai("police", true)
	heli_cd -= 2.0
	block_cd -= 2.0
	if wanted >= 4 and helis < (1 if wanted == 4 else 2) and heli_cd <= 0.0:
		heli_cd = 25.0
		var a := randf() * TAU
		spawn_heli(21, "police", pp + Vector3(cos(a) * 160.0, 40.0, sin(a) * 160.0))
		hud.toast("Police helicopter inbound")
	if wanted >= 5 and tanks < 1:
		spawn_ai("tank", true)
		hud.toast("The army has been deployed")
	if wanted >= 3 and blocks < 4 and block_cd <= 0.0 and in_interior < 0:
		block_cd = 30.0
		spawn_roadblock()

func spawn_roadblock() -> void:
	var pp := player_pos()
	var f := Vector3(-sin(cam_yaw), 0, -cos(cam_yaw))
	if cur_car != null and is_instance_valid(cur_car) and not cur_car.is_heli:
		f = -cur_car.global_transform.basis.z
		f.y = 0.0
	if f.length() < 0.1:
		return
	f = f.normalized()
	var tgt := pp + f * 120.0
	var n := Vector2i(clampi(roundi(tgt.x / Cfg.P), -Cfg.GRID, Cfg.GRID), clampi(roundi(tgt.z / Cfg.P), -Cfg.GRID, Cfg.GRID))
	var along_x := absf(f.x) > absf(f.z)
	var base := Cfg.nd(n.x, n.y)
	var pos := base
	var yaw := 0.0
	if along_x:
		pos = base + Vector3(-signf(f.x) * 18.0, 0, 0)
		yaw = 0.0
		pos.z = base.z
	else:
		pos = base + Vector3(0, 0, -signf(f.z) * 18.0)
		yaw = PI * 0.5
	if pos.distance_to(pp) < 50.0:
		return
	for k in range(2):
		var off := Vector3(0, 0, (k - 0.5) * 6.0) if along_x else Vector3((k - 0.5) * 6.0, 0, 0)
		var v = spawn_vehicle(0, Color(0.92, 0.92, 0.95), "police", pos + off, yaw)
		v.make_police()
		v.blocked = true
		v.cops_out = true
		var c = spawn_ped(pos + off + (Vector3(-signf(f.x) * -3.0, 0, 0) if along_x else Vector3(0, 0, -signf(f.z) * -3.0)), "cop")
		c.mission_ped = false

func traffic_manage(delta: float) -> void:
	vehicles = vehicles.filter(func(v): return is_instance_valid(v))
	peds = peds.filter(func(p): return is_instance_valid(p))
	var pp := player_pos()
	traffic_cd -= delta
	if traffic_cd <= 0.0:
		traffic_cd = 0.4
		var ai_n := 0
		var max_ai: int = [12, 18, 26, 34][quality]
		for v in vehicles:
			if v.mode == "ai" and not v.is_heli:
				ai_n += 1
				if v.global_position.distance_to(pp) > 310.0:
					v.queue_free()
		if ai_n < max_ai:
			spawn_ai("ai")
		var civ_n := 0
		for p in peds:
			if p.kind == "civ" and not p.dead:
				civ_n += 1
		if civ_n < [18, 26, 36, 46][quality]:
			spawn_ped()

func base_logic() -> void:
	if in_base() and base_alarm <= 0.0:
		base_alarm = 45.0
		crime(62.0)
		hud.toast("You entered a military zone!")

# ================================================================ death / respawn
func on_player_dead(kind: String) -> void:
	dead_t = 0.0
	hud.show_banner(kind, 3.4)
	if cur_car != null:
		exit_car(true)
	if m_active:
		fail_mission("You failed")

func respawn(fee: int) -> void:
	dead_t = -1.0
	money = maxi(0, money - fee)
	heat = 0.0
	wanted = 0
	cleanup_police()
	if in_interior >= 0:
		in_interior = -1
		update_env(true)
	player.health = 100.0
	player.armor = 0.0
	player.y = 0.0
	player.yv = 0.0
	if home_idx >= 0:
		player.global_position = Cfg.shop_door(home_idx) + Vector3(-3.0, 0, 0)
		hud.toast("You woke up at home. Fee $" + str(fee))
	else:
		player.global_position = Cfg.ic(-3, -3)
		hud.toast("Hospital bill: $" + str(fee))

# ================================================================ missions
func make_marker() -> void:
	marker = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 2.2
	cm.bottom_radius = 2.2
	cm.height = 70.0
	cm.radial_segments = 16
	cm.rings = 1
	marker.mesh = cm
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mt.albedo_color = Color(1.0, 0.8, 0.1, 0.22)
	mt.cull_mode = BaseMaterial3D.CULL_DISABLED
	marker.material_override = mt
	marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	marker.visible = false
	add_child(marker)

func set_marker(pos: Vector3, col: Color, show := true) -> void:
	marker_pos = pos
	marker_col = col
	marker_on = show
	marker.visible = show and in_interior < 0
	marker.global_position = Vector3(pos.x, 35, pos.z)
	(marker.material_override as StandardMaterial3D).albedo_color = Color(col.r, col.g, col.b, 0.22)

func update_mission(delta: float) -> void:
	start_arm = maxf(0.0, start_arm - delta)
	var defs := Story.missions()
	if not m_active:
		m_title = ""
		m_text = ""
		var nxt: Dictionary
		if chapter < defs.size():
			nxt = defs[chapter]
		else:
			story_done = true
			if courier_def.is_empty():
				courier_def = Story.courier()
			nxt = courier_def
		var sp: Vector3 = nxt["start"]
		set_marker(sp, Color(1.0, 0.8, 0.1) if chapter < defs.size() else Color(0.3, 0.8, 1.0))
		m_text = ("Next: " if chapter < defs.size() else "Job: ") + str(nxt["title"])
		m_title = ("CHAPTER " + str(chapter + 1)) if chapter < defs.size() else "FREE ROAM"
		var auto_start := chapter == 0 and game_t > 7.0
		if in_interior < 0 and ((xz_dist(player_pos(), sp) < 6.0 and start_arm <= 0.0) or auto_start):
			begin_mission(nxt)
		return
	m_step_t += delta
	var s: Dictionary = m_def["steps"][m_step]
	var pp := player_pos()
	match s["t"]:
		"goto":
			var ok := xz_dist(pp, s["p"]) < 8.0
			if s.get("car", false):
				ok = ok and cur_car != null and cur_car == m_car
			if ok:
				next_step()
		"getcar":
			if m_car != null and is_instance_valid(m_car):
				set_marker(m_car.global_position, Color(0.3, 1.0, 0.4))
			if cur_car != null and cur_car == m_car:
				next_step()
		"kill":
			var alive := 0
			for t in m_targets:
				if is_instance_valid(t) and not t.dead:
					alive += 1
			m_text = str(s["text"]) + " (" + str(alive) + " left)"
			if alive == 0:
				next_step()
		"wanted":
			if not m_wanted_set:
				m_wanted_set = true
				heat = maxf(heat, [0.0, 10.0, 32.0, 52.0, 72.0, 90.0][int(s["lv"])])
			elif wanted == 0 and m_step_t > 5.0:
				next_step()
		"chase":
			var t = m_targets[0] if m_targets.size() > 0 else null
			if t == null or not is_instance_valid(t) or t.mode == "wreck":
				next_step()
			else:
				set_marker(t.global_position, Color(1.0, 0.2, 0.2))
				var dd: float = t.global_position.distance_to(pp)
				m_text = str(s["text"]) + " (" + str(int(dd)) + " m)"
				if dd > 280.0:
					m_lost_t += delta
					if m_lost_t > 8.0:
						fail_mission("You lost the target")
				else:
					m_lost_t = 0.0
		"race":
			var pts: Array = s["pts"]
			m_race_t -= delta
			m_text = "RACE " + str(m_race_i + 1) + "/" + str(pts.size()) + "   " + str(maxi(0, int(m_race_t))) + "s"
			if cur_car == null or cur_car.is_heli:
				m_text += "  - get in a car!"
			set_marker(pts[m_race_i], Color(0.2, 0.9, 1.0))
			if cur_car != null and not cur_car.is_heli and xz_dist(pp, pts[m_race_i]) < 14.0:
				m_race_i += 1
				sfx("buy", -6.0, 1.2)
				if m_race_i >= pts.size():
					next_step()
			elif m_race_t <= 0.0:
				fail_mission("Out of time")
		"killheli":
			var h = m_targets[0] if m_targets.size() > 0 else null
			if h == null or not is_instance_valid(h) or h.mode == "wreck":
				next_step()
			else:
				set_marker(h.global_position, Color(1.0, 0.2, 0.2))
				m_text = str(s["text"]) + " (" + str(int(h.global_position.distance_to(pp))) + " m)"

func begin_mission(def: Dictionary) -> void:
	m_active = true
	m_def = def
	m_step = -1
	m_car = null
	m_targets.clear()
	m_lost_t = 0.0
	set_marker(Vector3.ZERO, Color.WHITE, false)
	hud.toast(str(def["title"]))
	next_step()

func next_step() -> void:
	m_step += 1
	m_wanted_set = false
	m_step_t = 0.0
	m_lost_t = 0.0
	if m_step >= m_def["steps"].size():
		complete_mission()
		return
	var s: Dictionary = m_def["steps"][m_step]
	m_title = str(m_def["title"])
	match s["t"]:
		"talk":
			for ln in s["lines"]:
				hud.say(str(ln[0]), str(ln[1]))
			next_step()
		"goto":
			m_text = str(s["text"])
			set_marker(s["p"], Color(1.0, 0.8, 0.1))
		"getcar":
			m_text = str(s["text"])
			var v = spawn_vehicle(int(s["kind"]), s["color"], "parked", s["p"], float(s["yaw"]))
			v.mission_car = true
			m_car = v
			set_marker(s["p"], Color(0.3, 1.0, 0.4))
			if int(s.get("heat", 0)) > 0:
				m_text += " (stolen!)"
		"kill":
			m_text = str(s["text"])
			set_marker(s["p"], Color(1.0, 0.2, 0.2))
			m_targets.clear()
			for i in range(int(s["n"])):
				var ax := randf() < 0.5
				var off := randf_range(9.0, 24.0) * (1.0 if randf() < 0.5 else -1.0)
				var pos: Vector3 = s["p"] + (Vector3(off, 0, randf_range(-3, 3)) if ax else Vector3(randf_range(-3, 3), 0, off))
				var p = spawn_ped(pos, "gun")
				m_targets.append(p)
			if s.get("boss", false):
				var bp = spawn_ped(s["p"] + Vector3(0, 0, -6), "boss")
				m_targets.append(bp)
		"wanted":
			m_text = str(s["text"])
			set_marker(Vector3.ZERO, Color.WHITE, false)
		"chase":
			m_text = str(s["text"])
			var sp: Vector3 = s["p"]
			var n0 := Vector2i(roundi(sp.x / Cfg.P), roundi(sp.z / Cfg.P))
			var dv := Vector2(0, 1)
			if not Cfg.inb(n0 + Vector2i(0, 1)):
				dv = Vector2(0, -1)
			var p2 := Vector2(n0) * Cfg.P + Cfg.lane_off(dv)
			var v2 = spawn_vehicle(int(s["kind"]), s["color"], "boss", Vector3(p2.x, 0, p2.y), Cfg.yaw_of(dv))
			v2.dirv = dv
			v2.node = n0 + Vector2i(roundi(dv.x), roundi(dv.y))
			v2.choose_next()
			v2.max_health = 260.0
			v2.health = 260.0
			v2.base_speed = 30.0
			m_targets = [v2]
		"race":
			m_race_i = 0
			m_race_t = float(s["time"])
			m_text = str(s["text"])
			set_marker(s["pts"][0], Color(0.2, 0.9, 1.0))
		"killheli":
			m_text = str(s["text"])
			var sp2: Vector3 = s["p"]
			var h = spawn_heli(20, "boss", Vector3(sp2.x, 45.0, sp2.z))
			h.max_health = 600.0
			h.health = 600.0
			m_targets = [h]
			weapons_owned[4] = true
			weapon = 4
			hud.toast("RPG acquired - shoot the helicopter down!")

func complete_mission() -> void:
	var reward := int(m_def["reward"])
	money += reward
	hud.toast("MISSION COMPLETE  +$" + str(reward))
	hud.show_banner("MISSION PASSED", 3.0)
	if m_def.has("weapon"):
		weapons_owned[int(m_def["weapon"])] = true
	if m_car != null and is_instance_valid(m_car):
		m_car.mission_car = false
	if chapter < Story.missions().size():
		chapter += 1
		if chapter >= Story.missions().size():
			hud.toast("STORY COMPLETE - free roam and courier jobs unlocked")
	else:
		courier_def = Story.courier()
	player.armor = minf(100.0, player.armor + 25.0)
	m_active = false
	m_def = {}
	m_car = null
	m_targets.clear()
	start_arm = 8.0
	save_game()

func fail_mission(reason: String) -> void:
	hud.toast("MISSION FAILED: " + reason)
	m_active = false
	m_def = {}
	hud.clear_subs()
	for t in m_targets:
		if is_instance_valid(t):
			t.queue_free()
	m_targets.clear()
	m_car = null
	start_arm = 5.0

# ================================================================ save / load
func save_game() -> void:
	var cf := ConfigFile.new()
	cf.set_value("save", "money", money)
	cf.set_value("save", "chapter", chapter)
	cf.set_value("save", "weapons", weapons_owned)
	cf.set_value("save", "outfit", player.outfit)
	cf.set_value("save", "outfits", owned_outfits)
	cf.set_value("save", "owned", owned)
	cf.set_value("save", "props", properties)
	cf.set_value("save", "home", home_idx)
	cf.set_value("save", "quality", quality_mode)
	cf.set_value("save", "time", time_h)
	cf.save("user://save2.cfg")

func load_game() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://save2.cfg") != OK:
		return
	money = int(cf.get_value("save", "money", 800))
	chapter = int(cf.get_value("save", "chapter", 0))
	var w = cf.get_value("save", "weapons", weapons_owned)
	if w is Array and w.size() == 5:
		weapons_owned = w
	owned_outfits = cf.get_value("save", "outfits", [0])
	owned = cf.get_value("save", "owned", [])
	properties = cf.get_value("save", "props", [])
	home_idx = int(cf.get_value("save", "home", -1))
	quality_mode = int(cf.get_value("save", "quality", 0))
	time_h = float(cf.get_value("save", "time", 17.0))
	player.set_outfit(int(cf.get_value("save", "outfit", 0)))
	if quality_mode > 0:
		apply_quality(quality_mode - 1 if quality_mode < 3 else 3)
	if chapter > 0:
		start_arm = 6.0

# ================================================================ update checker
func check_update() -> void:
	http = HTTPRequest.new()
	http.timeout = 8.0
	add_child(http)
	http.request_completed.connect(_on_update_result)
	var err := http.request(Cfg.UPDATE_URL, PackedStringArray(["User-Agent: IronHarbor", "Accept: application/vnd.github+json"]))
	if err != OK:
		return

func _ver_parts(t: String) -> Array:
	var out: Array = []
	var cur := ""
	for ch in t:
		if ch >= "0" and ch <= "9":
			cur += ch
		elif cur != "":
			out.append(int(cur))
			cur = ""
	if cur != "":
		out.append(int(cur))
	return out

func _ver_newer(latest: String, current: String) -> bool:
	var a := _ver_parts(latest)
	var b := _ver_parts(current)
	for i in range(maxi(a.size(), b.size())):
		var x: int = a[i] if i < a.size() else 0
		var y: int = b[i] if i < b.size() else 0
		if x > y:
			return true
		if x < y:
			return false
	return false

func _on_update_result(result: int, code: int, headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		return
	var j = JSON.parse_string(body.get_string_from_utf8())
	if typeof(j) != TYPE_DICTIONARY:
		return
	var tag := str(j.get("tag_name", ""))
	if tag != "" and _ver_newer(tag, Cfg.VERSION_NAME):
		hud.show_update("Update " + tag + " available", str(j.get("html_url", Cfg.REPO_URL)))
