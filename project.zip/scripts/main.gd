extends Node3D
# IRON HARBOR - main game: city, day/night, traffic, police, missions, camera.
const Cfg = preload("res://scripts/cfg.gd")
const Sh = preload("res://scripts/shaders.gd")
const Models = preload("res://scripts/models.gd")
const Story = preload("res://scripts/story.gd")
const VehicleS = preload("res://scripts/vehicle.gd")
const PedS = preload("res://scripts/ped.gd")
const PlayerS = preload("res://scripts/player.gd")
const HudS = preload("res://scripts/hud.gd")

var player
var cur_car = null
var cam: Camera3D
var sun: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var hud
var time_h := 17.0
var vehicles: Array = []
var peds: Array = []
var money := 500
var heat := 0.0
var wanted := 0
var cop_seen_t := 99.0
var busted_t := 0.0
var chapter := 0
var quality_mode := 0
var quality := 2
var fps_t := 0.0
var cam_yaw := 0.0
var cam_pitch := 0.3
var look_idle := 5.0
var mat_build: ShaderMaterial
var mat_ground: ShaderMaterial
var mat_water: ShaderMaterial
var lamp_mat: StandardMaterial3D
var weapons_owned := [true, false]
var weapon := 0
var fire_cd := 0.0
var game_t := 0.0
var shake := 0.0
var dead_t := -1.0
var engine_p: AudioStreamPlayer
var siren_p: AudioStreamPlayer
var police_cd := 2.0
var traffic_cd := 3.0
var env_t := 0.0
var save_t := 0.0
var player_heading_v := 0.0
var last_hurt_t := 0.0
# mission state
var m_active := false
var m_def := {}
var m_step := 0
var m_wait := false
var m_cars: Array = []
var m_car = null
var m_targets: Array = []
var m_wanted_set := false
var m_step_t := 0.0
var m_title := ""
var m_text := ""
var start_arm := 3.0
var marker: MeshInstance3D
var marker_pos := Vector3.ZERO
var marker_on := false
var marker_col := Color(1, 0.8, 0.1)
var story_done := false
var courier_def := {}
var cleanup_nodes: Array = []

# ================================================================ setup
func _ready() -> void:
	randomize()
	Engine.max_fps = 60
	get_viewport().msaa_3d = Viewport.MSAA_DISABLED
	setup_env()
	build_city()
	cam = Camera3D.new()
	cam.far = 460.0
	cam.near = 0.12
	cam.fov = 68.0
	add_child(cam)
	cam.current = true
	player = PlayerS.new()
	add_child(player)
	player.setup(self)
	player.global_position = Cfg.ic(0, 0)
	cam_yaw = PI
	var layer := CanvasLayer.new()
	layer.layer = 5
	add_child(layer)
	hud = HudS.new()
	hud.main = self
	layer.add_child(hud)
	make_audio()
	make_marker()
	load_game()
	spawn_parked(16)
	for i in range(12):
		spawn_ai("ai")
	for i in range(22):
		spawn_ped()
	apply_quality(2)
	update_env(true)

func setup_env() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_curve = 0.12
	sky_mat.ground_curve = 0.05
	sky_mat.sun_angle_max = 25.0
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.6, 0.68, 0.8)
	env.ambient_light_energy = 1.0
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.0
	env.fog_enabled = true
	env.fog_density = 0.0018
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.08
	env.adjustment_saturation = 1.12
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 90.0
	sun.shadow_bias = 0.06
	add_child(sun)

func mm_inst(mesh: Mesh, mat: Material, xf: Array, cols: Array, shadow := true) -> MultiMeshInstance3D:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = cols.size() > 0
	mm.mesh = mesh
	mm.instance_count = xf.size()
	for i in range(xf.size()):
		mm.set_instance_transform(i, xf[i])
		if cols.size() > 0:
			mm.set_instance_color(i, cols[i])
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = mat
	if not shadow:
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	return mi

func build_city() -> void:
	var P := Cfg.P
	# ground
	var ground := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(780, 780)
	ground.mesh = pm
	mat_ground = ShaderMaterial.new()
	mat_ground.shader = Sh.get_shader("ground")
	ground.material_override = mat_ground
	ground.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ground)
	# water
	var water := MeshInstance3D.new()
	var wm := PlaneMesh.new()
	wm.size = Vector2(2600, 2600)
	wm.subdivide_width = 40
	wm.subdivide_depth = 40
	water.mesh = wm
	water.position.y = -1.4
	mat_water = ShaderMaterial.new()
	mat_water.shader = Sh.get_shader("water")
	water.material_override = mat_water
	water.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(water)
	# boundary walls
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)
	var wall_mat := StandardMaterial3D.new()
	wall_mat.albedo_color = Color(0.5, 0.5, 0.5)
	for side in [[Vector3(0, 0.8, -388), Vector3(780, 1.6, 2)], [Vector3(0, 0.8, 388), Vector3(780, 1.6, 2)], [Vector3(-388, 0.8, 0), Vector3(2, 1.6, 780)], [Vector3(388, 0.8, 0), Vector3(2, 1.6, 780)]]:
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = side[1] + Vector3(0, 6, 0)
		cs.shape = bs
		cs.position = side[0]
		body.add_child(cs)
		var wmi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = side[1]
		wmi.mesh = bm
		wmi.position = side[0]
		wmi.material_override = wall_mat
		add_child(wmi)
	# buildings
	mat_build = ShaderMaterial.new()
	mat_build.shader = Sh.get_shader("building")
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261024
	var pal := [Color(0.62, 0.58, 0.52), Color(0.48, 0.5, 0.55), Color(0.7, 0.66, 0.6), Color(0.58, 0.4, 0.34), Color(0.42, 0.45, 0.48), Color(0.75, 0.72, 0.68), Color(0.36, 0.4, 0.46), Color(0.62, 0.54, 0.42)]
	var bx: Array = []
	var bc: Array = []
	var tree_pos: Array = []
	var cont_x: Array = []
	var cont_c: Array = []
	var park_mat := StandardMaterial3D.new()
	park_mat.albedo_color = Color(0.18, 0.38, 0.16)
	park_mat.roughness = 1.0
	for bi in range(-Cfg.GRID, Cfg.GRID):
		for bj in range(-Cfg.GRID, Cfg.GRID):
			var S := P - 22.0
			var ox := bi * P + 11.0
			var oz := bj * P + 11.0
			var cx := ox + S * 0.5
			var cz := oz + S * 0.5
			var zone := clampf(1.0 - Vector2(cx, cz).length() / 330.0, 0.0, 1.0)
			var r := rng.randf()
			if r < 0.11 and (bi != 0 or bj != 0):
				var pk := MeshInstance3D.new()
				var ppm := PlaneMesh.new()
				ppm.size = Vector2(S, S)
				pk.mesh = ppm
				pk.position = Vector3(cx, 0.03, cz)
				pk.material_override = park_mat
				pk.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
				add_child(pk)
				for t in range(26):
					tree_pos.append(Vector3(cx + rng.randf_range(-S * 0.45, S * 0.45), 0, cz + rng.randf_range(-S * 0.45, S * 0.45)))
				continue
			var lots: Array = []
			if rng.randf() < 0.3:
				lots.append([cx, cz, S - 2.0, S - 2.0])
			else:
				var hs := S * 0.5
				for a in [-1, 1]:
					for b in [-1, 1]:
						lots.append([cx + a * hs * 0.5, cz + b * hs * 0.5, hs - 3.0, hs - 3.0])
			for lot in lots:
				var w: float = lot[2] - rng.randf_range(0.0, 3.0)
				var d: float = lot[3] - rng.randf_range(0.0, 3.0)
				var h := rng.randf_range(8.0, 26.0) + zone * zone * rng.randf() * 85.0
				if lot[2] > 40.0:
					h = rng.randf_range(9.0, 16.0) + zone * 20.0
				var col: Color = pal[rng.randi() % pal.size()]
				col = col.lightened(rng.randf_range(-0.1, 0.1))
				bx.append(Transform3D(Basis.from_scale(Vector3(w, h, d)), Vector3(lot[0], h * 0.5, lot[1])))
				bc.append(col)
				var cs2 := CollisionShape3D.new()
				var bs2 := BoxShape3D.new()
				bs2.size = Vector3(w, h, d)
				cs2.shape = bs2
				cs2.position = Vector3(lot[0], h * 0.5, lot[1])
				body.add_child(cs2)
				if h > 38.0:
					var h2 := h * 0.28
					bx.append(Transform3D(Basis.from_scale(Vector3(w * 0.62, h2, d * 0.62)), Vector3(lot[0], h + h2 * 0.5, lot[1])))
					bc.append(col.darkened(0.12))
					bx.append(Transform3D(Basis.from_scale(Vector3(0.5, 14.0, 0.5)), Vector3(lot[0], h + h2 + 7.0, lot[1])))
					bc.append(Color(0.3, 0.3, 0.32))
	mm_inst(BoxMesh.new(), mat_build, bx, bc)
	# harbor apron containers and cranes
	for i in range(34):
		var px := rng.randf_range(-300.0, 300.0)
		var pz := rng.randf_range(340.0, 372.0)
		var stack := rng.randi_range(1, 3)
		var cc := Color.from_hsv(rng.randf(), 0.55, 0.65)
		var ang := 0.0 if rng.randf() < 0.5 else PI * 0.5
		for sidx in range(stack):
			cont_x.append(Transform3D(Basis(Vector3.UP, ang) * Basis.from_scale(Vector3(6.0, 2.6, 2.4)), Vector3(px, 1.3 + sidx * 2.6, pz)))
			cont_c.append(cc)
		var ccs := CollisionShape3D.new()
		var cbs := BoxShape3D.new()
		cbs.size = Vector3(6.0 if ang == 0.0 else 2.4, 2.6 * stack, 2.4 if ang == 0.0 else 6.0)
		ccs.shape = cbs
		ccs.position = Vector3(px, 1.3 * stack, pz)
		body.add_child(ccs)
	var cmat := StandardMaterial3D.new()
	cmat.vertex_color_use_as_albedo = true
	cmat.roughness = 0.6
	cmat.metallic = 0.3
	mm_inst(BoxMesh.new(), cmat, cont_x, cont_c)
	var crane_mat := StandardMaterial3D.new()
	crane_mat.albedo_color = Color(0.8, 0.25, 0.1)
	for cxp in [-130.0, 60.0, 210.0]:
		for lx in [-9.0, 9.0]:
			var leg := MeshInstance3D.new()
			var lm := BoxMesh.new()
			lm.size = Vector3(1.4, 34.0, 1.4)
			leg.mesh = lm
			leg.position = Vector3(cxp + lx, 17.0, 378.0)
			leg.material_override = crane_mat
			add_child(leg)
		var beam := MeshInstance3D.new()
		var bmm := BoxMesh.new()
		bmm.size = Vector3(22.0, 2.0, 2.0)
		beam.mesh = bmm
		beam.position = Vector3(cxp, 34.0, 378.0)
		beam.material_override = crane_mat
		add_child(beam)
		var arm := MeshInstance3D.new()
		var am := BoxMesh.new()
		am.size = Vector3(2.0, 2.0, 60.0)
		arm.mesh = am
		arm.position = Vector3(cxp, 35.0, 356.0)
		arm.material_override = crane_mat
		add_child(arm)
	# street trees
	var step := 24.0
	for li in range(-Cfg.GRID, Cfg.GRID + 1):
		var t := -312.0
		while t <= 312.0:
			if absf(fposmod(t + P * 0.5, P) - P * 0.5) > 15.0 and rng.randf() < 0.55:
				var sd := 10.2 if rng.randf() < 0.5 else -10.2
				tree_pos.append(Vector3(li * P + sd, 0, t))
				tree_pos.append(Vector3(t, 0, li * P + sd))
			t += step
	var tx: Array = []
	var cx_: Array = []
	var cc2: Array = []
	for tp in tree_pos:
		var sc := rng.randf_range(0.8, 1.35)
		tx.append(Transform3D(Basis.from_scale(Vector3(0.35, 2.4 * sc, 0.35)), tp + Vector3(0, 1.2 * sc, 0)))
		cx_.append(Transform3D(Basis.from_scale(Vector3(2.0 * sc, 2.0 * sc, 2.0 * sc)), tp + Vector3(0, 3.6 * sc, 0)))
		cc2.append(Color.from_hsv(rng.randf_range(0.22, 0.34), rng.randf_range(0.5, 0.75), rng.randf_range(0.35, 0.6)))
	var trunk_mat := StandardMaterial3D.new()
	trunk_mat.albedo_color = Color(0.25, 0.17, 0.1)
	var crown_mat := StandardMaterial3D.new()
	crown_mat.vertex_color_use_as_albedo = true
	crown_mat.roughness = 1.0
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.6
	cyl.bottom_radius = 0.8
	cyl.height = 1.0
	cyl.radial_segments = 6
	cyl.rings = 1
	var sph := SphereMesh.new()
	sph.radius = 1.0
	sph.height = 2.0
	sph.radial_segments = 8
	sph.rings = 5
	mm_inst(cyl, trunk_mat, tx, [])
	mm_inst(sph, crown_mat, cx_, cc2)
	# street lamps
	var lx_: Array = []
	var lh_: Array = []
	var lt := -300.0
	while lt <= 300.0:
		if absf(fposmod(lt + P * 0.5, P) - P * 0.5) > 14.0:
			for li in range(-Cfg.GRID, Cfg.GRID + 1):
				var sd2 := 8.7 if int(lt / 40.0 + li) % 2 == 0 else -8.7
				lx_.append(Transform3D(Basis.from_scale(Vector3(1, 1, 1)), Vector3(li * P + sd2, 3.7, lt)))
				lh_.append(Transform3D(Basis.IDENTITY, Vector3(li * P + sd2 - sign(sd2) * 0.8, 7.5, lt)))
				lx_.append(Transform3D(Basis.IDENTITY, Vector3(lt, 3.7, li * P + sd2)))
				lh_.append(Transform3D(Basis.IDENTITY, Vector3(lt, 7.5, li * P + sd2 - sign(sd2) * 0.8)))
		lt += 40.0
	var pole := CylinderMesh.new()
	pole.top_radius = 0.07
	pole.bottom_radius = 0.1
	pole.height = 7.4
	pole.radial_segments = 6
	pole.rings = 1
	var pole_mat := StandardMaterial3D.new()
	pole_mat.albedo_color = Color(0.12, 0.13, 0.15)
	mm_inst(pole, pole_mat, lx_, [], false)
	var lamp_m := BoxMesh.new()
	lamp_m.size = Vector3(0.7, 0.14, 0.4)
	lamp_mat = StandardMaterial3D.new()
	lamp_mat.albedo_color = Color(1.0, 0.9, 0.6)
	lamp_mat.emission_enabled = true
	lamp_mat.emission = Color(1.0, 0.8, 0.45)
	lamp_mat.emission_energy_multiplier = 0.0
	mm_inst(lamp_m, lamp_mat, lh_, [], false)

# ================================================================ audio
func make_audio() -> void:
	engine_p = AudioStreamPlayer.new()
	engine_p.stream = Models.sound("engine")
	engine_p.volume_db = -12.0
	add_child(engine_p)
	siren_p = AudioStreamPlayer.new()
	siren_p.stream = Models.sound("siren")
	siren_p.volume_db = -80.0
	add_child(siren_p)
	siren_p.play()

func sfx(name: String, vol := -4.0, pitch := 1.0) -> void:
	var p := AudioStreamPlayer.new()
	p.stream = Models.sound(name)
	p.volume_db = vol
	p.pitch_scale = pitch * randf_range(0.93, 1.07)
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()

# ================================================================ spawning
func spawn_vehicle(kind: int, col: Color, md: String, pos: Vector3, yaw: float):
	var v = VehicleS.new()
	add_child(v)
	v.setup(self, kind, col, md)
	v.global_position = pos
	v.rotation.y = yaw
	vehicles.append(v)
	return v

func rand_car_color() -> Color:
	var pal := [Color(0.85, 0.85, 0.87), Color(0.08, 0.08, 0.1), Color(0.5, 0.5, 0.55), Color(0.6, 0.08, 0.08), Color(0.1, 0.25, 0.5), Color(0.9, 0.75, 0.1), Color(0.15, 0.4, 0.25), Color(0.7, 0.4, 0.15)]
	return pal[randi() % pal.size()]

func spawn_parked(n: int) -> void:
	for i in range(n):
		var line := randi_range(-Cfg.GRID, Cfg.GRID)
		var t := randf_range(-300.0, 300.0)
		if absf(fposmod(t + Cfg.P * 0.5, Cfg.P) - Cfg.P * 0.5) < 16.0:
			continue
		var side := 6.4 if randf() < 0.5 else -6.4
		var pos := Vector3(line * Cfg.P + side, 0, t)
		var yaw := 0.0
		if randf() < 0.5:
			pos = Vector3(t, 0, line * Cfg.P + side)
			yaw = PI * 0.5
		if pos.distance_to(Cfg.ic(0, 0)) < 15.0:
			continue
		spawn_vehicle(randi() % 3, rand_car_color(), "parked", pos, yaw + (0.0 if randf() < 0.5 else PI))

func spawn_ai(md: String, near_player := false):
	var dirs := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	var pp: Vector3 = player_pos()
	for attempt in range(14):
		var n := Vector2i(randi_range(-Cfg.GRID, Cfg.GRID), randi_range(-Cfg.GRID, Cfg.GRID))
		var d: Vector2i = dirs[randi() % 4]
		var prev := n - d
		if not Cfg.inb(prev):
			continue
		var dv := Vector2(d)
		var p2 := Vector2(prev) * Cfg.P + dv * Cfg.P * randf_range(0.25, 0.75) + Cfg.lane_off(dv)
		var wp := Vector3(p2.x, 0, p2.y)
		var dist := wp.distance_to(pp)
		if near_player:
			if dist < 110.0 or dist > 200.0:
				continue
		elif dist < 55.0 or dist > 280.0:
			continue
		var kind := randi() % 3
		var col := rand_car_color()
		if md == "police":
			kind = 0
			col = Color(0.92, 0.92, 0.95)
		var v = spawn_vehicle(kind, col, md, wp, Cfg.yaw_of(dv))
		v.dirv = dv
		v.node = n
		v.choose_next()
		if md == "police":
			v.make_police()
		return v
	return null

func spawn_ped(pos := Vector3.ZERO, kind := "civ"):
	var p = PedS.new()
	add_child(p)
	p.setup(self, kind, pos)
	peds.append(p)
	return p

# ================================================================ helpers used by other scripts
func player_pos() -> Vector3:
	if cur_car != null and is_instance_valid(cur_car):
		return cur_car.global_position
	return player.global_position

func player_alive() -> bool:
	return player.health > 0.0

func player_heading() -> float:
	if cur_car != null and is_instance_valid(cur_car):
		return cur_car.rotation.y
	return player.rotation.y

func obstacles() -> Array:
	var l: Array = []
	for v in vehicles:
		if is_instance_valid(v):
			l.append(v)
	if cur_car == null:
		l.append(player)
	return l

func drive_input() -> Dictionary:
	var m: Vector2 = hud.move
	var thr := 1.0 if hud.b_gas else clampf(m.y, 0.0, 1.0)
	var brk := 1.0 if hud.b_brake else clampf(-m.y, 0.0, 1.0)
	return {"thr": thr, "brk": brk, "steer": clampf(m.x * 1.3, -1.0, 1.0), "hand": hud.b_hand}

func get_targets() -> Array:
	var l: Array = []
	if marker_on:
		l.append({"pos": marker_pos, "color": marker_col})
	return l

func quality_name() -> String:
	return ["AUTO", "LOW", "MEDIUM", "HIGH"][quality_mode] + " (" + ["LOW", "MED", "HIGH", "ULTRA"][quality] + ")"

func cycle_quality() -> void:
	quality_mode = (quality_mode + 1) % 4
	if quality_mode > 0:
		apply_quality(quality_mode - 1 if quality_mode < 3 else 3)
	save_game()

func apply_quality(q: int) -> void:
	quality = clampi(q, 0, 3)
	var vp := get_viewport()
	vp.scaling_3d_scale = [0.55, 0.7, 0.85, 1.0][quality]
	sun.shadow_enabled = quality >= 1
	sun.directional_shadow_max_distance = [60.0, 60.0, 90.0, 130.0][quality]
	env.glow_enabled = quality >= 3
	env.fog_density = [0.0028, 0.0024, 0.0018, 0.0014][quality]

# ================================================================ environment / time
func update_env(force := false) -> void:
	var a := (time_h - 6.0) / 24.0 * TAU
	var e := sin(a)
	var dayf := smoothstep(-0.12, 0.28, e)
	var night := 1.0 - dayf
	var elev := asin(clampf(absf(e), 0.0, 1.0))
	sun.rotation = Vector3(-elev, PI * 0.5 + a, 0)
	if e >= 0.0:
		sun.light_color = Color(1.0, 0.93, 0.82).lerp(Color(1.0, 0.6, 0.35), 1.0 - smoothstep(0.0, 0.35, e))
		sun.light_energy = clampf(e * 2.2, 0.0, 1.4) + 0.05
	else:
		sun.light_color = Color(0.5, 0.6, 1.0)
		sun.light_energy = 0.28 * smoothstep(-0.05, -0.4, e)
	var sunset := 1.0 - smoothstep(0.0, 0.35, absf(e))
	var top := Color(0.02, 0.03, 0.08).lerp(Color(0.22, 0.42, 0.78), dayf)
	var hor := Color(0.05, 0.06, 0.11).lerp(Color(0.72, 0.8, 0.9), dayf)
	hor = hor.lerp(Color(0.95, 0.5, 0.28), sunset * 0.6 * dayf if dayf > 0.05 else 0.0)
	sky_mat.sky_top_color = top
	sky_mat.sky_horizon_color = hor
	sky_mat.ground_horizon_color = hor
	sky_mat.ground_bottom_color = top.darkened(0.3)
	env.fog_light_color = hor
	env.ambient_light_color = Color(0.05, 0.07, 0.13).lerp(Color(0.62, 0.69, 0.8), dayf)
	env.ambient_light_energy = lerpf(0.9, 1.0, dayf)
	mat_build.set_shader_parameter("night", night)
	mat_water.set_shader_parameter("night", night)
	lamp_mat.emission_energy_multiplier = night * 3.0
	Models.light_mat().set_shader_parameter("glow", 0.5 + night * 2.5)
	if cur_car != null and is_instance_valid(cur_car) and cur_car.headlight != null:
		cur_car.headlight.light_energy = night * 5.0

# ================================================================ main loop
func _process(delta: float) -> void:
	game_t += delta
	time_h = fposmod(time_h + delta / 100.0, 24.0)
	env_t += delta
	if env_t > 0.5:
		env_t = 0.0
		update_env()
	camera_update(delta)
	audio_update(delta)
	if quality_mode == 0:
		fps_t += delta
		if fps_t > 3.0:
			fps_t = 0.0
			var f := Engine.get_frames_per_second()
			if f < 38 and quality > 0:
				apply_quality(quality - 1)
			elif f > 58 and quality < 2 and game_t > 20.0:
				apply_quality(quality + 1)

func camera_update(delta: float) -> void:
	var look: Vector2 = hud.take_look()
	if look.length() > 0.01:
		look_idle = 0.0
	else:
		look_idle += delta
	cam_yaw -= look.x * 0.0048
	cam_pitch = clampf(cam_pitch + look.y * 0.0036, -0.15, 1.1)
	var tgt: Node3D = player
	var dist := 5.2
	var height := 1.6
	if cur_car != null and is_instance_valid(cur_car):
		tgt = cur_car
		dist = 8.2 + minf(cur_car.speed_kmh() * 0.012, 2.5)
		height = 1.4
		if look_idle > 1.5:
			var want: float = cur_car.rotation.y
			if cur_car.spd < -1.0:
				want += PI
			cam_yaw = lerp_angle(cam_yaw, want, minf(1.0, 2.4 * delta))
			cam_pitch = lerpf(cam_pitch, 0.22, minf(1.0, 2.0 * delta))
	var focus := tgt.global_position + Vector3(0, height, 0)
	var back := Vector3(sin(cam_yaw), 0, cos(cam_yaw)) * cos(cam_pitch) + Vector3(0, sin(cam_pitch), 0)
	var right := Vector3(cos(cam_yaw), 0, -sin(cam_yaw))
	if cur_car == null:
		focus += right * 0.55
	var want_pos := focus + back * dist
	var q := PhysicsRayQueryParameters3D.create(focus, want_pos, 1)
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if hit:
		want_pos = focus + (want_pos - focus).normalized() * maxf(1.2, (hit.position - focus).length() - 0.4)
	shake = maxf(0.0, shake - delta * 2.5)
	var off := Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * shake * 0.15
	cam.global_position = want_pos + off
	cam.look_at(focus + off, Vector3.UP)
	var fov_t := 68.0
	if cur_car != null and is_instance_valid(cur_car):
		fov_t = 68.0 + minf(absf(cur_car.spd) * 0.35, 16.0)
	cam.fov = lerpf(cam.fov, fov_t, minf(1.0, 3.0 * delta))

func audio_update(delta: float) -> void:
	if cur_car != null and is_instance_valid(cur_car) and cur_car.mode == "player":
		if not engine_p.playing:
			engine_p.play()
		var s: float = absf(cur_car.spd)
		var gear := floorf(s / 10.0)
		var rpm := fposmod(s, 10.0) / 10.0
		engine_p.pitch_scale = 0.7 + rpm * 0.9 + minf(gear, 5.0) * 0.18
		engine_p.volume_db = -14.0 + minf(s * 0.1, 5.0)
	elif engine_p.playing:
		engine_p.stop()
	var best := 999.0
	if wanted > 0:
		for v in vehicles:
			if is_instance_valid(v) and v.mode == "police":
				best = minf(best, v.global_position.distance_to(player_pos()))
	siren_p.volume_db = lerpf(siren_p.volume_db, -80.0 if best > 140.0 else -24.0 + (1.0 - best / 140.0) * 18.0, minf(1.0, 4.0 * delta))

func _physics_process(delta: float) -> void:
	if hud.paused:
		return
	if dead_t >= 0.0:
		dead_t += delta
		if dead_t > 3.5:
			respawn(300)
		return
	# on-foot control
	if cur_car == null:
		var aiming: bool = hud.b_fire
		player.step(delta, hud.move, cam_yaw, aiming, hud.consume("jump"))
		try_shoot(delta)
		if hud.consume("swap"):
			var nw := (weapon + 1) % 2
			if weapons_owned[nw]:
				weapon = nw
				hud.toast("Switched weapon: " + ["Pistol", "SMG"][weapon])
	else:
		hud.consume("jump")
		hud.consume("swap")
		if is_instance_valid(cur_car):
			check_ped_hits(delta)
	if hud.consume("enter"):
		if cur_car == null:
			try_enter()
		else:
			exit_car(false)
	update_wanted(delta)
	traffic_manage(delta)
	update_mission(delta)
	if player.health <= 0.0 and dead_t < 0.0:
		on_player_dead("WASTED")
	save_t += delta
	if save_t > 60.0:
		save_t = 0.0
		save_game()

# ================================================================ combat
func try_shoot(delta: float) -> void:
	fire_cd -= delta
	if not hud.b_fire or fire_cd > 0.0 or player.health <= 0.0:
		return
	fire_cd = [0.28, 0.09][weapon]
	var dmg: float = [34.0, 17.0][weapon]
	var from := cam.global_position
	var to := from + (-cam.global_transform.basis.z) * 90.0
	var q := PhysicsRayQueryParameters3D.create(from, to, 1 | 2 | 4)
	q.exclude = [player.get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	var endp := to
	if hit:
		endp = hit.position
		var col = hit.collider
		if col != null:
			if col.has_method("hit"):
				col.hit(dmg, true)
			elif col.has_method("damage"):
				col.damage(dmg * 1.4)
				if col.mode == "police":
					crime(18.0)
				elif col.mode != "wreck":
					crime(3.0)
	var mp: Vector3 = player.global_position + Vector3(0, 1.25, 0) + (-player.global_transform.basis.z) * 0.6
	tracer(mp, endp)
	sfx(["shot", "smg"][weapon], -6.0)
	cam_pitch = clampf(cam_pitch - 0.004, -0.15, 1.1)
	if wanted == 0:
		crime(1.5)
	# gunfire panics civilians nearby
	for p in peds:
		if is_instance_valid(p) and not p.dead and p.kind == "civ" and p.global_position.distance_to(player.global_position) < 30.0:
			p.panic = 6.0

func tracer(a: Vector3, b: Vector3) -> void:
	var m := MeshInstance3D.new()
	var bm := BoxMesh.new()
	var len := a.distance_to(b)
	bm.size = Vector3(0.04, 0.04, len)
	m.mesh = bm
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.albedo_color = Color(1.0, 0.85, 0.4)
	m.material_override = mt
	m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(m)
	m.global_position = (a + b) * 0.5
	m.look_at(b, Vector3.UP)
	get_tree().create_timer(0.05).timeout.connect(m.queue_free)

func enemy_shoot(p, dist: float) -> void:
	var chance := clampf(0.55 - dist / 70.0, 0.1, 0.5)
	if cur_car != null:
		chance *= 0.6
	var tp := player_pos() + Vector3(0, 1.1, 0)
	var mp: Vector3 = p.global_position + Vector3(0, 1.2, 0)
	var hit_it := randf() < chance
	var endp := tp
	if not hit_it:
		endp = tp + Vector3(randf_range(-2.5, 2.5), randf_range(-0.8, 1.5), randf_range(-2.5, 2.5))
	tracer(mp, endp)
	sfx("enemy", -10.0 + clampf(-dist * 0.2, -14.0, 0.0))
	if hit_it:
		hurt_player(randf_range(5.0, 9.0) if p.kind != "boss" else randf_range(8.0, 13.0))

func hurt_player(dmg: float) -> void:
	if cur_car != null and is_instance_valid(cur_car):
		cur_car.damage(dmg * 0.7)
		shake = maxf(shake, 0.5)
		return
	player.hurt(dmg)
	hud.flash = 1.0
	shake = maxf(shake, 0.6)

func check_ped_hits(delta: float) -> void:
	if absf(cur_car.spd) < 3.5:
		return
	for p in peds:
		if is_instance_valid(p) and not p.dead:
			var d: float = p.global_position.distance_to(cur_car.global_position)
			if d < 2.3:
				p.hit(200.0, true)
				crime(10.0)
				cur_car.vel *= 0.93
				sfx("crash", -8.0, 1.4)

func on_crash(loss: float, pos: Vector3) -> void:
	shake = maxf(shake, clampf(loss * 0.1, 0.3, 1.5))
	sfx("crash", -4.0 + minf(loss * 0.2, 4.0))
	if wanted == 0 and loss > 10.0:
		crime(2.0)

func on_bump(v, imp: Vector3, by) -> void:
	if by == cur_car and cur_car != null:
		if v.mode == "police":
			crime(12.0)
		elif v.mode == "ai":
			crime(3.0)

func on_explode(v, was_player: bool) -> void:
	sfx("boom", 0.0)
	shake = 1.5
	if was_player or v == cur_car:
		exit_car(true)
		player.hurt(55.0)
		hud.flash = 1.0
	elif v.global_position.distance_to(player_pos()) < 7.0:
		player.hurt(40.0)
		hud.flash = 1.0
	for p in peds:
		if is_instance_valid(p) and not p.dead and p.global_position.distance_to(v.global_position) < 6.0:
			p.hit(300.0, true)
	if v.mission_car and m_active:
		fail_mission("The vehicle was destroyed")

func ped_died(p, by_player: bool) -> void:
	if p.cash > 0:
		money += p.cash
		hud.toast("+$" + str(p.cash))
	if by_player and p.kind == "civ":
		crime(8.0)

# ================================================================ vehicles
func try_enter() -> void:
	var best = null
	var bd := 5.5
	for v in vehicles:
		if is_instance_valid(v) and v.mode != "wreck":
			var d: float = v.global_position.distance_to(player.global_position)
			if d < bd:
				bd = d
				best = v
	if best == null:
		return
	var was: String = best.mode
	if was == "police":
		crime(30.0)
	elif was == "ai":
		crime(12.0)
	best.set_player(true)
	best.vel = best.vel * 0.0 if was == "parked" else best.vel
	cur_car = best
	player.visible = false
	player.collision_layer = 0
	player.collision_mask = 0
	sfx("crash", -20.0, 2.0)
	if m_active and m_car == best:
		pass

func exit_car(forced: bool) -> void:
	if cur_car == null or not is_instance_valid(cur_car):
		cur_car = null
		return
	var c = cur_car
	var side: Vector3 = c.global_transform.basis.x * 2.6
	player.global_position = c.global_position + side
	player.global_position.y = 0.0
	player.rotation.y = c.rotation.y
	player.visible = true
	player.collision_layer = 8
	player.collision_mask = 1 | 2 | 4
	if c.mode == "player":
		c.set_player(false)
	cur_car = null
	hud.b_gas = false
	cam_yaw = c.rotation.y
	look_idle = 5.0

func crime(amount: float) -> void:
	heat = minf(100.0, heat + amount)

func update_wanted(delta: float) -> void:
	var lvl := 0
	if heat >= 5.0: lvl = 1
	if heat >= 28.0: lvl = 2
	if heat >= 48.0: lvl = 3
	if heat >= 68.0: lvl = 4
	if heat >= 88.0: lvl = 5
	if lvl > wanted:
		wanted = lvl
		hud.toast("WANTED LEVEL " + str(wanted))
		cop_seen_t = 99.0
	# cop awareness
	var nearest := 999.0
	var pp := player_pos()
	for v in vehicles:
		if is_instance_valid(v) and v.mode == "police":
			nearest = minf(nearest, v.global_position.distance_to(pp))
	if wanted > 0:
		if nearest < 85.0:
			cop_seen_t = 0.0
		else:
			cop_seen_t += delta
		if cop_seen_t > 7.0:
			heat -= 11.0 * delta
		else:
			heat -= 0.25 * delta
		heat = maxf(0.0, heat)
		if heat < 4.0:
			heat = 0.0
			wanted = 0
			hud.toast("WANTED LEVEL LOST")
			for v in vehicles:
				if is_instance_valid(v) and v.mode == "police":
					v.mode = "ai"
					v.base_speed = 11.0
	else:
		heat = maxf(0.0, heat - 1.0 * delta)
	# busted when on foot with a cop right next to you
	if cur_car == null and wanted > 0:
		var near_cop := false
		for v in vehicles:
			if is_instance_valid(v) and v.mode == "police" and v.global_position.distance_to(pp) < 7.0 and absf(v.spd) < 4.0:
				near_cop = true
		busted_t = busted_t + delta if near_cop else maxf(0.0, busted_t - delta)
		if busted_t > 2.5:
			busted_t = 0.0
			on_player_dead("BUSTED")
	# police ram damage
	if cur_car != null and is_instance_valid(cur_car):
		for v in vehicles:
			if is_instance_valid(v) and v.mode == "police" and wanted > 0 and v.global_position.distance_to(cur_car.global_position) < 3.6:
				cur_car.damage(9.0 * delta)
				cur_car.vel += (cur_car.global_position - v.global_position).normalized() * 6.0 * delta
	elif wanted > 0:
		for v in vehicles:
			if is_instance_valid(v) and v.mode == "police" and absf(v.spd) > 3.0 and v.global_position.distance_to(player.global_position) < 2.2 and game_t - last_hurt_t > 0.8:
				last_hurt_t = game_t
				player.hurt(14.0)
				hud.flash = 1.0

func traffic_manage(delta: float) -> void:
	vehicles = vehicles.filter(func(v): return is_instance_valid(v))
	peds = peds.filter(func(p): return is_instance_valid(p))
	var pp := player_pos()
	# police
	police_cd -= delta
	if police_cd <= 0.0:
		police_cd = 2.0
		var want_n: int = [0, 1, 2, 3, 4, 5][wanted]
		var cops := 0
		for v in vehicles:
			if v.mode == "police":
				cops += 1
				if wanted > 0 and v.global_position.distance_to(pp) > 260.0:
					v.queue_free()
		if wanted > 0 and cops < want_n:
			spawn_ai("police", true)
	# civilian traffic upkeep
	traffic_cd -= delta
	if traffic_cd <= 0.0:
		traffic_cd = 1.5
		var ai_n := 0
		var max_ai: int = [5, 8, 12, 16][quality]
		for v in vehicles:
			if v.mode == "ai":
				ai_n += 1
				if v.global_position.distance_to(pp) > 300.0:
					v.queue_free()
		if ai_n < max_ai:
			spawn_ai("ai")
		var civ_n := 0
		for p in peds:
			if p.kind == "civ" and not p.dead:
				civ_n += 1
		if civ_n < [10, 16, 22, 28][quality]:
			spawn_ped()

# ================================================================ death / respawn
func on_player_dead(kind: String) -> void:
	dead_t = 0.0
	hud.show_banner(kind, 3.4)
	if cur_car != null:
		exit_car(true)
	if m_active:
		fail_mission("You failed")

func respawn(fee: int) -> void:
	dead_t = -1.0
	money = maxi(0, money - fee)
	heat = 0.0
	wanted = 0
	player.health = 100.0
	player.armor = 0.0
	player.global_position = Cfg.ic(-3, -3)
	player.y = 0.0
	player.yv = 0.0
	for v in vehicles:
		if is_instance_valid(v) and v.mode == "police":
			v.mode = "ai"
	hud.toast("Hospital bill: $" + str(fee))

# ================================================================ missions
func make_marker() -> void:
	marker = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 2.2
	cm.bottom_radius = 2.2
	cm.height = 70.0
	cm.radial_segments = 16
	cm.rings = 1
	marker.mesh = cm
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mt.albedo_color = Color(1.0, 0.8, 0.1, 0.22)
	mt.cull_mode = BaseMaterial3D.CULL_DISABLED
	marker.material_override = mt
	marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	marker.visible = false
	add_child(marker)

func set_marker(pos: Vector3, col: Color, show := true) -> void:
	marker_pos = pos
	marker_col = col
	marker_on = show
	marker.visible = show
	marker.global_position = pos + Vector3(0, 35, 0)
	(marker.material_override as StandardMaterial3D).albedo_color = Color(col.r, col.g, col.b, 0.22)

func xz_dist(a: Vector3, b: Vector3) -> float:
	return Vector2(a.x - b.x, a.z - b.z).length()

func current_defs() -> Array:
	return Story.missions()

func update_mission(delta: float) -> void:
	start_arm = maxf(0.0, start_arm - delta)
	if not m_active:
		m_title = ""
		m_text = ""
		if hud.dialog_active():
			return
		var defs := current_defs()
		var nxt: Dictionary
		if chapter < defs.size():
			nxt = defs[chapter]
		else:
			story_done = true
			if courier_def.is_empty():
				courier_def = Story.courier()
			nxt = courier_def
		var sp: Vector3 = nxt["start"]
		set_marker(sp, Color(1.0, 0.8, 0.1) if chapter < defs.size() else Color(0.3, 0.8, 1.0))
		m_text = ("Next: " if chapter < defs.size() else "Job: ") + str(nxt["title"])
		m_title = "CHAPTER " + str(chapter + 1) if chapter < defs.size() else "FREE ROAM"
		var auto_start := chapter == 0 and game_t > 6.0
		if (xz_dist(player_pos(), sp) < 6.0 and start_arm <= 0.0) or auto_start:
			begin_mission(nxt)
		return
	m_step_t += delta
	if m_wait:
		return
	var s: Dictionary = m_def["steps"][m_step]
	var pp := player_pos()
	match s["t"]:
		"goto":
			var ok := xz_dist(pp, s["p"]) < 8.0
			if s.get("car", false):
				ok = ok and cur_car != null and cur_car == m_car
			if ok:
				next_step()
		"getcar":
			if cur_car != null and cur_car == m_car:
				next_step()
		"kill":
			var alive := 0
			for t in m_targets:
				if is_instance_valid(t) and not t.dead:
					alive += 1
			m_text = str(s["text"]) + " (" + str(alive) + " left)"
			if alive == 0:
				next_step()
		"wanted":
			if not m_wanted_set:
				m_wanted_set = true
				heat = maxf(heat, [0.0, 10.0, 32.0, 52.0, 72.0, 90.0][int(s["lv"])])
			elif wanted == 0 and m_step_t > 3.0:
				next_step()

func begin_mission(def: Dictionary) -> void:
	m_active = true
	m_def = def
	m_step = -1
	m_car = null
	m_targets.clear()
	set_marker(Vector3.ZERO, Color.WHITE, false)
	hud.toast(str(def["title"]))
	next_step()

func next_step() -> void:
	m_step += 1
	m_wanted_set = false
	m_step_t = 0.0
	if m_step >= m_def["steps"].size():
		complete_mission()
		return
	var s: Dictionary = m_def["steps"][m_step]
	m_title = str(m_def["title"])
	match s["t"]:
		"talk":
			m_wait = true
			m_text = ""
			set_marker(Vector3.ZERO, Color.WHITE, false)
			hud.show_dialog(s["lines"], _on_dialog_done)
		"goto":
			m_wait = false
			m_text = str(s["text"])
			set_marker(s["p"], Color(1.0, 0.8, 0.1))
		"getcar":
			m_wait = false
			m_text = str(s["text"])
			var v = spawn_vehicle(int(s["kind"]), s["color"], "parked", s["p"], float(s["yaw"]))
			v.mission_car = true
			m_car = v
			set_marker(s["p"], Color(0.3, 1.0, 0.4))
			if s.get("heat", 0) > 0:
				m_text += " (will raise your wanted level)"
		"kill":
			m_wait = false
			m_text = str(s["text"])
			set_marker(s["p"], Color(1.0, 0.2, 0.2))
			m_targets.clear()
			var n := int(s["n"])
			for i in range(n):
				var ax := randf() < 0.5
				var off := randf_range(9.0, 24.0) * (1.0 if randf() < 0.5 else -1.0)
				var pos: Vector3 = s["p"] + (Vector3(off, 0, randf_range(-3, 3)) if ax else Vector3(randf_range(-3, 3), 0, off))
				var p = spawn_ped(pos, "gun")
				p.mission_ped = false
				m_targets.append(p)
			if s.get("boss", false):
				var bp = spawn_ped(s["p"] + Vector3(0, 0, -6), "boss")
				m_targets.append(bp)
		"wanted":
			m_wait = false
			m_text = str(s["text"])
			set_marker(Vector3.ZERO, Color.WHITE, false)

func _on_dialog_done() -> void:
	m_wait = false
	next_step()

func complete_mission() -> void:
	var reward := int(m_def["reward"])
	money += reward
	hud.toast("MISSION COMPLETE  +$" + str(reward))
	hud.show_banner("MISSION PASSED", 3.0)
	if m_def.has("weapon"):
		weapons_owned[int(m_def["weapon"])] = true
	if m_car != null and is_instance_valid(m_car):
		m_car.mission_car = false
	if chapter < current_defs().size():
		chapter += 1
		if chapter >= current_defs().size() and not story_done:
			hud.toast("STORY COMPLETE - free roam unlocked")
	else:
		courier_def = Story.courier()
	player.armor = minf(100.0, player.armor + 25.0)
	m_active = false
	m_def = {}
	m_car = null
	m_targets.clear()
	start_arm = 8.0
	save_game()

func fail_mission(reason: String) -> void:
	hud.toast("MISSION FAILED: " + reason)
	m_active = false
	m_wait = false
	m_def = {}
	hud.dlg.clear()
	hud.dlg_i = 0
	for t in m_targets:
		if is_instance_valid(t):
			t.queue_free()
	m_targets.clear()
	m_car = null
	start_arm = 5.0

# ================================================================ save / load
func save_game() -> void:
	var cf := ConfigFile.new()
	cf.set_value("save", "money", money)
	cf.set_value("save", "chapter", chapter)
	cf.set_value("save", "smg", weapons_owned[1])
	cf.set_value("save", "quality", quality_mode)
	cf.set_value("save", "time", time_h)
	cf.save("user://save.cfg")

func load_game() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://save.cfg") != OK:
		return
	money = int(cf.get_value("save", "money", 500))
	chapter = int(cf.get_value("save", "chapter", 0))
	weapons_owned[1] = bool(cf.get_value("save", "smg", false))
	quality_mode = int(cf.get_value("save", "quality", 0))
	time_h = float(cf.get_value("save", "time", 17.0))
	if quality_mode > 0:
		apply_quality(quality_mode - 1 if quality_mode < 3 else 3)
	if chapter > 0:
		hud.title_t = 3.0
