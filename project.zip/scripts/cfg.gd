extends RefCounted
# Global constants and data tables.
# ---- update checker: compares this version with the latest GitHub release tag ----
# (the build workflow fills these in automatically from your repo and the git tag)
const VERSION_NAME := "v2.0"
const UPDATE_URL := "https://api.github.com/repos/Tasin202/IRON-HARBOR/releases/latest"
const REPO_URL := "https://github.com/Tasin202/IRON-HARBOR/releases"

const P := 80.0
const GRID := 4
const LANE := 4.0
# Traffic drives on the left side of the road (set false for right-hand traffic)
const LEFT_TRAFFIC := true

# Vehicle kinds: 0 sedan,1 sports,2 SUV,3 muscle,4 supercar,5 pickup,6 van,7 bus,10 tank,20 heli,21 police heli
const KINDS := {
	0: {"n": "Sedan", "max": 42.0, "acc": 16.0, "hp": 100.0, "price": 4000, "sz": Vector3(1.9, 1.3, 4.5), "wb": 2.7},
	1: {"n": "Veloce Sports", "max": 58.0, "acc": 23.0, "hp": 90.0, "price": 18000, "sz": Vector3(1.95, 1.2, 4.5), "wb": 2.6},
	2: {"n": "Ranger SUV", "max": 38.0, "acc": 14.0, "hp": 150.0, "price": 9000, "sz": Vector3(2.0, 1.8, 4.7), "wb": 2.9},
	3: {"n": "Bullet Muscle", "max": 52.0, "acc": 22.0, "hp": 120.0, "price": 14000, "sz": Vector3(2.0, 1.3, 4.9), "wb": 3.0},
	4: {"n": "Zenith Supercar", "max": 72.0, "acc": 32.0, "hp": 80.0, "price": 75000, "sz": Vector3(2.1, 1.1, 4.4), "wb": 2.7},
	5: {"n": "Hauler Pickup", "max": 40.0, "acc": 15.0, "hp": 140.0, "price": 7000, "sz": Vector3(2.0, 1.8, 5.3), "wb": 3.3},
	6: {"n": "Cargo Van", "max": 34.0, "acc": 11.0, "hp": 140.0, "price": 6000, "sz": Vector3(2.0, 2.4, 5.4), "wb": 3.4},
	7: {"n": "City Bus", "max": 26.0, "acc": 8.0, "hp": 280.0, "price": 0, "sz": Vector3(2.6, 3.2, 10.2), "wb": 6.6},
	10: {"n": "Rhino Tank", "max": 16.0, "acc": 7.0, "hp": 1000.0, "price": 40000, "sz": Vector3(3.5, 2.4, 7.0), "wb": 4.5},
	20: {"n": "Skylark Helicopter", "max": 46.0, "acc": 0.0, "hp": 420.0, "price": 20000, "sz": Vector3(2.6, 2.6, 8.0), "wb": 4.0},
	21: {"n": "Police Helicopter", "max": 42.0, "acc": 0.0, "hp": 380.0, "price": 0, "sz": Vector3(2.6, 2.6, 8.0), "wb": 4.0},
}

const WEAPONS := [
	{"n": "Pistol", "dmg": 34.0, "cd": 0.28, "pel": 1, "spread": 0.0, "price": 0},
	{"n": "SMG", "dmg": 17.0, "cd": 0.09, "pel": 1, "spread": 0.02, "price": 0},
	{"n": "Shotgun", "dmg": 15.0, "cd": 0.85, "pel": 8, "spread": 0.07, "price": 900},
	{"n": "Rifle", "dmg": 30.0, "cd": 0.11, "pel": 1, "spread": 0.012, "price": 2800},
	{"n": "RPG", "dmg": 0.0, "cd": 1.7, "pel": 0, "spread": 0.0, "price": 9500},
]

const OUTFITS := [
	{"n": "Street Kane", "shirt": Color(0.12, 0.14, 0.22), "pants": Color(0.16, 0.2, 0.3), "shoes": Color(0.1, 0.1, 0.1), "hair": Color(0.05, 0.04, 0.03), "sl": 0.0},
	{"n": "Biker", "shirt": Color(0.06, 0.06, 0.07), "pants": Color(0.1, 0.1, 0.12), "shoes": Color(0.05, 0.05, 0.05), "hair": Color(0.05, 0.04, 0.03), "sl": 1.0},
	{"n": "Sharp Suit", "shirt": Color(0.18, 0.18, 0.22), "pants": Color(0.16, 0.16, 0.2), "shoes": Color(0.04, 0.04, 0.04), "hair": Color(0.05, 0.04, 0.03), "sl": 1.0},
	{"n": "Red Hoodie", "shirt": Color(0.65, 0.1, 0.1), "pants": Color(0.12, 0.12, 0.14), "shoes": Color(0.9, 0.9, 0.9), "hair": Color(0.05, 0.04, 0.03), "sl": 1.0},
	{"n": "Tourist", "shirt": Color(0.9, 0.75, 0.2), "pants": Color(0.75, 0.7, 0.6), "shoes": Color(0.5, 0.35, 0.2), "hair": Color(0.15, 0.1, 0.05), "sl": 0.0},
	{"n": "Tactical", "shirt": Color(0.2, 0.25, 0.18), "pants": Color(0.22, 0.26, 0.2), "shoes": Color(0.06, 0.06, 0.05), "hair": Color(0.05, 0.04, 0.03), "sl": 1.0},
	{"n": "Neon Night", "shirt": Color(0.1, 0.8, 0.7), "pants": Color(0.35, 0.1, 0.5), "shoes": Color(0.95, 0.95, 0.2), "hair": Color(0.7, 0.1, 0.5), "sl": 0.0},
	{"n": "Gold Boss", "shirt": Color(0.85, 0.7, 0.25), "pants": Color(0.08, 0.08, 0.1), "shoes": Color(0.9, 0.8, 0.3), "hair": Color(0.7, 0.55, 0.1), "sl": 1.0},
]

# Shops: bi,bj = block that holds the shop building (door on its west face).
const SHOPS := [
	{"id": "ammu", "name": "AMMU-NATION", "bi": -1, "bj": 0, "col": Color(0.55, 0.12, 0.08)},
	{"id": "burger", "name": "BURGER SHOT", "bi": 1, "bj": -1, "col": Color(0.85, 0.35, 0.08)},
	{"id": "clothes", "name": "URBAN CLOTHES", "bi": -3, "bj": -1, "col": Color(0.2, 0.3, 0.55)},
	{"id": "dealer", "name": "PREMIER AUTO", "bi": 0, "bj": 1, "col": Color(0.15, 0.4, 0.2)},
	{"id": "apt", "name": "HARBOR HOMES", "bi": 2, "bj": 1, "col": Color(0.4, 0.3, 0.5)},
	{"id": "apt2", "name": "SKYLINE PENTHOUSE", "bi": -2, "bj": 2, "col": Color(0.55, 0.45, 0.2)},
]
const BASE_BLOCK := Vector2i(2, -4)

static func ki(k: int) -> Dictionary:
	if KINDS.has(k):
		return KINDS[k]
	return KINDS[0]

static func lane_off(d: Vector2) -> Vector2:
	var l := Vector2(d.y, -d.x)
	if LEFT_TRAFFIC:
		return l * LANE
	return -l * LANE

static func inb(n: Vector2i) -> bool:
	return absi(n.x) <= GRID and absi(n.y) <= GRID

static func yaw_of(d: Vector2) -> float:
	return atan2(-d.x, -d.y)

static func ic(i: int, j: int) -> Vector3:
	return Vector3(i * P + 9.5, 0.0, j * P + 9.5)

static func nd(i: int, j: int) -> Vector3:
	return Vector3(i * P, 0.0, j * P)

static func shop_door(i: int) -> Vector3:
	var s: Dictionary = SHOPS[i]
	var ox: float = s["bi"] * P + 11.0
	var oz: float = s["bj"] * P + 11.0
	var S := P - 22.0
	# marker on the sidewalk in front of the west-face door
	return Vector3(s["bi"] * P + 10.0, 0.0, oz + S * 0.5 - 14.5)
