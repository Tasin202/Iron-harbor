extends RefCounted
# Global city constants. Roads run along multiples of P on both axes.
const P := 80.0
const GRID := 4
const LANE := 4.0
# Traffic drives on the left side of the road (set false for right-hand traffic)
const LEFT_TRAFFIC := true

static func lane_off(d: Vector2) -> Vector2:
	var l := Vector2(d.y, -d.x)
	if LEFT_TRAFFIC:
		return l * LANE
	return -l * LANE

static func inb(n: Vector2i) -> bool:
	return absi(n.x) <= GRID and absi(n.y) <= GRID

static func yaw_of(d: Vector2) -> float:
	return atan2(-d.x, -d.y)

static func ic(i: int, j: int) -> Vector3:
	return Vector3(i * P + 9.5, 0.0, j * P + 9.5)

static func nd(i: int, j: int) -> Vector3:
	return Vector3(i * P, 0.0, j * P)
