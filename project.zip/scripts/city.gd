extends RefCounted
# City builder: ground, water, buildings with detail, shops, military base, traffic lights, props.
const Cfg = preload("res://scripts/cfg.gd")
const Sh = preload("res://scripts/shaders.gd")

static func _label(parent: Node, text: String, pos: Vector3, yaw: float, col: Color, px := 0.03) -> void:
	var l := Label3D.new()
	l.text = text
	l.pixel_size = px
	l.font_size = 64
	l.modulate = col
	l.outline_size = 10
	l.outline_modulate = Color(0, 0, 0, 1)
	l.position = pos
	l.rotation.y = yaw
	parent.add_child(l)

static func build(m) -> void:
	m.prog(0.08, "Laying asphalt and water...")
	var P := Cfg.P
	# ground
	var ground := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(780, 780)
	ground.mesh = pm
	m.mat_ground = ShaderMaterial.new()
	m.mat_ground.shader = Sh.get_shader("ground")
	ground.material_override = m.mat_ground
	ground.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	m.add_child(ground)
	# water
	var water := MeshInstance3D.new()
	var wm := PlaneMesh.new()
	wm.size = Vector2(2600, 2600)
	wm.subdivide_width = 40
	wm.subdivide_depth = 40
	water.mesh = wm
	water.position.y = -1.4
	m.mat_water = ShaderMaterial.new()
	m.mat_water.shader = Sh.get_shader("water")
	water.material_override = m.mat_water
	water.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	m.add_child(water)
	# static collision body for everything solid
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	m.add_child(body)
	m.world_body = body
	var wall_mat := StandardMaterial3D.new()
	wall_mat.albedo_color = Color(0.5, 0.5, 0.5)
	for side in [[Vector3(0, 0.8, -388), Vector3(780, 1.6, 2)], [Vector3(0, 0.8, 388), Vector3(780, 1.6, 2)], [Vector3(-388, 0.8, 0), Vector3(2, 1.6, 780)], [Vector3(388, 0.8, 0), Vector3(2, 1.6, 780)]]:
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = side[1] + Vector3(0, 6, 0)
		cs.shape = bs
		cs.position = side[0]
		body.add_child(cs)
		var wmi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = side[1]
		wmi.mesh = bm
		wmi.position = side[0]
		wmi.material_override = wall_mat
		m.add_child(wmi)
	m.mat_build = ShaderMaterial.new()
	m.mat_build.shader = Sh.get_shader("building")
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261024
	var pal := [Color(0.62, 0.58, 0.52), Color(0.48, 0.5, 0.55), Color(0.7, 0.66, 0.6), Color(0.58, 0.4, 0.34), Color(0.42, 0.45, 0.48), Color(0.75, 0.72, 0.68), Color(0.36, 0.4, 0.46), Color(0.62, 0.54, 0.42)]
	var awn_pal := [Color(0.8, 0.15, 0.15), Color(0.15, 0.4, 0.75), Color(0.15, 0.6, 0.3), Color(0.85, 0.6, 0.1), Color(0.5, 0.2, 0.6), Color(0.9, 0.9, 0.85)]
	var neon_pal := [Color(1.0, 0.2, 0.5), Color(0.2, 0.9, 1.0), Color(1.0, 0.8, 0.1), Color(0.3, 1.0, 0.4), Color(0.9, 0.3, 1.0)]
	var bx: Array = []
	var bc: Array = []
	var dx: Array = []   # detail boxes (vertex colored, lit)
	var dc: Array = []
	var nx: Array = []   # neon (emissive at night)
	var nc: Array = []
	var tree_pos: Array = []
	var shop_blocks := {}
	for i in range(Cfg.SHOPS.size()):
		shop_blocks[Vector2i(Cfg.SHOPS[i]["bi"], Cfg.SHOPS[i]["bj"])] = i
	var park_mat := StandardMaterial3D.new()
	park_mat.albedo_color = Color(0.18, 0.38, 0.16)
	park_mat.roughness = 1.0
	m.prog(0.12, "Raising the skyline...")
	await m.get_tree().process_frame
	for bi in range(-Cfg.GRID, Cfg.GRID):
		for bj in range(-Cfg.GRID, Cfg.GRID):
			var S := P - 22.0
			var ox := bi * P + 11.0
			var oz := bj * P + 11.0
			var cx := ox + S * 0.5
			var cz := oz + S * 0.5
			var key := Vector2i(bi, bj)
			var zone := clampf(1.0 - Vector2(cx, cz).length() / 330.0, 0.0, 1.0)
			var r := rng.randf()
			if key == Cfg.BASE_BLOCK:
				_military_base(m, body, cx, cz, S)
				continue
			if r < 0.11 and (bi != 0 or bj != 0) and not shop_blocks.has(key):
				var pk := MeshInstance3D.new()
				var ppm := PlaneMesh.new()
				ppm.size = Vector2(S, S)
				pk.mesh = ppm
				pk.position = Vector3(cx, 0.03, cz)
				pk.material_override = park_mat
				pk.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
				m.add_child(pk)
				for t in range(26):
					tree_pos.append(Vector3(cx + rng.randf_range(-S * 0.45, S * 0.45), 0, cz + rng.randf_range(-S * 0.45, S * 0.45)))
				continue
			var lots: Array = []
			var force_split = shop_blocks.has(key)
			if rng.randf() < 0.3 and not force_split:
				lots.append([cx, cz, S - 2.0, S - 2.0, false])
			else:
				var hs := S * 0.5
				var first := true
				for a in [-1, 1]:
					for b in [-1, 1]:
						lots.append([cx + a * hs * 0.5, cz + b * hs * 0.5, hs - 3.0, hs - 3.0, force_split and a == -1 and b == -1])
			for lot in lots:
				var is_shop: bool = lot[4]
				var w: float = lot[2] - (0.0 if is_shop else rng.randf_range(0.0, 3.0))
				var d: float = lot[3] - (0.0 if is_shop else rng.randf_range(0.0, 3.0))
				var h := rng.randf_range(8.0, 26.0) + zone * zone * rng.randf() * 85.0
				if lot[2] > 40.0:
					h = rng.randf_range(9.0, 16.0) + zone * 20.0
				var col: Color = pal[rng.randi() % pal.size()]
				col = col.lightened(rng.randf_range(-0.1, 0.1))
				if is_shop:
					var sd: Dictionary = Cfg.SHOPS[shop_blocks[key]]
					h = 8.0
					col = sd["col"]
				bx.append(Transform3D(Basis.from_scale(Vector3(w, h, d)), Vector3(lot[0], h * 0.5, lot[1])))
				bc.append(col)
				var cs2 := CollisionShape3D.new()
				var bs2 := BoxShape3D.new()
				bs2.size = Vector3(w, h, d)
				cs2.shape = bs2
				cs2.position = Vector3(lot[0], h * 0.5, lot[1])
				body.add_child(cs2)
				# roof details
				for k in range(rng.randi_range(1, 3)):
					var rw := rng.randf_range(1.8, 4.0)
					var rh := rng.randf_range(1.0, 2.2)
					dx.append(Transform3D(Basis.from_scale(Vector3(rw, rh, rw * rng.randf_range(0.7, 1.4))), Vector3(lot[0] + rng.randf_range(-w * 0.3, w * 0.3), h + rh * 0.5, lot[1] + rng.randf_range(-d * 0.3, d * 0.3))))
					dc.append(Color(0.45, 0.46, 0.48))
				# cornice ledge
				dx.append(Transform3D(Basis.from_scale(Vector3(w + 0.8, 0.5, d + 0.8)), Vector3(lot[0], h + 0.15, lot[1])))
				dc.append(col.darkened(0.25))
				# awnings and signs on road-facing sides
				var faces := []
				if lot[0] < cx or lot[2] > 40.0:
					faces.append(Vector3(-1, 0, 0))
				if lot[0] > cx or lot[2] > 40.0:
					faces.append(Vector3(1, 0, 0))
				if lot[1] < cz or lot[2] > 40.0:
					faces.append(Vector3(0, 0, -1))
				if lot[1] > cz or lot[2] > 40.0:
					faces.append(Vector3(0, 0, 1))
				for fd in faces:
					var along: Vector3 = Vector3(fd.z, 0, fd.x)
					var half = (w if absf(fd.x) > 0.5 else d) * 0.5
					var depth = (d if absf(fd.x) > 0.5 else w) * 0.5
					var base = Vector3(lot[0], 0, lot[1]) + fd * (depth if absf(fd.x) < 0.5 else half)
					if absf(fd.x) > 0.5:
						base = Vector3(lot[0], 0, lot[1]) + fd * (w * 0.5)
					else:
						base = Vector3(lot[0], 0, lot[1]) + fd * (d * 0.5)
					var span = (d if absf(fd.x) > 0.5 else w)
					var aw_col: Color = awn_pal[rng.randi() % awn_pal.size()]
					var sx = span * 0.8 if absf(fd.x) < 0.5 else 1.5
					var sz = 1.5 if absf(fd.x) < 0.5 else span * 0.8
					dx.append(Transform3D(Basis.from_scale(Vector3(sx, 0.18, sz)), base + fd * 0.75 + Vector3(0, 3.5, 0)))
					dc.append(aw_col)
					if zone > 0.25 and rng.randf() < 0.55 and not is_shop:
						var nc_col: Color = neon_pal[rng.randi() % neon_pal.size()]
						var nsx = span * 0.5 if absf(fd.x) < 0.5 else 0.25
						var nsz = 0.25 if absf(fd.x) < 0.5 else span * 0.5
						nx.append(Transform3D(Basis.from_scale(Vector3(nsx, 0.9, nsz)), base + fd * 0.2 + Vector3(0, 5.4, 0)))
						nc.append(nc_col)
				if is_shop:
					var sidx: int = shop_blocks[key]
					var sd2: Dictionary = Cfg.SHOPS[sidx]
					var face_x: float = lot[0] - w * 0.5
					var door_z: float = lot[1]
					var door_mat := Color(0.06, 0.06, 0.08)
					dx.append(Transform3D(Basis.from_scale(Vector3(0.4, 3.0, 3.4)), Vector3(face_x - 0.1, 1.5, door_z)))
					dc.append(door_mat)
					nx.append(Transform3D(Basis.from_scale(Vector3(0.3, 2.4, 8.0)), Vector3(face_x - 0.1, 1.7, door_z + 7.0)))
					nc.append(Color(0.5, 0.8, 1.0))
					nx.append(Transform3D(Basis.from_scale(Vector3(0.3, 2.4, 8.0)), Vector3(face_x - 0.1, 1.7, door_z - 7.0)))
					nc.append(Color(0.5, 0.8, 1.0))
					nx.append(Transform3D(Basis.from_scale(Vector3(0.5, 1.4, 12.0)), Vector3(face_x - 0.15, 6.2, door_z)))
					nc.append(sd2["col"].lightened(0.35))
					_label(m, sd2["name"], Vector3(face_x - 0.45, 6.2, door_z), -PI * 0.5, Color(1, 1, 1), 0.04)
				if h > 38.0:
					var h2 := h * 0.28
					bx.append(Transform3D(Basis.from_scale(Vector3(w * 0.62, h2, d * 0.62)), Vector3(lot[0], h + h2 * 0.5, lot[1])))
					bc.append(col.darkened(0.12))
					bx.append(Transform3D(Basis.from_scale(Vector3(0.5, 14.0, 0.5)), Vector3(lot[0], h + h2 + 7.0, lot[1])))
					bc.append(Color(0.3, 0.3, 0.32))
	m.mm_inst(BoxMesh.new(), m.mat_build, bx, bc)
	var dmat := StandardMaterial3D.new()
	dmat.vertex_color_use_as_albedo = true
	dmat.roughness = 0.8
	m.mm_inst(BoxMesh.new(), dmat, dx, dc)
	m.mat_neon = ShaderMaterial.new()
	m.mat_neon.shader = Sh.get_shader("lights")
	m.mm_inst(BoxMesh.new(), m.mat_neon, nx, nc, false)
	m.prog(0.42, "Stacking containers at the harbor...")
	await m.get_tree().process_frame
	# harbor apron containers and cranes
	var cont_x: Array = []
	var cont_c: Array = []
	for i in range(34):
		var px := rng.randf_range(-300.0, 300.0)
		var pz := rng.randf_range(340.0, 372.0)
		var stack := rng.randi_range(1, 3)
		var cc := Color.from_hsv(rng.randf(), 0.55, 0.65)
		var ang := 0.0 if rng.randf() < 0.5 else PI * 0.5
		for sidx2 in range(stack):
			cont_x.append(Transform3D(Basis(Vector3.UP, ang) * Basis.from_scale(Vector3(6.0, 2.6, 2.4)), Vector3(px, 1.3 + sidx2 * 2.6, pz)))
			cont_c.append(cc)
		var ccs := CollisionShape3D.new()
		var cbs := BoxShape3D.new()
		cbs.size = Vector3(6.0 if ang == 0.0 else 2.4, 2.6 * stack, 2.4 if ang == 0.0 else 6.0)
		ccs.shape = cbs
		ccs.position = Vector3(px, 1.3 * stack, pz)
		body.add_child(ccs)
	var cmat := StandardMaterial3D.new()
	cmat.vertex_color_use_as_albedo = true
	cmat.roughness = 0.6
	cmat.metallic = 0.3
	m.mm_inst(BoxMesh.new(), cmat, cont_x, cont_c)
	var crane_mat := StandardMaterial3D.new()
	crane_mat.albedo_color = Color(0.8, 0.25, 0.1)
	for cxp in [-130.0, 60.0, 210.0]:
		for lx in [-9.0, 9.0]:
			var leg := MeshInstance3D.new()
			var lm := BoxMesh.new()
			lm.size = Vector3(1.4, 34.0, 1.4)
			leg.mesh = lm
			leg.position = Vector3(cxp + lx, 17.0, 378.0)
			leg.material_override = crane_mat
			m.add_child(leg)
		var beam := MeshInstance3D.new()
		var bmm := BoxMesh.new()
		bmm.size = Vector3(22.0, 2.0, 2.0)
		beam.mesh = bmm
		beam.position = Vector3(cxp, 34.0, 378.0)
		beam.material_override = crane_mat
		m.add_child(beam)
		var arm := MeshInstance3D.new()
		var am := BoxMesh.new()
		am.size = Vector3(2.0, 2.0, 60.0)
		arm.mesh = am
		arm.position = Vector3(cxp, 35.0, 356.0)
		arm.material_override = crane_mat
		m.add_child(arm)
	m.prog(0.5, "Planting trees...")
	await m.get_tree().process_frame
	# street trees
	var step := 24.0
	for li in range(-Cfg.GRID, Cfg.GRID + 1):
		var t := -312.0
		while t <= 312.0:
			if absf(fposmod(t + P * 0.5, P) - P * 0.5) > 15.0 and rng.randf() < 0.5:
				var sd3 := 10.2 if rng.randf() < 0.5 else -10.2
				tree_pos.append(Vector3(li * P + sd3, 0, t))
				tree_pos.append(Vector3(t, 0, li * P + sd3))
			t += step
	var tx: Array = []
	var cx_: Array = []
	var cc2: Array = []
	for tp in tree_pos:
		var sc := rng.randf_range(0.8, 1.35)
		tx.append(Transform3D(Basis.from_scale(Vector3(0.35, 2.4 * sc, 0.35)), tp + Vector3(0, 1.2 * sc, 0)))
		cx_.append(Transform3D(Basis.from_scale(Vector3(2.0 * sc, 2.0 * sc, 2.0 * sc)), tp + Vector3(0, 3.6 * sc, 0)))
		cc2.append(Color.from_hsv(rng.randf_range(0.22, 0.34), rng.randf_range(0.5, 0.75), rng.randf_range(0.35, 0.6)))
	var trunk_mat := StandardMaterial3D.new()
	trunk_mat.albedo_color = Color(0.25, 0.17, 0.1)
	var crown_mat := StandardMaterial3D.new()
	crown_mat.vertex_color_use_as_albedo = true
	crown_mat.roughness = 1.0
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.6
	cyl.bottom_radius = 0.8
	cyl.height = 1.0
	cyl.radial_segments = 6
	cyl.rings = 1
	var sph := SphereMesh.new()
	sph.radius = 1.0
	sph.height = 2.0
	sph.radial_segments = 8
	sph.rings = 5
	m.mm_inst(cyl, trunk_mat, tx, [])
	m.mm_inst(sph, crown_mat, cx_, cc2)
	# street lamps
	var lx_: Array = []
	var lh_: Array = []
	var lt := -300.0
	while lt <= 300.0:
		if absf(fposmod(lt + P * 0.5, P) - P * 0.5) > 14.0:
			for li2 in range(-Cfg.GRID, Cfg.GRID + 1):
				var sd2 := 8.7 if int(lt / 40.0 + li2) % 2 == 0 else -8.7
				lx_.append(Transform3D(Basis.IDENTITY, Vector3(li2 * P + sd2, 3.7, lt)))
				lh_.append(Transform3D(Basis.IDENTITY, Vector3(li2 * P + sd2 - signf(sd2) * 0.8, 7.5, lt)))
				lx_.append(Transform3D(Basis.IDENTITY, Vector3(lt, 3.7, li2 * P + sd2)))
				lh_.append(Transform3D(Basis.IDENTITY, Vector3(lt, 7.5, li2 * P + sd2 - signf(sd2) * 0.8)))
		lt += 40.0
	var pole := CylinderMesh.new()
	pole.top_radius = 0.07
	pole.bottom_radius = 0.1
	pole.height = 7.4
	pole.radial_segments = 6
	pole.rings = 1
	var pole_mat := StandardMaterial3D.new()
	pole_mat.albedo_color = Color(0.12, 0.13, 0.15)
	m.mm_inst(pole, pole_mat, lx_, [], false)
	var lamp_m := BoxMesh.new()
	lamp_m.size = Vector3(0.7, 0.14, 0.4)
	m.lamp_mat = StandardMaterial3D.new()
	m.lamp_mat.albedo_color = Color(1.0, 0.9, 0.6)
	m.lamp_mat.emission_enabled = true
	m.lamp_mat.emission = Color(1.0, 0.8, 0.45)
	m.lamp_mat.emission_energy_multiplier = 0.0
	m.mm_inst(lamp_m, m.lamp_mat, lh_, [], false)
	m.prog(0.56, "Wiring up the traffic lights...")
	await m.get_tree().process_frame
	# traffic lights: pole + black housing + colored lamp at every intersection corner
	var tp_x: Array = []
	var th_x: Array = []
	var tl_x: Array = []
	var tl_axis: Array = []
	for i in range(-Cfg.GRID, Cfg.GRID + 1):
		for j in range(-Cfg.GRID, Cfg.GRID + 1):
			var cxn := i * P
			var czn := j * P
			var k := 0
			for sx in [-1.0, 1.0]:
				for sz2 in [-1.0, 1.0]:
					var px2 = cxn + sx * 9.6
					var pz2 = czn + sz2 * 9.6
					tp_x.append(Transform3D(Basis.from_scale(Vector3(1, 0.75, 1)), Vector3(px2, 2.8, pz2)))
					th_x.append(Transform3D(Basis.from_scale(Vector3(0.4, 1.0, 0.4)), Vector3(px2, 5.6, pz2)))
					tl_x.append(Transform3D(Basis.from_scale(Vector3(0.3, 0.3, 0.3)), Vector3(px2, 5.95, pz2)))
					# diagonal corners share an axis
					tl_axis.append(1 if (sx * sz2) > 0.0 else 0)
					k += 1
	m.mm_inst(pole, pole_mat, tp_x, [], false)
	var hbox := BoxMesh.new()
	m.mm_inst(hbox, pole_mat, th_x, [], false)
	var lbox := BoxMesh.new()
	m.sig_axis = tl_axis
	var cols0: Array = []
	for q in range(tl_x.size()):
		cols0.append(Color(1, 0.1, 0.1))
	m.sig_mm = m.mm_inst(lbox, m.mat_sig_lights(), tl_x, cols0, false)
	# street props
	var bench_x: Array = []
	var bench_c: Array = []
	var bin_x: Array = []
	var bin_c: Array = []
	for n in range(260):
		var line := rng.randi_range(-Cfg.GRID, Cfg.GRID - 1)
		var tpos := rng.randf_range(-300.0, 300.0)
		if absf(fposmod(tpos + P * 0.5, P) - P * 0.5) < 14.0:
			continue
		var ax := rng.randf() < 0.5
		var sd4 := 10.8
		var base2 := Vector3(line * P + P * 0.5 + (sd4 - P * 0.5 if rng.randf() < 0.5 else -(sd4 - P * 0.5)), 0, tpos)
		# put props along the building edge of a block (offset from road line by ~10.8 m)
		var px3 := line * P + (10.8 if rng.randf() < 0.5 else P - 10.8)
		var pos3 := Vector3(px3, 0, tpos) if ax else Vector3(tpos, 0, px3)
		var yaw := 0.0 if ax else PI * 0.5
		var t2 := rng.randi_range(0, 3)
		if t2 == 0:
			bench_x.append(Transform3D(Basis(Vector3.UP, yaw) * Basis.from_scale(Vector3(0.5, 0.45, 1.8)), pos3 + Vector3(0, 0.25, 0)))
			bench_c.append(Color(0.35, 0.22, 0.12))
		elif t2 == 1:
			bench_x.append(Transform3D(Basis(Vector3.UP, yaw) * Basis.from_scale(Vector3(1.0, 1.3, 2.4)), pos3 + Vector3(0, 0.7, 0)))
			bench_c.append(Color(0.1, 0.35, 0.18))
		elif t2 == 2:
			bin_x.append(Transform3D(Basis.from_scale(Vector3(0.5, 0.9, 0.5)), pos3 + Vector3(0, 0.45, 0)))
			bin_c.append(Color(0.2, 0.22, 0.25))
		else:
			bin_x.append(Transform3D(Basis.from_scale(Vector3(0.35, 0.8, 0.35)), pos3 + Vector3(0, 0.4, 0)))
			bin_c.append(Color(0.75, 0.1, 0.1))
	var prop_mat := StandardMaterial3D.new()
	prop_mat.vertex_color_use_as_albedo = true
	prop_mat.roughness = 0.8
	m.mm_inst(BoxMesh.new(), prop_mat, bench_x, bench_c, false)
	var pcyl := CylinderMesh.new()
	pcyl.top_radius = 0.5
	pcyl.bottom_radius = 0.5
	pcyl.height = 1.0
	pcyl.radial_segments = 8
	pcyl.rings = 1
	m.mm_inst(pcyl, prop_mat, bin_x, bin_c, false)

static func _military_base(m, body: StaticBody3D, cx: float, cz: float, S: float) -> void:
	var half := S * 0.5
	var fence_mat := StandardMaterial3D.new()
	fence_mat.albedo_color = Color(0.3, 0.32, 0.3)
	fence_mat.metallic = 0.5
	var gate := 12.0
	var segs := [
		[Vector3(cx, 1.5, cz - half), Vector3(S, 3.0, 0.6)],
		[Vector3(cx - half, 1.5, cz), Vector3(0.6, 3.0, S)],
		[Vector3(cx + half, 1.5, cz), Vector3(0.6, 3.0, S)],
		[Vector3(cx - (half + gate * 0.5) * 0.5, 1.5, cz + half), Vector3(half - gate * 0.5, 3.0, 0.6)],
		[Vector3(cx + (half + gate * 0.5) * 0.5, 1.5, cz + half), Vector3(half - gate * 0.5, 3.0, 0.6)],
	]
	for sg in segs:
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = sg[1]
		cs.shape = bs
		cs.position = sg[0]
		body.add_child(cs)
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = sg[1]
		mi.mesh = bm
		mi.position = sg[0]
		mi.material_override = fence_mat
		m.add_child(mi)
	var hang := MeshInstance3D.new()
	var hm := BoxMesh.new()
	hm.size = Vector3(26, 9, 14)
	hang.mesh = hm
	hang.position = Vector3(cx, 4.5, cz - half + 12)
	var hm_mat := StandardMaterial3D.new()
	hm_mat.albedo_color = Color(0.32, 0.36, 0.28)
	hang.material_override = hm_mat
	m.add_child(hang)
	var hcs := CollisionShape3D.new()
	var hbs := BoxShape3D.new()
	hbs.size = Vector3(26, 9, 14)
	hcs.shape = hbs
	hcs.position = hang.position
	body.add_child(hcs)
	_label(m, "FORT HARBOR - RESTRICTED", Vector3(cx, 4.5, cz + half - 0.6), PI, Color(1, 0.2, 0.2), 0.05)
	m.base_rect = Rect2(cx - half, cz - half, S, S)
	m.base_gate = Vector3(cx, 0, cz + half + 6.0)
