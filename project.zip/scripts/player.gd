extends CharacterBody3D
# The on-foot player character.
const Cfg = preload("res://scripts/cfg.gd")
const Models = preload("res://scripts/models.gd")
const Sh = preload("res://scripts/shaders.gd")

var main
var health := 100.0
var armor := 0.0
var y := 0.0
var yv := 0.0
var mat: ShaderMaterial
var mi: MeshInstance3D
var last_walk := -1.0
var aim_v := 0.0
var outfit := 0

func setup(m) -> void:
	main = m
	collision_layer = 8
	collision_mask = 1 | 2 | 4
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
	mi = MeshInstance3D.new()
	mi.mesh = Models.ped_mesh(true)
	mat = ShaderMaterial.new()
	mat.shader = Sh.get_shader("ped")
	mat.set_shader_parameter("skin", Color(0.72, 0.52, 0.4))
	mat.set_shader_parameter("speed", 9.0)
	mat.set_shader_parameter("aim", 0.0)
	mi.material_override = mat
	add_child(mi)
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.34
	cap.height = 1.75
	cs.shape = cap
	cs.position.y = 0.88
	add_child(cs)
	set_outfit(0)

func set_outfit(i: int) -> void:
	outfit = clampi(i, 0, Cfg.OUTFITS.size() - 1)
	var o: Dictionary = Cfg.OUTFITS[outfit]
	mat.set_shader_parameter("shirt", o["shirt"])
	mat.set_shader_parameter("pants", o["pants"])
	mat.set_shader_parameter("shoes", o["shoes"])
	mat.set_shader_parameter("hair", o["hair"])
	mat.set_shader_parameter("sleeves", o["sl"])

func set_walk(v: float) -> void:
	if absf(v - last_walk) > 0.05:
		last_walk = v
		mat.set_shader_parameter("walk", v)

func step(delta: float, mv: Vector2, cam_yaw: float, aiming: bool, jump: bool) -> void:
	var fwd := Vector3(-sin(cam_yaw), 0, -cos(cam_yaw))
	var right := Vector3(cos(cam_yaw), 0, -sin(cam_yaw))
	var wish := right * mv.x + fwd * mv.y
	var m := minf(wish.length(), 1.0)
	var spd = 2.4 + 3.6 * clampf((m - 0.5) * 2.0, 0.0, 1.0)
	if m > 0.06:
		velocity = wish.normalized() * spd * minf(1.0, m * 1.4)
	else:
		velocity = Vector3.ZERO
	var target := rotation.y
	if aiming:
		target = cam_yaw
	elif m > 0.1:
		target = atan2(-wish.x, -wish.z)
	rotation.y = lerp_angle(rotation.y, target, minf(1.0, 12.0 * delta))
	if jump and y <= 0.001:
		yv = 5.2
	yv -= 15.0 * delta
	y += yv * delta
	if y < 0.0:
		y = 0.0
		yv = 0.0
	move_and_slide()
	global_position.y = y
	set_walk(clampf(m * 1.3, 0.0, 1.0) if y <= 0.01 else 0.3)
	mat.set_shader_parameter("speed", 5.0 + spd * 1.3)
	aim_v = move_toward(aim_v, 1.0 if aiming else 0.0, delta * 6.0)
	mat.set_shader_parameter("aim", aim_v)

func hurt(dmg: float) -> void:
	if armor > 0.0:
		var a := minf(armor, dmg * 0.6)
		armor -= a
		dmg -= a
	health -= dmg
