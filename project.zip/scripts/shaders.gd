extends RefCounted

const GROUND := """
shader_type spatial;
varying vec3 wp;
float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void vertex(){ wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment(){
	float P = 80.0;
	vec2 p = wp.xz;
	vec2 u = mod(p + P * 0.5, P) - P * 0.5;
	vec2 d = abs(u);
	bool rx = d.x < 8.0;
	bool rz = d.y < 8.0;
	vec3 col;
	float rough = 0.9;
	float n = h21(floor(p * 1.5)) * 0.05;
	if (rx || rz) {
		col = vec3(0.075 + n);
		rough = 0.7;
		vec3 yel = vec3(0.85, 0.62, 0.08);
		vec3 wht = vec3(0.78);
		if (rx && !rz) {
			if (d.x > 0.12 && d.x < 0.38) col = yel;
			if (abs(d.x - 7.5) < 0.09) col = wht;
			if (d.y > 8.8 && d.y < 11.5 && fract(p.x * 0.7) < 0.5 && d.x > 0.8 && d.x < 7.2) col = wht;
		} else if (rz && !rx) {
			if (d.y > 0.12 && d.y < 0.38) col = yel;
			if (abs(d.y - 7.5) < 0.09) col = wht;
			if (d.x > 8.8 && d.x < 11.5 && fract(p.y * 0.7) < 0.5 && d.y > 0.8 && d.y < 7.2) col = wht;
		}
	} else if (d.x < 11.0 || d.y < 11.0) {
		vec2 g = fract(p / 1.6);
		float line = step(g.x, 0.03) + step(g.y, 0.03);
		col = vec3(0.45 + n) - line * 0.08;
		rough = 0.85;
	} else {
		col = vec3(0.30, 0.30, 0.29) + n;
	}
	ALBEDO = col;
	ROUGHNESS = rough;
	SPECULAR = 0.3;
}
"""

const BUILDING := """
shader_type spatial;
uniform float night = 0.0;
varying vec3 wp;
varying vec3 wn;
varying vec3 icol;
float h21(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
void vertex(){
	wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	wn = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
	icol = COLOR.rgb;
}
void fragment(){
	vec3 alb = icol;
	vec3 em = vec3(0.0);
	float rough = 0.85;
	float met = 0.0;
	if (abs(wn.y) < 0.5) {
		float along = abs(wn.x) > 0.5 ? wp.z : wp.x;
		vec2 g = vec2(along / 3.0, wp.y / 3.6);
		vec2 cell = floor(g);
		vec2 f = fract(g);
		float win = step(0.16, f.x) * step(f.x, 0.84) * step(0.22, f.y) * step(f.y, 0.78);
		if (wp.y < 3.6) win = 0.0;
		float seed = h21(cell + floor(icol.rg * 97.0));
		float lit = step(0.5, seed) * step(0.3, h21(cell * 1.7 + 3.0));
		vec3 glass = mix(vec3(0.06, 0.09, 0.13), vec3(0.16, 0.22, 0.28), seed);
		alb = mix(alb, glass, win);
		rough = mix(0.85, 0.12, win);
		met = win * 0.4;
		em = win * lit * night * vec3(1.0, 0.8, 0.5) * 1.3;
		float slab = step(f.y, 0.07) * (1.0 - win);
		alb *= 1.0 - slab * 0.25;
		if (wp.y < 3.6) alb *= 0.8;
	} else if (wn.y > 0.5) {
		alb *= 0.55;
	}
	ALBEDO = alb;
	ROUGHNESS = rough;
	METALLIC = met;
	EMISSION = em;
}
"""

const WATER := """
shader_type spatial;
uniform float night = 0.0;
varying vec3 wp;
void vertex(){
	wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	VERTEX.y += sin(wp.x * 0.15 + TIME * 0.8) * 0.12 + sin(wp.z * 0.11 + TIME * 0.6) * 0.1;
}
void fragment(){
	vec3 deep = mix(vec3(0.03, 0.16, 0.24), vec3(0.01, 0.03, 0.06), night);
	float f = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 3.0);
	ALBEDO = deep + f * 0.15;
	ROUGHNESS = 0.08;
	SPECULAR = 0.8;
	METALLIC = 0.2;
}
"""

const PED := """
shader_type spatial;
uniform vec3 skin : source_color = vec3(0.8, 0.6, 0.48);
uniform vec3 shirt : source_color = vec3(0.2, 0.3, 0.5);
uniform vec3 pants : source_color = vec3(0.1, 0.1, 0.15);
uniform float walk = 1.0;
uniform float phase = 0.0;
uniform float speed = 7.0;
varying float vpart;
void vertex(){
	vpart = UV.x;
	float p = UV.x;
	float s = sin(TIME * speed + phase) * walk;
	float ang = 0.0;
	vec3 piv = vec3(0.0, 0.92, 0.0);
	if (p > 3.5 && p < 4.5) { ang = s * 0.7; }
	else if (p > 4.5 && p < 5.5) { ang = -s * 0.7; }
	else if (p > 1.5 && p < 2.5) { ang = -s * 0.6; piv.y = 1.42; }
	else if (p > 2.5 && p < 3.5) { ang = s * 0.6; piv.y = 1.42; }
	float c = cos(ang);
	float sn = sin(ang);
	vec3 v = VERTEX - piv;
	VERTEX = piv + vec3(v.x, v.y * c - v.z * sn, v.y * sn + v.z * c);
	NORMAL = vec3(NORMAL.x, NORMAL.y * c - NORMAL.z * sn, NORMAL.y * sn + NORMAL.z * c);
}
void fragment(){
	vec3 col = skin;
	if (vpart > 0.5 && vpart < 3.5) { col = shirt; }
	else if (vpart > 3.5 && vpart < 5.5) { col = pants; }
	else if (vpart > 5.5) { col = vec3(0.04); }
	ALBEDO = col;
	ROUGHNESS = 0.85;
}
"""

const LIGHTS := """
shader_type spatial;
uniform float glow = 0.8;
void fragment(){
	ALBEDO = COLOR.rgb;
	EMISSION = COLOR.rgb * glow;
}
"""

static var _s := {}

static func get_shader(key: String) -> Shader:
	if _s.has(key):
		return _s[key]
	var sh := Shader.new()
	match key:
		"ground": sh.code = GROUND
		"building": sh.code = BUILDING
		"water": sh.code = WATER
		"ped": sh.code = PED
		"lights": sh.code = LIGHTS
	_s[key] = sh
	return sh
