extends CharacterBody3D
# Cars: player-driven (arcade physics), traffic AI, police, parked, wrecks.
const Cfg = preload("res://scripts/cfg.gd")
const Models = preload("res://scripts/models.gd")

var main
var kind := 0
var mode := "parked"   # player, ai, police, parked, wreck
var paint := Color.WHITE
var spd := 0.0
var steer := 0.0
var vel := Vector3.ZERO
var health := 100.0
var max_speed := 40.0
var accel := 15.0
var knock := Vector3.ZERO
var dirv := Vector2(0, 1)
var node := Vector2i.ZERO
var next_dir := Vector2(0, 1)
var base_speed := 12.0
var ram := false
var dead_t := 0.0
var stuck_t := 0.0
var ignore_t := 0.0
var mat: StandardMaterial3D
var bar_a: MeshInstance3D
var bar_b: MeshInstance3D
var bar_t := 0.0
var smoke: CPUParticles3D
var mission_car := false
var headlight: SpotLight3D
var mi: MeshInstance3D

func setup(m, k: int, col: Color, md: String) -> void:
	main = m
	kind = k
	paint = col
	mode = md
	collision_layer = 2
	collision_mask = 0
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
	mi = MeshInstance3D.new()
	mi.mesh = Models.car_mesh(kind)
	mat = StandardMaterial3D.new()
	mat.albedo_color = col
	mat.vertex_color_use_as_albedo = true
	mat.metallic = 0.6
	mat.metallic_specular = 0.7
	mat.roughness = 0.28
	mi.set_surface_override_material(0, mat)
	mi.set_surface_override_material(1, Models.wheel_mat())
	mi.set_surface_override_material(2, Models.light_mat())
	mi.visibility_range_end = 180.0
	add_child(mi)
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(1.9, 1.3, 4.5)
	cs.shape = bs
	cs.position.y = 0.75
	add_child(cs)
	if kind == 1:
		max_speed = 58.0
		accel = 22.0
	elif kind == 2:
		max_speed = 36.0
		accel = 12.0
	else:
		max_speed = 42.0
		accel = 15.0
	base_speed = randf_range(9.0, 14.0)

func make_police() -> void:
	ram = true
	var bm := BoxMesh.new()
	bm.size = Vector3(0.45, 0.14, 0.3)
	bar_a = MeshInstance3D.new()
	bar_a.mesh = bm
	bar_a.position = Vector3(-0.28, 1.46, 0.5)
	bar_a.material_override = _glow_mat(Color(1, 0.05, 0.05))
	add_child(bar_a)
	bar_b = MeshInstance3D.new()
	bar_b.mesh = bm
	bar_b.position = Vector3(0.28, 1.46, 0.5)
	bar_b.material_override = _glow_mat(Color(0.1, 0.2, 1))
	add_child(bar_b)
	max_speed = 52.0
	accel = 20.0

func _glow_mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = 0.1
	return m

func set_player(on: bool) -> void:
	if on:
		mode = "player"
		collision_mask = 1 | 2
		if headlight == null:
			headlight = SpotLight3D.new()
			headlight.position = Vector3(0, 0.9, -2.1)
			headlight.spot_range = 48.0
			headlight.spot_angle = 34.0
			headlight.light_energy = 0.0
			add_child(headlight)
	else:
		mode = "parked"
		collision_mask = 0
		if headlight != null:
			headlight.queue_free()
			headlight = null

func speed_kmh() -> float:
	return absf(spd) * 3.6

# ---------------------------------------------------------------- physics
func _physics_process(delta: float) -> void:
	if main == null:
		return
	match mode:
		"player":
			player_step(delta)
		"ai", "police":
			ai_step(delta)
		"parked":
			coast_step(delta)
		"wreck":
			dead_t += delta
			vel = vel.move_toward(Vector3.ZERO, 12.0 * delta)
			global_position += vel * delta
			if dead_t > 35.0 and not mission_car and main.cur_car != self:
				queue_free()
	if knock.length() > 0.05:
		global_position += knock * delta
		knock = knock.move_toward(Vector3.ZERO, 14.0 * delta)
	if bar_a != null:
		var on: bool = mode == "police" and main.wanted > 0
		bar_t += delta
		var ph := int(bar_t * 6.0) % 2 == 0
		(bar_a.material_override as StandardMaterial3D).emission_energy_multiplier = 3.0 if (on and ph) else 0.1
		(bar_b.material_override as StandardMaterial3D).emission_energy_multiplier = 3.0 if (on and not ph) else 0.1

func drive(thr: float, brk: float, st: float, hand: bool, delta: float) -> void:
	var f := -global_transform.basis.z
	spd = vel.dot(f)
	if thr > 0.01:
		if spd < -0.5:
			spd += 26.0 * delta
		else:
			spd += accel * thr * (1.0 - clampf(spd / max_speed, 0.0, 1.0)) * delta
	if brk > 0.01:
		if spd > 0.5:
			spd -= 30.0 * brk * delta
		else:
			spd -= accel * 0.7 * brk * delta
			spd = maxf(spd, -max_speed * 0.3)
	if thr < 0.01 and brk < 0.01:
		spd = move_toward(spd, 0.0, (1.2 + absf(spd) * 0.04) * delta * 4.0)
	if hand:
		spd = move_toward(spd, 0.0, 16.0 * delta)
	steer = move_toward(steer, st, 4.5 * delta)
	var lim := 0.55 / (1.0 + absf(spd) * 0.09)
	var yaw_rate := spd / 2.7 * tan(steer * lim)
	rotate_y(-yaw_rate * delta)
	var f2 := -global_transform.basis.z
	var grip := 7.0
	if hand:
		grip = 1.6
	elif absf(spd) > 25.0:
		grip = 5.5
	vel = vel.lerp(f2 * spd, clampf(grip * delta, 0.0, 1.0))
	vel.y = 0.0

func player_step(delta: float) -> void:
	var inp: Dictionary = main.drive_input()
	drive(inp["thr"], inp["brk"], inp["steer"], inp["hand"], delta)
	velocity = vel
	var before := vel.length()
	move_and_slide()
	var after: Vector3 = get_real_velocity()
	for i in range(get_slide_collision_count()):
		var c := get_slide_collision(i)
		var col := c.get_collider()
		if col != null and col.has_method("bump"):
			col.bump(vel * 0.6, self)
	var loss := before - after.length()
	vel = after
	vel.y = 0.0
	global_position.y = 0.0
	if loss > 6.0:
		damage((loss - 6.0) * 4.0)
		main.on_crash(loss, global_position)

func coast_step(delta: float) -> void:
	if vel.length() > 0.05:
		vel = vel.move_toward(Vector3.ZERO, 10.0 * delta)
		global_position += vel * delta

# ---------------------------------------------------------------- AI
func choose_next() -> void:
	var d := Vector2i(roundi(dirv.x), roundi(dirv.y))
	var opts: Array = []
	for c in [d, Vector2i(d.y, -d.x), Vector2i(-d.y, d.x)]:
		if Cfg.inb(node + c):
			opts.append(c)
	var chase: bool = mode == "police" and main.wanted > 0
	var pp: Vector3 = main.player_pos()
	if chase:
		var behind := (Vector2(pp.x, pp.z) - Vector2(global_position.x, global_position.z)).dot(dirv) < -40.0
		if behind and Cfg.inb(node - d):
			opts.append(-d)
	if opts.is_empty():
		opts.append(-d)
	var pick: Vector2i = opts[0]
	if chase:
		var best := 1e9
		for c in opts:
			var q := Vector2(node + c) * Cfg.P
			var dd := q.distance_to(Vector2(pp.x, pp.z))
			if dd < best:
				best = dd
				pick = c
	else:
		var total := 0.0
		for c in opts:
			total += 3.0 if c == d else 1.0
		var r := randf() * total
		for c in opts:
			r -= 3.0 if c == d else 1.0
			if r <= 0.0:
				pick = c
				break
	next_dir = Vector2(pick)

func aim() -> Vector2:
	var nw := Vector2(node) * Cfg.P
	var x := nw + Cfg.lane_off(dirv)
	if next_dir != dirv:
		x += Cfg.lane_off(next_dir)
	return x

func obstacle_speed(f2: Vector2, r2: Vector2) -> float:
	var best := 999.0
	if ignore_t > 0.0:
		return best
	var pos2 := Vector2(global_position.x, global_position.z)
	for o in main.obstacles():
		if o == self or not is_instance_valid(o):
			continue
		if ram and o == main.cur_car:
			continue
		var rel := Vector2(o.global_position.x, o.global_position.z) - pos2
		var ahead := rel.dot(f2)
		if ahead > 1.0 and ahead < 17.0 and absf(rel.dot(r2)) < 2.5:
			best = minf(best, maxf(0.0, ahead - 6.5) * 1.2)
	return best

func ai_step(delta: float) -> void:
	var pos2 := Vector2(global_position.x, global_position.z)
	var x := aim()
	if (x - pos2).dot(dirv) < 2.0:
		dirv = next_dir
		node += Vector2i(roundi(next_dir.x), roundi(next_dir.y))
		choose_next()
		x = aim()
	var turning := next_dir != dirv
	var target := x + (next_dir if turning else dirv) * 8.0
	var chasing: bool = mode == "police" and main.wanted > 0
	if chasing:
		var pp: Vector3 = main.player_pos()
		var dp := Vector2(pp.x, pp.z) - pos2
		if dp.length() < 24.0:
			target = Vector2(pp.x, pp.z)
	var f := -global_transform.basis.z
	var f2 := Vector2(f.x, f.z)
	var dn := (target - pos2).normalized()
	var r2 := Vector2(-f2.y, f2.x)
	var dr := dn.dot(r2)
	var st := clampf(dr * 2.6, -1.0, 1.0)
	if dn.dot(f2) < 0.0:
		st = 1.0 if dr >= 0.0 else -1.0
	var vt := base_speed
	if chasing:
		vt = 22.0 + main.wanted * 1.5
	if turning and (x - pos2).dot(dirv) < 24.0:
		vt = minf(vt, 7.0)
	vt = minf(vt, obstacle_speed(f2, r2))
	if spd < 0.4 and vt > 1.0:
		stuck_t += delta
		if stuck_t > 7.0:
			ignore_t = 2.5
			stuck_t = 0.0
	else:
		stuck_t = 0.0
	ignore_t = maxf(0.0, ignore_t - delta)
	var thr := clampf((vt - spd) * 0.4, 0.0, 1.0)
	var brk := clampf((spd - vt) * 0.5, 0.0, 1.0)
	drive(thr, brk, st, false, delta)
	global_position += vel * delta
	global_position.y = 0.0

# ---------------------------------------------------------------- damage
func bump(imp: Vector3, by) -> void:
	knock += imp * 0.8
	if mode == "wreck":
		return
	damage(imp.length() * 1.2)
	main.on_bump(self, imp, by)

func damage(amount: float) -> void:
	if mode == "wreck" or amount <= 0.0:
		return
	health -= amount
	if health < 30.0 and smoke == null:
		_make_smoke(false)
	if health <= 0.0:
		explode()

func _make_smoke(fire: bool) -> void:
	smoke = CPUParticles3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.28
	sm.height = 0.56
	sm.radial_segments = 6
	sm.rings = 3
	smoke.mesh = sm
	smoke.amount = 14
	smoke.lifetime = 1.6
	smoke.direction = Vector3.UP
	smoke.spread = 18.0
	smoke.initial_velocity_min = 1.5
	smoke.initial_velocity_max = 3.0
	smoke.gravity = Vector3(0, 0.6, 0)
	smoke.scale_amount_min = 0.6
	smoke.scale_amount_max = 1.6
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(1.0, 0.45, 0.1, 0.8) if fire else Color(0.22, 0.22, 0.22, 0.65)
	smoke.material_override = m
	smoke.position = Vector3(0, 1.0, -1.6)
	add_child(smoke)

func explode() -> void:
	if mode == "wreck":
		return
	var was_player := mode == "player"
	mode = "wreck"
	health = 0.0
	mat.albedo_color = Color(0.04, 0.04, 0.04)
	if smoke != null:
		smoke.queue_free()
		smoke = null
	_make_smoke(true)
	if headlight != null:
		headlight.queue_free()
		headlight = null
	main.on_explode(self, was_player)
