extends CharacterBody3D
# Vehicles: cars, tank, helicopters. Player-driven, traffic AI, police, parked, wrecks.
const Cfg = preload("res://scripts/cfg.gd")
const Models = preload("res://scripts/models.gd")

var main
var kind := 0
var info := {}
var mode := "parked"   # player, ai, police, boss, parked, wreck
var paint := Color.WHITE
var spd := 0.0
var steer := 0.0
var vel := Vector3.ZERO
var health := 100.0
var max_health := 100.0
var max_speed := 40.0
var accel := 15.0
var wheelbase := 2.7
var knock := Vector3.ZERO
var dirv := Vector2(0, 1)
var node := Vector2i.ZERO
var next_dir := Vector2(0, 1)
var base_speed := 12.0
var ram := false
var dead_t := 0.0
var stuck_t := 0.0
var ignore_t := 0.0
var mat: StandardMaterial3D
var bar_a: MeshInstance3D
var bar_b: MeshInstance3D
var bar_t := 0.0
var smoke: CPUParticles3D
var mission_car := false
var headlight: SpotLight3D
var mi: MeshInstance3D
var eng_lvl := 0
var brk_lvl := 0
var arm_lvl := 0
var owned_idx := -1
var cops_out := false
var turret: MeshInstance3D
var rotor: MeshInstance3D
var trotor: MeshInstance3D
var rotor_speed := 0.0
var is_heli := false
var is_tank := false
var alt_v := 0.0
var fire_cd := 0.0
var shoot_cd := 2.0
var orbit_t := 0.0
var spot: SpotLight3D
var tilt := Vector2.ZERO
var wp_i := 0
var blocked := false

func setup(m, k: int, col: Color, md: String) -> void:
	main = m
	kind = k
	info = Cfg.ki(k)
	paint = col
	mode = md
	is_heli = k >= 20
	is_tank = k == 10
	collision_layer = 2
	collision_mask = 0
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
	mi = MeshInstance3D.new()
	mat = StandardMaterial3D.new()
	mat.albedo_color = col
	mat.vertex_color_use_as_albedo = true
	mat.metallic = 0.6
	mat.metallic_specular = 0.7
	mat.roughness = 0.28
	if is_tank:
		mi.mesh = Models.tank_hull()
		mi.set_surface_override_material(0, Models.trim_mat())
		turret = MeshInstance3D.new()
		turret.mesh = Models.tank_turret()
		turret.material_override = Models.trim_mat()
		turret.position = Vector3(0, 1.95, 0.2)
		add_child(turret)
	elif is_heli:
		mi.mesh = Models.heli_body(kind == 21)
		mi.set_surface_override_material(0, mat)
		mi.set_surface_override_material(1, Models.trim_mat())
		rotor = MeshInstance3D.new()
		rotor.mesh = Models.rotor_mesh()
		rotor.material_override = Models.trim_mat()
		rotor.position = Vector3(0, 2.62, 0.6)
		mi.add_child(rotor)
		trotor = MeshInstance3D.new()
		trotor.mesh = Models.tail_rotor_mesh()
		trotor.material_override = Models.trim_mat()
		trotor.position = Vector3(0.18, 2.4, 5.5)
		mi.add_child(trotor)
	else:
		mi.mesh = Models.car_mesh(kind)
		mi.set_surface_override_material(0, mat)
		mi.set_surface_override_material(1, Models.trim_mat())
		mi.set_surface_override_material(2, Models.light_mat())
	mi.visibility_range_end = 220.0 if (is_heli or kind == 7) else 180.0
	add_child(mi)
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	var sz: Vector3 = info["sz"]
	bs.size = sz
	cs.shape = bs
	cs.position.y = sz.y * 0.5 + 0.12 if not is_heli else 1.5
	add_child(cs)
	max_health = info["hp"]
	health = max_health
	wheelbase = info["wb"]
	base_speed = randf_range(9.0, 14.0)
	apply_upgrades()
	if kind == 21:
		_make_spot()

func apply_upgrades() -> void:
	max_speed = float(info["max"]) * (1.0 + 0.09 * eng_lvl)
	accel = float(info["acc"]) * (1.0 + 0.14 * eng_lvl)

func _make_spot() -> void:
	spot = SpotLight3D.new()
	spot.spot_range = 120.0
	spot.spot_angle = 14.0
	spot.light_energy = 0.0
	spot.position = Vector3(0, 1.0, -2.0)
	add_child(spot)

func make_police() -> void:
	ram = true
	if is_heli or is_tank:
		return
	var bm := BoxMesh.new()
	bm.size = Vector3(0.45, 0.14, 0.3)
	bar_a = MeshInstance3D.new()
	bar_a.mesh = bm
	bar_a.position = Vector3(-0.28, 1.46, 0.5)
	bar_a.material_override = _glow_mat(Color(1, 0.05, 0.05))
	add_child(bar_a)
	bar_b = MeshInstance3D.new()
	bar_b.mesh = bm
	bar_b.position = Vector3(0.28, 1.46, 0.5)
	bar_b.material_override = _glow_mat(Color(0.1, 0.2, 1))
	add_child(bar_b)
	max_speed = 52.0 * (1.0 + 0.0)
	accel = 21.0

func _glow_mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = 0.1
	return m

func set_player(on: bool) -> void:
	if on:
		mode = "player"
		collision_mask = 1 | 2
		if headlight == null and not is_heli and not is_tank:
			headlight = SpotLight3D.new()
			headlight.position = Vector3(0, 0.9, -2.1)
			headlight.spot_range = 48.0
			headlight.spot_angle = 34.0
			headlight.light_energy = 0.0
			add_child(headlight)
	else:
		mode = "parked"
		collision_mask = 0
		if headlight != null:
			headlight.queue_free()
			headlight = null

func speed_kmh() -> float:
	if is_heli:
		return vel.length() * 3.6
	return absf(spd) * 3.6

func altitude() -> float:
	return global_position.y

# ---------------------------------------------------------------- physics
func _physics_process(delta: float) -> void:
	if main == null:
		return
	fire_cd = maxf(0.0, fire_cd - delta)
	match mode:
		"player":
			if is_heli:
				heli_player_step(delta)
			else:
				player_step(delta)
		"ai", "police", "boss":
			if is_heli:
				heli_ai_step(delta)
			elif blocked:
				coast_step(delta)
			else:
				ai_step(delta)
		"parked":
			if is_heli:
				heli_idle(delta)
			else:
				coast_step(delta)
		"wreck":
			dead_t += delta
			vel = vel.move_toward(Vector3.ZERO, 12.0 * delta)
			global_position += vel * delta
			if is_heli and global_position.y > 0.0:
				global_position.y = maxf(0.0, global_position.y - 28.0 * delta)
			if dead_t > 35.0 and not mission_car and main.cur_car != self:
				queue_free()
	if is_tank and turret != null:
		_turret_step(delta)
	if rotor != null:
		rotor.rotate_y(rotor_speed * delta)
		trotor.rotate_x(rotor_speed * 1.5 * delta)
	if knock.length() > 0.05:
		global_position += knock * delta
		knock = knock.move_toward(Vector3.ZERO, 14.0 * delta)
	if bar_a != null:
		var on: bool = (mode == "police" and main.wanted > 0)
		bar_t += delta
		var ph := int(bar_t * 6.0) % 2 == 0
		(bar_a.material_override as StandardMaterial3D).emission_energy_multiplier = 3.0 if (on and ph) else 0.1
		(bar_b.material_override as StandardMaterial3D).emission_energy_multiplier = 3.0 if (on and not ph) else 0.1

func _turret_step(delta: float) -> void:
	var want := rotation.y
	if mode == "player":
		want = main.cam_yaw
	elif mode == "police" or mode == "boss":
		var pp: Vector3 = main.player_pos()
		want = atan2(-(pp.x - global_position.x), -(pp.z - global_position.z))
	var local := want - rotation.y
	turret.rotation.y = lerp_angle(turret.rotation.y, local, minf(1.0, 3.0 * delta))

func turret_dir() -> Vector3:
	var yaw := rotation.y + (turret.rotation.y if turret != null else 0.0)
	return Vector3(-sin(yaw), 0.0, -cos(yaw))

func muzzle_pos() -> Vector3:
	return global_position + Vector3(0, 2.05, 0) + turret_dir() * 4.6

func drive(thr: float, brk: float, st: float, hand: bool, delta: float) -> void:
	var f := -global_transform.basis.z
	var old := vel.dot(f)
	spd = old
	var bf := 40.0 * (1.0 + 0.25 * brk_lvl)
	if thr > 0.01:
		if spd < -0.5:
			spd += bf * 0.6 * delta
		else:
			spd += accel * thr * (1.0 - clampf(spd / max_speed, 0.0, 1.0)) * delta
	if brk > 0.01:
		if spd > 0.4:
			spd = maxf(0.0, spd - bf * brk * delta)
		else:
			spd -= accel * 0.7 * brk * delta
			spd = maxf(spd, -max_speed * 0.3)
	if thr < 0.01 and brk < 0.01:
		spd = move_toward(spd, 0.0, (2.2 + absf(spd) * 0.05) * delta)
	if hand:
		spd = move_toward(spd, 0.0, 26.0 * delta)
	vel += f * (spd - old)
	steer = move_toward(steer, st, 4.5 * delta)
	var lim := 0.55 / (1.0 + absf(spd) * 0.09)
	var yaw_rate := 0.0
	if is_tank:
		lim = 0.9 / (1.0 + absf(spd) * 0.12)
		yaw_rate = spd / wheelbase * tan(steer * lim)
		if absf(spd) < 2.0:
			yaw_rate += steer * 0.9 * (1.0 - absf(spd) * 0.5)
	else:
		yaw_rate = spd / wheelbase * tan(steer * lim)
	rotate_y(-yaw_rate * delta)
	var f2 := -global_transform.basis.z
	var grip := 7.5
	if hand:
		grip = 1.5
	elif absf(spd) > 25.0:
		grip = 6.0
	var fwd_comp := f2 * vel.dot(f2)
	var lat := vel - fwd_comp
	lat = lat.lerp(Vector3.ZERO, clampf(grip * delta, 0.0, 1.0))
	# keep most of the speed when turning
	vel = fwd_comp + lat
	vel.y = 0.0

func player_step(delta: float) -> void:
	var inp: Dictionary = main.drive_input()
	drive(inp["thr"], inp["brk"], inp["steer"], inp["hand"], delta)
	velocity = vel
	var before := vel.length()
	move_and_slide()
	var after: Vector3 = get_real_velocity()
	for i in range(get_slide_collision_count()):
		var c := get_slide_collision(i)
		var col := c.get_collider()
		if col != null and col.has_method("bump"):
			if is_tank:
				col.damage(260.0)
				col.bump(vel * 1.5, self)
			else:
				col.bump(vel * 0.6, self)
	var loss := before - after.length()
	vel = after
	vel.y = 0.0
	global_position.y = 0.0
	var thr := 8.0 if not is_tank else 22.0
	if loss > 6.0 and not is_tank:
		damage((loss - 6.0) * 4.0)
		main.on_crash(loss, global_position)
	elif loss > thr:
		main.on_crash(loss * 0.4, global_position)

func coast_step(delta: float) -> void:
	if vel.length() > 0.05:
		vel = vel.move_toward(Vector3.ZERO, 10.0 * delta)
		global_position += vel * delta

# ---------------------------------------------------------------- helicopter
func heli_player_step(delta: float) -> void:
	var inp: Dictionary = main.drive_input()
	var up: float = float(inp["thr"]) - float(inp["brk"])
	var fwd_in: float = main.hud.move.y
	rotor_speed = lerpf(rotor_speed, 28.0, 2.0 * delta)
	rotate_y(-float(inp["steer"]) * 1.5 * delta)
	var f := -global_transform.basis.z
	var tv := f * fwd_in * max_speed
	vel = vel.lerp(tv, clampf(1.5 * delta, 0.0, 1.0))
	vel.y = 0.0
	alt_v = lerpf(alt_v, up * 13.0, clampf(3.0 * delta, 0.0, 1.0))
	var landed := global_position.y <= 0.2
	if landed and up <= 0.0:
		vel = vel * 0.0
		alt_v = 0.0
	velocity = Vector3(vel.x, alt_v, vel.z)
	var before := velocity.length()
	move_and_slide()
	var after: Vector3 = get_real_velocity()
	if global_position.y < 0.0:
		global_position.y = 0.0
		alt_v = maxf(0.0, alt_v)
	if global_position.y > 170.0:
		global_position.y = 170.0
		alt_v = minf(0.0, alt_v)
	var loss := before - after.length()
	if loss > 8.0:
		damage((loss - 8.0) * 5.0)
		main.on_crash(loss, global_position)
	vel = Vector3(after.x, 0.0, after.z)
	spd = vel.dot(f)
	tilt = tilt.lerp(Vector2(-fwd_in * 0.2, float(inp["steer"]) * 0.22), clampf(4.0 * delta, 0.0, 1.0))
	mi.rotation = Vector3(tilt.x, 0.0, tilt.y)

func heli_idle(delta: float) -> void:
	rotor_speed = lerpf(rotor_speed, 0.0, 1.0 * delta)
	global_position.y = maxf(0.0, global_position.y - 8.0 * delta)
	mi.rotation = mi.rotation.lerp(Vector3.ZERO, clampf(3.0 * delta, 0.0, 1.0))

func heli_ai_step(delta: float) -> void:
	rotor_speed = lerpf(rotor_speed, 28.0, 2.0 * delta)
	var pp: Vector3 = main.player_pos()
	var goal := Vector3.ZERO
	var alt := 32.0
	if mode == "boss":
		var pts: Array = main.boss_route()
		var tgt: Vector3 = pts[wp_i % pts.size()]
		goal = Vector3(tgt.x, 0, tgt.z)
		alt = 45.0
		if Vector2(global_position.x - goal.x, global_position.z - goal.z).length() < 12.0:
			wp_i += 1
	else:
		orbit_t += delta
		goal = Vector3(pp.x + cos(orbit_t * 0.35) * 26.0, 0, pp.z + sin(orbit_t * 0.35) * 26.0)
	var to := Vector3(goal.x - global_position.x, 0, goal.z - global_position.z)
	var sp := minf(to.length() * 1.2, max_speed * 0.8)
	var dv := to.normalized() * sp
	vel = vel.lerp(dv, clampf(1.2 * delta, 0.0, 1.0))
	var target_alt := alt
	alt_v = lerpf(alt_v, clampf((target_alt - global_position.y) * 0.8, -10.0, 10.0), clampf(2.0 * delta, 0.0, 1.0))
	global_position += Vector3(vel.x, alt_v, vel.z) * delta
	if mode == "police":
		var face := Vector3(pp.x - global_position.x, 0, pp.z - global_position.z)
		if face.length() > 1.0:
			rotation.y = lerp_angle(rotation.y, atan2(-face.x, -face.z), clampf(2.0 * delta, 0.0, 1.0))
		if spot != null:
			spot.light_energy = main.night_amount() * 8.0
			spot.look_at(pp + Vector3(0, 1.0, 0), Vector3.UP)
		shoot_cd -= delta
		var dist := global_position.distance_to(pp)
		if shoot_cd <= 0.0 and dist < 100.0 and main.wanted >= 3:
			shoot_cd = randf_range(0.9, 1.6)
			main.heli_shoot(self, dist)
	elif vel.length() > 1.0:
		rotation.y = lerp_angle(rotation.y, atan2(-vel.x, -vel.z), clampf(2.0 * delta, 0.0, 1.0))
	mi.rotation = Vector3(-0.12, 0.0, 0.0)

# ---------------------------------------------------------------- AI
func choose_next() -> void:
	var d := Vector2i(roundi(dirv.x), roundi(dirv.y))
	var opts: Array = []
	for c in [d, Vector2i(d.y, -d.x), Vector2i(-d.y, d.x)]:
		if Cfg.inb(node + c):
			opts.append(c)
	var chase: bool = mode == "police" and main.wanted > 0
	var pp: Vector3 = main.player_pos()
	if chase:
		var behind := (Vector2(pp.x, pp.z) - Vector2(global_position.x, global_position.z)).dot(dirv) < -40.0
		if behind and Cfg.inb(node - d):
			opts.append(-d)
	if opts.is_empty():
		opts.append(-d)
	var pick: Vector2i = opts[0]
	if mode == "boss":
		# flee away from the player
		var worst := -1.0
		for c in opts:
			var q2 = Vector2(node + c) * Cfg.P
			var dd2 = q2.distance_to(Vector2(pp.x, pp.z))
			if dd2 > worst:
				worst = dd2
				pick = c
	elif chase:
		var best := 1e9
		for c in opts:
			var q = Vector2(node + c) * Cfg.P
			var dd = q.distance_to(Vector2(pp.x, pp.z))
			if dd < best:
				best = dd
				pick = c
	else:
		var total := 0.0
		for c in opts:
			total += 3.0 if c == d else 1.0
		var r := randf() * total
		for c in opts:
			r -= 3.0 if c == d else 1.0
			if r <= 0.0:
				pick = c
				break
	next_dir = Vector2(pick)

func aim() -> Vector2:
	var nw := Vector2(node) * Cfg.P
	var x := nw + Cfg.lane_off(dirv)
	if next_dir != dirv:
		x += Cfg.lane_off(next_dir)
	return x

func obstacle_speed(f2: Vector2, r2: Vector2, x: Vector2) -> float:
	var best := 999.0
	if ignore_t > 0.0:
		return best
	var pos2 := Vector2(global_position.x, global_position.z)
	for o in main.obstacles():
		if o == self or not is_instance_valid(o):
			continue
		if ram and o == main.cur_car:
			continue
		if o.get("is_heli") == true:
			continue
		var rel = Vector2(o.global_position.x, o.global_position.z) - pos2
		var ahead = rel.dot(f2)
		var lim := 17.0 + absf(spd) * 0.5
		if ahead > 1.0 and ahead < lim and absf(rel.dot(r2)) < 2.6:
			best = minf(best, maxf(0.0, ahead - 6.5) * 1.3)
	# traffic lights
	if not ram and mode != "boss":
		var nw := Vector2(node) * Cfg.P
		var dist_stop := (nw - pos2).dot(dirv) - 10.5
		if dist_stop > -1.0 and dist_stop < 45.0:
			var ns := absf(dirv.y) > 0.5
			var state: int = main.signal_state(ns)
			if state != 2:
				if dist_stop < 0.5:
					if state == 0:
						best = 0.0
				else:
					best = minf(best, sqrt(maxf(0.0, dist_stop) * 2.0 * 7.0))
	return best

func ai_step(delta: float) -> void:
	var pos2 := Vector2(global_position.x, global_position.z)
	var x := aim()
	if (x - pos2).dot(dirv) < 2.0:
		dirv = next_dir
		node += Vector2i(roundi(next_dir.x), roundi(next_dir.y))
		choose_next()
		x = aim()
	var turning := next_dir != dirv
	var target := x + (next_dir if turning else dirv) * 8.0
	var chasing: bool = (mode == "police" and main.wanted > 0) or mode == "boss"
	if mode == "police" and main.wanted > 0:
		var pp: Vector3 = main.player_pos()
		var dp := Vector2(pp.x, pp.z) - pos2
		if dp.length() < 24.0 and not is_tank:
			target = Vector2(pp.x, pp.z)
	var f := -global_transform.basis.z
	var f2 := Vector2(f.x, f.z)
	var dn := (target - pos2).normalized()
	var r2 := Vector2(-f2.y, f2.x)
	var dr := dn.dot(r2)
	var st := clampf(dr * 2.6, -1.0, 1.0)
	if dn.dot(f2) < 0.0:
		st = 1.0 if dr >= 0.0 else -1.0
	var vt := base_speed
	if chasing:
		vt = 22.0 + main.wanted * 2.0
		if mode == "boss":
			vt = 30.0
	vt = minf(vt, max_speed * 0.92)
	if turning and (x - pos2).dot(dirv) < 24.0:
		vt = minf(vt, 7.0)
	vt = minf(vt, obstacle_speed(f2, r2, x))
	if spd < 0.4 and vt > 1.0:
		stuck_t += delta
		if stuck_t > 6.0:
			ignore_t = 2.5
			stuck_t = 0.0
	else:
		stuck_t = 0.0
	ignore_t = maxf(0.0, ignore_t - delta)
	var thr := clampf((vt - spd) * 0.4, 0.0, 1.0)
	var brk := clampf((spd - vt) * 0.5, 0.0, 1.0)
	drive(thr, brk, st, false, delta)
	global_position += vel * delta
	global_position.y = 0.0
	if is_tank and mode == "police":
		shoot_cd -= delta
		var dd = global_position.distance_to(main.player_pos())
		if shoot_cd <= 0.0 and dd < 80.0 and main.wanted >= 4:
			shoot_cd = 4.0
			main.fire_shell(self, false)

# ---------------------------------------------------------------- damage
func bump(imp: Vector3, by) -> void:
	knock += imp * 0.8
	if mode == "wreck":
		return
	damage(imp.length() * 1.2)
	main.on_bump(self, imp, by)

func damage(amount: float) -> void:
	if mode == "wreck" or amount <= 0.0:
		return
	if is_tank:
		amount *= 0.5
	amount *= (1.0 - 0.22 * arm_lvl)
	health -= amount
	if health < max_health * 0.3 and smoke == null:
		_make_smoke(false)
	if health <= 0.0:
		explode()

func repair() -> void:
	health = max_health
	if smoke != null:
		smoke.queue_free()
		smoke = null

func set_paint(c: Color) -> void:
	paint = c
	mat.albedo_color = c

func _make_smoke(fire: bool) -> void:
	smoke = CPUParticles3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.28
	sm.height = 0.56
	sm.radial_segments = 6
	sm.rings = 3
	smoke.mesh = sm
	smoke.amount = 14
	smoke.lifetime = 1.6
	smoke.direction = Vector3.UP
	smoke.spread = 18.0
	smoke.initial_velocity_min = 1.5
	smoke.initial_velocity_max = 3.0
	smoke.gravity = Vector3(0, 0.6, 0)
	smoke.scale_amount_min = 0.6
	smoke.scale_amount_max = 1.6
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(1.0, 0.45, 0.1, 0.8) if fire else Color(0.22, 0.22, 0.22, 0.65)
	smoke.material_override = m
	smoke.position = Vector3(0, 1.0, -1.6) if not is_heli else Vector3(0, 1.8, 0)
	add_child(smoke)

func explode() -> void:
	if mode == "wreck":
		return
	var was_player := mode == "player"
	mode = "wreck"
	health = 0.0
	mat.albedo_color = Color(0.04, 0.04, 0.04)
	if smoke != null:
		smoke.queue_free()
		smoke = null
	_make_smoke(true)
	if headlight != null:
		headlight.queue_free()
		headlight = null
	if spot != null:
		spot.light_energy = 0.0
	rotor_speed = 0.0
	main.on_explode(self, was_player)
