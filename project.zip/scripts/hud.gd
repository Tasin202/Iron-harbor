extends Control
# Touch controls + HUD (minimap, GPS, wanted stars, subtitles, phone/shop menus, full map, pause).
const Cfg = preload("res://scripts/cfg.gd")

var main
var move := Vector2.ZERO
var look_accum := Vector2.ZERO
var b_fire := false
var b_gas := false
var b_brake := false
var b_hand := false
var b_rkt := false
var ev := {}
var tmap := {}
var stick_center := Vector2.ZERO
var stick_idx := -1
var paused := false
var font: Font
var toasts: Array = []
var subs: Array = []     # [speaker, text, ttl]
var title_t := 5.0
var flash := 0.0
var banner := ""
var banner_t := 0.0
var mm: Control
var u := 1.0
var fade_a := 0.0
var fade_state := 0      # 0 none, 1 fading out, 2 fading in
var fade_cb := Callable()
# menus
var menu_open := false
var menu_title := ""
var menu_sub := ""
var menu_rows: Array = []
var menu_cb := Callable()
var menu_scroll := 0.0
var menu_touch := {}
var map_open := false
var update_text := ""
var update_url := ""
var update_t := 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	font = ThemeDB.fallback_font
	mm = Control.new()
	mm.clip_contents = true
	mm.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(mm)
	mm.draw.connect(_draw_map)

func take_look() -> Vector2:
	var l := look_accum
	look_accum = Vector2.ZERO
	return l

func consume(id: String) -> bool:
	if ev.has(id):
		ev.erase(id)
		return true
	return false

func toast(t: String) -> void:
	toasts.append([t, 3.5])
	if toasts.size() > 3:
		toasts.pop_front()

func show_banner(t: String, dur: float) -> void:
	banner = t
	banner_t = dur

func say(speaker: String, text: String) -> void:
	subs.append([speaker, text, 2.4 + text.length() * 0.035])
	if subs.size() > 4:
		subs.pop_front()

func show_update(text: String, url: String) -> void:
	update_text = text
	update_url = url
	update_t = 30.0

func update_rect() -> Rect2:
	return Rect2(16 * u, size.y * 0.5 - 44 * u, 340 * u, 88 * u)

func clear_subs() -> void:
	subs.clear()

func start_fade(cb: Callable) -> void:
	fade_state = 1
	fade_cb = cb

func open_menu(title: String, rows: Array, cb: Callable, sub := "") -> void:
	menu_open = true
	menu_title = title
	menu_sub = sub
	menu_rows = rows
	menu_cb = cb
	menu_scroll = 0.0
	map_open = false
	get_tree().paused = true
	tmap.clear()
	stick_idx = -1
	move = Vector2.ZERO

func refresh_menu(rows: Array, sub := "") -> void:
	menu_rows = rows
	menu_sub = sub

func close_menu() -> void:
	menu_open = false
	map_open = false
	if not paused:
		get_tree().paused = false

func open_map() -> void:
	map_open = true
	menu_open = false
	get_tree().paused = true
	tmap.clear()
	stick_idx = -1
	move = Vector2.ZERO

# ---------------------------------------------------------------- layout
func btn_list() -> Array:
	var w := size.x
	var h := size.y
	var l: Array = []
	var car = main.cur_car
	if car != null and is_instance_valid(car):
		if car.is_heli:
			l.append({"id": "gas", "pos": Vector2(w - 150 * u, h - 170 * u), "r": 76 * u, "label": "UP"})
			l.append({"id": "brake", "pos": Vector2(w - 330 * u, h - 105 * u), "r": 56 * u, "label": "DOWN"})
			l.append({"id": "fire", "pos": Vector2(w - 320 * u, h - 250 * u), "r": 46 * u, "label": "GUN"})
			l.append({"id": "rkt", "pos": Vector2(w - 470 * u, h - 140 * u), "r": 42 * u, "label": "ROCKET"})
		elif car.is_tank:
			l.append({"id": "gas", "pos": Vector2(w - 150 * u, h - 170 * u), "r": 76 * u, "label": "GAS"})
			l.append({"id": "brake", "pos": Vector2(w - 330 * u, h - 105 * u), "r": 56 * u, "label": "BRAKE"})
			l.append({"id": "fire", "pos": Vector2(w - 320 * u, h - 250 * u), "r": 54 * u, "label": "FIRE"})
		else:
			l.append({"id": "gas", "pos": Vector2(w - 150 * u, h - 170 * u), "r": 80 * u, "label": "GAS"})
			l.append({"id": "brake", "pos": Vector2(w - 340 * u, h - 110 * u), "r": 58 * u, "label": "BRAKE"})
			l.append({"id": "hand", "pos": Vector2(w - 330 * u, h - 250 * u), "r": 42 * u, "label": "DRIFT"})
		l.append({"id": "enter", "pos": Vector2(w - 80 * u, h - 340 * u), "r": 44 * u, "label": "EXIT"})
	else:
		l.append({"id": "fire", "pos": Vector2(w - 150 * u, h - 160 * u), "r": 76 * u, "label": "FIRE"})
		l.append({"id": "jump", "pos": Vector2(w - 310 * u, h - 90 * u), "r": 48 * u, "label": "JUMP"})
		l.append({"id": "enter", "pos": Vector2(w - 80 * u, h - 330 * u), "r": 46 * u, "label": "ENTER"})
		l.append({"id": "swap", "pos": Vector2(w - 270 * u, h - 240 * u), "r": 38 * u, "label": "GUN"})
	return l

func pause_rects() -> Array:
	var c := size * 0.5
	var bw := 360 * u
	var bh := 64 * u
	return [
		Rect2(c.x - bw * 0.5, c.y - 110 * u, bw, bh),
		Rect2(c.x - bw * 0.5, c.y - 30 * u, bw, bh),
		Rect2(c.x - bw * 0.5, c.y + 50 * u, bw, bh)]

func menu_panel() -> Rect2:
	var pw := minf(size.x * 0.8, 820 * u)
	return Rect2((size.x - pw) * 0.5, 20 * u, pw, size.y - 40 * u)

func menu_list_rect() -> Rect2:
	var p := menu_panel()
	return Rect2(p.position.x + 16 * u, p.position.y + 96 * u, p.size.x - 32 * u, p.size.y - 96 * u - 84 * u)

func menu_back_rect() -> Rect2:
	var p := menu_panel()
	return Rect2(p.position.x + p.size.x * 0.5 - 130 * u, p.end.y - 70 * u, 260 * u, 54 * u)

func row_h() -> float:
	return 62.0 * u

func phone_rect() -> Vector2:
	return Vector2(46 * u, 262 * u)

# ---------------------------------------------------------------- input
func _input(event: InputEvent) -> void:
	if main == null:
		return
	if event is InputEventScreenTouch:
		var idx: int = event.index
		if event.pressed:
			_press(idx, event.position)
		else:
			_release(idx, event.position)
	elif event is InputEventScreenDrag:
		var idx2: int = event.index
		if menu_open and menu_touch.has(idx2):
			var mt: Dictionary = menu_touch[idx2]
			mt["moved"] = float(mt["moved"]) + event.relative.length()
			menu_scroll -= event.relative.y
			_clamp_scroll()
			return
		if tmap.has(idx2):
			var t: Dictionary = tmap[idx2]
			if t["role"] == "stick":
				var v: Vector2 = (event.position - stick_center) / (62.0 * u)
				v = v.limit_length(1.0)
				move = Vector2(v.x, -v.y)
			elif t["role"] == "look":
				look_accum += event.relative

func _clamp_scroll() -> void:
	var total := menu_rows.size() * row_h()
	var vis := menu_list_rect().size.y
	menu_scroll = clampf(menu_scroll, 0.0, maxf(0.0, total - vis))

func _press(idx: int, pos: Vector2) -> void:
	if fade_state != 0:
		return
	if paused:
		var r := pause_rects()
		if r[0].has_point(pos):
			set_paused(false)
		elif r[1].has_point(pos):
			main.cycle_quality()
		elif r[2].has_point(pos):
			main.save_game()
			get_tree().quit()
		return
	if map_open:
		var mr := _map_rect()
		if menu_back_rect().has_point(pos):
			close_menu()
		elif mr.has_point(pos):
			main.set_waypoint(_map_to_world(pos, mr))
			toast("Waypoint set")
		return
	if menu_open:
		if menu_back_rect().has_point(pos):
			main.menu_back()
		elif menu_list_rect().has_point(pos):
			menu_touch[idx] = {"start": pos, "moved": 0.0}
		return
	if update_t > 0.0 and update_rect().has_point(pos):
		OS.shell_open(update_url)
		update_t = 0.0
		return
	if pos.distance_to(Vector2(size.x - 50 * u, 50 * u)) < 34 * u:
		set_paused(true)
		return
	if pos.distance_to(phone_rect()) < 34 * u:
		main.open_phone()
		return
	for b in btn_list():
		if pos.distance_to(b["pos"]) <= b["r"] * 1.15:
			tmap[idx] = {"role": "btn", "id": b["id"]}
			if b["id"] == "enter" or b["id"] == "jump" or b["id"] == "swap":
				ev[b["id"]] = true
			return
	if pos.x < size.x * 0.45:
		if stick_idx == -1:
			stick_idx = idx
			stick_center = pos
			tmap[idx] = {"role": "stick"}
	else:
		tmap[idx] = {"role": "look"}

func _release(idx: int, pos: Vector2) -> void:
	if menu_open and menu_touch.has(idx):
		var mt: Dictionary = menu_touch[idx]
		menu_touch.erase(idx)
		if float(mt["moved"]) < 14.0:
			var lr := menu_list_rect()
			var ry := pos.y - lr.position.y + menu_scroll
			var i := int(ry / row_h())
			if i >= 0 and i < menu_rows.size() and lr.has_point(pos):
				var row: Dictionary = menu_rows[i]
				if not row.get("dis", false) and not row.get("hdr", false):
					main.menu_pick(row["id"])
		return
	if tmap.has(idx):
		if tmap[idx]["role"] == "stick":
			stick_idx = -1
			move = Vector2.ZERO
		tmap.erase(idx)

func set_paused(p: bool) -> void:
	paused = p
	get_tree().paused = p or menu_open or map_open
	if p:
		tmap.clear()
		stick_idx = -1
		move = Vector2.ZERO

# ---------------------------------------------------------------- update
func _process(delta: float) -> void:
	if main == null:
		return
	position = Vector2.ZERO
	size = get_viewport_rect().size
	u = maxf(0.5, size.y / 720.0)
	b_fire = false
	b_gas = false
	b_brake = false
	b_hand = false
	b_rkt = false
	for t in tmap.values():
		if t["role"] == "btn":
			match t["id"]:
				"fire": b_fire = true
				"gas": b_gas = true
				"brake": b_brake = true
				"hand": b_hand = true
				"rkt": b_rkt = true
	if stick_idx == -1 and not menu_open:
		var kx := 0.0
		var ky := 0.0
		if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): kx += 1.0
		if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): kx -= 1.0
		if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): ky += 1.0
		if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): ky -= 1.0
		move = Vector2(kx, ky)
	if Input.is_key_pressed(KEY_SPACE):
		b_fire = true
		b_hand = true
	if Input.is_key_pressed(KEY_E):
		if not ev.has("kE"):
			ev["enter"] = true
			ev["kE"] = true
	else:
		ev.erase("kE")
	title_t = maxf(0.0, title_t - delta)
	update_t = maxf(0.0, update_t - delta)
	flash = maxf(0.0, flash - delta * 2.0)
	banner_t = maxf(0.0, banner_t - delta)
	for t in toasts:
		t[1] -= delta
	while toasts.size() > 0 and toasts[0][1] <= 0.0:
		toasts.pop_front()
	for sbs in subs:
		sbs[2] -= delta
	while subs.size() > 0 and subs[0][2] <= 0.0:
		subs.pop_front()
	# fade
	if fade_state == 1:
		fade_a = minf(1.0, fade_a + delta * 4.5)
		if fade_a >= 1.0:
			fade_state = 2
			if fade_cb.is_valid():
				fade_cb.call()
	elif fade_state == 2:
		fade_a = maxf(0.0, fade_a - delta * 3.0)
		if fade_a <= 0.0:
			fade_state = 0
	mm.visible = not (menu_open or map_open)
	mm.position = Vector2(16 * u, 16 * u)
	mm.size = Vector2(176 * u, 176 * u)
	mm.queue_redraw()
	queue_redraw()

# ---------------------------------------------------------------- drawing helpers
func _txt(s: String, pos: Vector2, fs: float, col: Color, align := HORIZONTAL_ALIGNMENT_LEFT, w := -1.0) -> void:
	draw_string_outline(font, pos, s, align, w, int(fs), int(maxf(2.0, fs * 0.14)), Color(0, 0, 0, 0.85))
	draw_string(font, pos, s, align, w, int(fs), col)

func _star(c: Vector2, r: float, col: Color) -> void:
	var pts := PackedVector2Array()
	for i in range(10):
		var a := -PI * 0.5 + i * PI / 5.0
		var rr := r if i % 2 == 0 else r * 0.45
		pts.append(c + Vector2(cos(a), sin(a)) * rr)
	draw_colored_polygon(pts, col)

func _mp(wp: Vector3, pp: Vector3, yaw: float, c: Vector2, sc: float) -> Vector2:
	var rel := wp - pp
	var rt := rel.x * cos(yaw) - rel.z * sin(yaw)
	var up := -rel.x * sin(yaw) - rel.z * cos(yaw)
	return c + Vector2(rt * sc, -up * sc)

func _map_rect() -> Rect2:
	var s := size.y - 150 * u
	return Rect2((size.x - s) * 0.5, 20 * u, s, s)

func _map_to_world(p: Vector2, r: Rect2) -> Vector3:
	var f := (p - r.position) / r.size
	return Vector3(lerpf(-380.0, 380.0, f.x), 0.0, lerpf(-380.0, 380.0, f.y))

func _w2m(w: Vector3, r: Rect2) -> Vector2:
	return r.position + Vector2((w.x + 380.0) / 760.0, (w.z + 380.0) / 760.0) * r.size

func _draw_map() -> void:
	var s := mm.size
	var c := s * 0.5
	var sc := 0.5 * u
	var yaw: float = main.cam_yaw
	var pp: Vector3 = main.player_pos()
	mm.draw_rect(Rect2(Vector2.ZERO, s), Color(0.05, 0.07, 0.1, 0.8))
	if main.in_interior >= 0:
		mm.draw_string(font, Vector2(10 * u, c.y), "INSIDE", HORIZONTAL_ALIGNMENT_LEFT, -1, int(24 * u), Color(1, 1, 1))
		return
	var rw := 15.0 * sc
	for i in range(-Cfg.GRID, Cfg.GRID + 1):
		var x := i * Cfg.P
		mm.draw_line(_mp(Vector3(x, 0, -330), pp, yaw, c, sc), _mp(Vector3(x, 0, 330), pp, yaw, c, sc), Color(0.42, 0.45, 0.5), rw)
		mm.draw_line(_mp(Vector3(-330, 0, x), pp, yaw, c, sc), _mp(Vector3(330, 0, x), pp, yaw, c, sc), Color(0.42, 0.45, 0.5), rw)
	var route: Array = main.gps_points()
	for i in range(route.size() - 1):
		mm.draw_line(_mp(route[i], pp, yaw, c, sc), _mp(route[i + 1], pp, yaw, c, sc), Color(0.25, 0.85, 1.0), 4.0 * u)
	for ic in main.map_icons():
		var p2 := _mp(ic["pos"], pp, yaw, c, sc)
		var off2 := p2 - c
		var lim2 := s.x * 0.5 - 8 * u
		if absf(off2.x) <= lim2 and absf(off2.y) <= lim2:
			mm.draw_circle(p2, 5 * u, ic["color"])
			mm.draw_arc(p2, 6 * u, 0, TAU, 12, Color(0, 0, 0, 0.8), 1.2 * u)
	if main.wanted > 0:
		for v in main.vehicles:
			if is_instance_valid(v) and (v.mode == "police"):
				mm.draw_circle(_mp(v.global_position, pp, yaw, c, sc), 3.5 * u, Color(1.0, 0.2, 0.2) if int(Time.get_ticks_msec() / 250.0) % 2 == 0 else Color(0.3, 0.4, 1.0))
	for t in main.get_targets():
		var p := _mp(t["pos"], pp, yaw, c, sc)
		var off := p - c
		var lim := s.x * 0.5 - 8 * u
		if absf(off.x) > lim or absf(off.y) > lim:
			off = off * (lim / maxf(absf(off.x), absf(off.y)))
		mm.draw_circle(c + off, 6 * u, t["color"])
		mm.draw_arc(c + off, 7.5 * u, 0, TAU, 16, Color(0, 0, 0, 0.8), 1.5 * u)
	var delta_a: float = main.player_heading() - yaw
	var v := Vector2(-sin(delta_a), -cos(delta_a))
	var pr := Vector2(-v.y, v.x)
	mm.draw_colored_polygon(PackedVector2Array([c + v * 10 * u, c - v * 6 * u + pr * 6 * u, c - v * 3 * u, c - v * 6 * u - pr * 6 * u]), Color(1, 1, 1))

func _draw_fullmap() -> void:
	var r := _map_rect()
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.82))
	draw_rect(r, Color(0.08, 0.1, 0.14))
	for i in range(-Cfg.GRID, Cfg.GRID + 1):
		var x := i * Cfg.P
		draw_line(_w2m(Vector3(x, 0, -330), r), _w2m(Vector3(x, 0, 330), r), Color(0.4, 0.43, 0.48), 5.0 * u)
		draw_line(_w2m(Vector3(-330, 0, x), r), _w2m(Vector3(330, 0, x), r), Color(0.4, 0.43, 0.48), 5.0 * u)
	for ic in main.map_icons():
		var p := _w2m(ic["pos"], r)
		draw_circle(p, 8 * u, ic["color"])
		_txt(str(ic["label"]), p + Vector2(10 * u, 5 * u), 15 * u, Color(1, 1, 1))
	var pp: Vector3 = main.player_pos()
	draw_circle(_w2m(pp, r), 7 * u, Color(1, 1, 1))
	if main.waypoint_on:
		var wp := _w2m(main.waypoint, r)
		draw_circle(wp, 9 * u, Color(1, 0.3, 0.9))
		draw_arc(wp, 12 * u, 0, TAU, 20, Color(1, 1, 1), 2 * u)
	_txt("MAP - tap to set a GPS waypoint", Vector2(0, size.y - 100 * u), 22 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, size.x)
	var b := menu_back_rect()
	draw_rect(b, Color(0.15, 0.17, 0.22, 0.95))
	draw_rect(b, Color(1, 0.8, 0.2, 0.8), false, 2 * u)
	_txt("CLOSE", b.position + Vector2(0, b.size.y * 0.66), 24 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, b.size.x)

func _draw_menu() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.7))
	var p := menu_panel()
	draw_rect(p, Color(0.07, 0.08, 0.11, 0.97))
	draw_rect(p, Color(1, 0.8, 0.2, 0.9), false, 2 * u)
	_txt(menu_title, Vector2(p.position.x, p.position.y + 46 * u), 34 * u, Color(1, 0.8, 0.2), HORIZONTAL_ALIGNMENT_CENTER, p.size.x)
	if menu_sub != "":
		_txt(menu_sub, Vector2(p.position.x, p.position.y + 78 * u), 20 * u, Color(0.6, 0.95, 0.6), HORIZONTAL_ALIGNMENT_CENTER, p.size.x)
	var lr := menu_list_rect()
	var rh := row_h()
	for i in range(menu_rows.size()):
		var y := lr.position.y + i * rh - menu_scroll
		if y + rh < lr.position.y or y > lr.end.y:
			continue
		var row: Dictionary = menu_rows[i]
		var rr := Rect2(lr.position.x, y + 3 * u, lr.size.x, rh - 6 * u)
		if rr.position.y < lr.position.y - rh or rr.end.y > lr.end.y + rh:
			continue
		var hdr: bool = row.get("hdr", false)
		var dis: bool = row.get("dis", false)
		draw_rect(rr, Color(0.14, 0.16, 0.21, 0.95) if not hdr else Color(0.1, 0.11, 0.14, 0.9))
		var tc := Color(1, 1, 1) if not dis else Color(0.5, 0.5, 0.5)
		if hdr:
			tc = Color(1, 0.8, 0.2)
		_txt(str(row["t"]), rr.position + Vector2(18 * u, rr.size.y * 0.66), 24 * u, tc)
		if row.has("r"):
			_txt(str(row["r"]), rr.position + Vector2(0, rr.size.y * 0.66), 22 * u, Color(0.55, 0.95, 0.55) if not dis else Color(0.55, 0.4, 0.4), HORIZONTAL_ALIGNMENT_RIGHT, rr.size.x - 18 * u)
	var b := menu_back_rect()
	draw_rect(b, Color(0.15, 0.17, 0.22, 0.95))
	draw_rect(b, Color(1, 0.8, 0.2, 0.8), false, 2 * u)
	_txt("BACK", b.position + Vector2(0, b.size.y * 0.66), 24 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, b.size.x)

func _draw() -> void:
	if main == null:
		return
	var w := size.x
	var h := size.y
	if map_open:
		_draw_fullmap()
		return
	if menu_open:
		_draw_menu()
		return
	var cam_car = main.cur_car
	if flash > 0.0:
		draw_rect(Rect2(0, 0, w, h), Color(0.8, 0, 0, flash * 0.35))
	if cam_car == null and main.player_alive() and main.in_interior < 0:
		var c := Vector2(w * 0.5, h * 0.5)
		draw_arc(c, 9 * u, 0, TAU, 20, Color(1, 1, 1, 0.8), 1.8 * u)
		draw_circle(c, 1.6 * u, Color(1, 0.3, 0.2))
	# health / armor / weapon
	var hb := Rect2(16 * u, 200 * u, 176 * u, 12 * u)
	draw_rect(hb, Color(0, 0, 0, 0.6))
	draw_rect(Rect2(hb.position, Vector2(hb.size.x * clampf(main.player.health / 100.0, 0, 1), hb.size.y)), Color(0.85, 0.15, 0.15))
	if main.player.armor > 0.0:
		var ab := Rect2(16 * u, 216 * u, 176 * u, 8 * u)
		draw_rect(ab, Color(0, 0, 0, 0.6))
		draw_rect(Rect2(ab.position, Vector2(ab.size.x * clampf(main.player.armor / 100.0, 0, 1), ab.size.y)), Color(0.3, 0.55, 1.0))
	if cam_car == null:
		_txt(main.weapon_name(), Vector2(16 * u, 246 * u), 20 * u, Color(1, 1, 1))
	# phone button
	var pc := phone_rect()
	draw_circle(pc, 30 * u, Color(0.1, 0.12, 0.16, 0.8))
	draw_rect(Rect2(pc.x - 11 * u, pc.y - 18 * u, 22 * u, 36 * u), Color(0.8, 0.85, 0.9), false, 2.5 * u)
	draw_rect(Rect2(pc.x - 8 * u, pc.y - 13 * u, 16 * u, 22 * u), Color(0.2, 0.7, 0.9, 0.7))
	# money, time, wanted
	_txt("$" + str(main.money), Vector2(w - 296 * u, 50 * u), 30 * u, Color(0.55, 0.95, 0.55), HORIZONTAL_ALIGNMENT_RIGHT, 200 * u)
	_txt(main.time_text(), Vector2(w - 296 * u, 78 * u), 18 * u, Color(0.8, 0.85, 1.0), HORIZONTAL_ALIGNMENT_RIGHT, 200 * u)
	for i in range(5):
		var on: bool = i < main.wanted
		var flashing: bool = main.wanted > 0 and main.cop_seen_t < 4.0 and int(Time.get_ticks_msec() / 300.0) % 2 == 0
		var col := Color(1, 0.85, 0.1) if on else Color(1, 1, 1, 0.18)
		if on and flashing:
			col = Color(0.4, 0.5, 1.0)
		_star(Vector2(w - 190 * u + i * 30 * u, 112 * u), 12 * u, col)
	draw_circle(Vector2(w - 50 * u, 50 * u), 26 * u, Color(0, 0, 0, 0.45))
	draw_rect(Rect2(w - 58 * u, 38 * u, 6 * u, 24 * u), Color(1, 1, 1, 0.9))
	draw_rect(Rect2(w - 46 * u, 38 * u, 6 * u, 24 * u), Color(1, 1, 1, 0.9))
	# objective + GPS arrow
	if main.m_text != "":
		_txt(main.m_title, Vector2(0, 36 * u), 16 * u, Color(1, 0.8, 0.2), HORIZONTAL_ALIGNMENT_CENTER, w)
		_txt(main.m_text, Vector2(0, 62 * u), 22 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, w)
	var gp = main.gps_target()
	if gp != null and main.in_interior < 0:
		var pp: Vector3 = main.player_pos()
		var dv: Vector3 = gp - pp
		var dist := Vector2(dv.x, dv.z).length()
		var tyaw := atan2(-dv.x, -dv.z)
		var rel := tyaw - float(main.cam_yaw)
		var ac := Vector2(w * 0.5, 112 * u)
		var fwd := Vector2(-sin(rel), -cos(rel))
		var rt := Vector2(-fwd.y, fwd.x)
		draw_colored_polygon(PackedVector2Array([ac + fwd * 22 * u, ac - fwd * 12 * u + rt * 16 * u, ac - fwd * 4 * u, ac - fwd * 12 * u - rt * 16 * u]), Color(1, 0.85, 0.15, 0.95))
		_txt(str(int(dist)) + " m", ac + Vector2(-60 * u, 40 * u), 18 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, 120 * u)
	# speed
	if cam_car != null:
		var sp := str(int(cam_car.speed_kmh())) + " km/h"
		if cam_car.is_heli:
			sp += "   ALT " + str(int(cam_car.altitude())) + " m"
		_txt(sp, Vector2(w * 0.5 - 200 * u, h - 40 * u), 32 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, 400 * u)
		var cb := Rect2(w * 0.5 - 90 * u, h - 30 * u, 180 * u, 8 * u)
		draw_rect(cb, Color(0, 0, 0, 0.6))
		draw_rect(Rect2(cb.position, Vector2(cb.size.x * clampf(cam_car.health / cam_car.max_health, 0, 1), cb.size.y)), Color(0.9, 0.6, 0.15))
	# interaction prompt
	if main.prompt != "" and not main.prompt_hidden():
		_txt(main.prompt, Vector2(0, h - 190 * u), 24 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, w)
	# toasts
	var ty := h * 0.3
	for t in toasts:
		_txt(t[0], Vector2(0, ty), 24 * u, Color(1, 1, 1, clampf(t[1], 0.0, 1.0)), HORIZONTAL_ALIGNMENT_CENTER, w)
		ty += 32 * u
	if update_t > 0.0:
		var ur := update_rect()
		draw_rect(ur, Color(0.05, 0.25, 0.1, 0.9))
		draw_rect(ur, Color(0.4, 1.0, 0.5, 0.9), false, 2 * u)
		_txt(update_text, ur.position + Vector2(0, 34 * u), 21 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, ur.size.x)
		_txt("Tap to open GitHub (optional)", ur.position + Vector2(0, 66 * u), 16 * u, Color(0.8, 1.0, 0.8), HORIZONTAL_ALIGNMENT_CENTER, ur.size.x)
	# subtitles (non-blocking)
	var sy := h - 70 * u - subs.size() * 0.0
	var k := 0
	for sb in subs:
		var alpha := clampf(float(sb[2]), 0.0, 1.0)
		var line := str(sb[0]) + ": " + str(sb[1])
		var yy := sy - (subs.size() - 1 - k) * 30 * u
		draw_rect(Rect2(w * 0.5 - 360 * u, yy - 22 * u, 720 * u, 30 * u), Color(0, 0, 0, 0.45 * alpha))
		_txt(line, Vector2(w * 0.5 - 350 * u, yy), 20 * u, Color(1, 0.95, 0.75, alpha), HORIZONTAL_ALIGNMENT_LEFT, 700 * u)
		k += 1
	# controls
	if not paused:
		if stick_idx != -1:
			draw_circle(stick_center, 62 * u, Color(1, 1, 1, 0.10))
			draw_arc(stick_center, 62 * u, 0, TAU, 32, Color(1, 1, 1, 0.35), 2 * u)
			draw_circle(stick_center + Vector2(move.x, -move.y) * 62 * u, 26 * u, Color(1, 1, 1, 0.4))
		else:
			var hc := Vector2(130 * u, h - 130 * u)
			draw_arc(hc, 62 * u, 0, TAU, 32, Color(1, 1, 1, 0.18), 2 * u)
		for b in btn_list():
			var down := false
			for t in tmap.values():
				if t["role"] == "btn" and t["id"] == b["id"]:
					down = true
			var pulse := 0.0
			if b["id"] == "enter" and main.prompt != "":
				pulse = 0.25 + 0.2 * sin(Time.get_ticks_msec() / 150.0)
			draw_circle(b["pos"], b["r"], Color(1, 1, 1, (0.28 if down else 0.12) + pulse))
			draw_arc(b["pos"], b["r"], 0, TAU, 28, Color(1, 1, 1, 0.45), 2 * u)
			_txt(b["label"], b["pos"] + Vector2(-b["r"], 6 * u), b["r"] * 0.33, Color(1, 1, 1, 0.9), HORIZONTAL_ALIGNMENT_CENTER, b["r"] * 2.0)
	if banner_t > 0.0:
		draw_rect(Rect2(0, h * 0.4, w, 110 * u), Color(0, 0, 0, 0.55 * clampf(banner_t, 0, 1)))
		_txt(banner, Vector2(0, h * 0.4 + 76 * u), 64 * u, Color(0.9, 0.12, 0.12, clampf(banner_t, 0, 1)), HORIZONTAL_ALIGNMENT_CENTER, w)
	if title_t > 0.0:
		var a := clampf(title_t, 0.0, 1.0)
		draw_rect(Rect2(0, 0, w, h), Color(0, 0, 0, clampf(title_t - 3.5, 0.0, 1.0) * 0.85))
		_txt("IRON HARBOR", Vector2(0, h * 0.5), 76 * u, Color(0.95, 0.75, 0.15, a), HORIZONTAL_ALIGNMENT_CENTER, w)
	if fade_a > 0.0:
		draw_rect(Rect2(0, 0, w, h), Color(0, 0, 0, fade_a))
	if paused:
		draw_rect(Rect2(0, 0, w, h), Color(0, 0, 0, 0.7))
		_txt("PAUSED", Vector2(0, h * 0.5 - 150 * u), 48 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, w)
		var labels := ["RESUME", "GRAPHICS: " + main.quality_name(), "SAVE AND QUIT"]
		var rr := pause_rects()
		for i in range(3):
			draw_rect(rr[i], Color(0.15, 0.17, 0.22, 0.95))
			draw_rect(rr[i], Color(1, 0.8, 0.2, 0.8), false, 2 * u)
			_txt(labels[i], rr[i].position + Vector2(0, rr[i].size.y * 0.66), 26 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, rr[i].size.x)
