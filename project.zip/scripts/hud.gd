extends Control
# Touch controls + HUD (minimap, wanted stars, dialogue, pause menu).
const Cfg = preload("res://scripts/cfg.gd")

var main
var move := Vector2.ZERO
var look_accum := Vector2.ZERO
var b_fire := false
var b_gas := false
var b_brake := false
var b_hand := false
var ev := {}
var tmap := {}
var stick_center := Vector2.ZERO
var stick_idx := -1
var paused := false
var font: Font
var toasts: Array = []
var dlg: Array = []
var dlg_i := 0
var dlg_t := 0.0
var dlg_cb := Callable()
var title_t := 5.0
var flash := 0.0
var banner := ""
var banner_t := 0.0
var mm: Control
var u := 1.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	font = ThemeDB.fallback_font
	mm = Control.new()
	mm.clip_contents = true
	mm.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(mm)
	mm.draw.connect(_draw_map)

func take_look() -> Vector2:
	var l := look_accum
	look_accum = Vector2.ZERO
	return l

func consume(id: String) -> bool:
	if ev.has(id):
		ev.erase(id)
		return true
	return false

func toast(t: String) -> void:
	toasts.append([t, 3.5])
	if toasts.size() > 3:
		toasts.pop_front()

func show_banner(t: String, dur: float) -> void:
	banner = t
	banner_t = dur

func show_dialog(lines: Array, cb: Callable) -> void:
	dlg = lines.duplicate()
	dlg_i = 0
	dlg_t = 0.0
	dlg_cb = cb

func dialog_active() -> bool:
	return dlg_i < dlg.size()

func _next_line() -> void:
	dlg_i += 1
	dlg_t = 0.0
	if dlg_i >= dlg.size():
		dlg.clear()
		dlg_i = 0
		if dlg_cb.is_valid():
			dlg_cb.call()

# ---------------------------------------------------------------- layout
func btn_list() -> Array:
	var w := size.x
	var h := size.y
	var l: Array = []
	if main.cur_car != null:
		l.append({"id": "gas", "pos": Vector2(w - 150 * u, h - 170 * u), "r": 80 * u, "label": "GAS"})
		l.append({"id": "brake", "pos": Vector2(w - 340 * u, h - 110 * u), "r": 56 * u, "label": "BRAKE"})
		l.append({"id": "hand", "pos": Vector2(w - 330 * u, h - 250 * u), "r": 42 * u, "label": "DRIFT"})
		l.append({"id": "enter", "pos": Vector2(w - 80 * u, h - 340 * u), "r": 44 * u, "label": "EXIT"})
	else:
		l.append({"id": "fire", "pos": Vector2(w - 150 * u, h - 160 * u), "r": 76 * u, "label": "FIRE"})
		l.append({"id": "jump", "pos": Vector2(w - 310 * u, h - 90 * u), "r": 48 * u, "label": "JUMP"})
		l.append({"id": "enter", "pos": Vector2(w - 80 * u, h - 330 * u), "r": 46 * u, "label": "ENTER"})
		l.append({"id": "swap", "pos": Vector2(w - 270 * u, h - 240 * u), "r": 38 * u, "label": "GUN"})
	return l

func pause_rects() -> Array:
	var c := size * 0.5
	var bw := 360 * u
	var bh := 64 * u
	return [
		Rect2(c.x - bw * 0.5, c.y - 110 * u, bw, bh),
		Rect2(c.x - bw * 0.5, c.y - 30 * u, bw, bh),
		Rect2(c.x - bw * 0.5, c.y + 50 * u, bw, bh)]

func dlg_rect() -> Rect2:
	return Rect2(size.x * 0.15, size.y - 170 * u, size.x * 0.7, 120 * u)

# ---------------------------------------------------------------- input
func _input(event: InputEvent) -> void:
	if main == null:
		return
	if event is InputEventScreenTouch:
		var idx: int = event.index
		if event.pressed:
			_press(idx, event.position)
		else:
			_release(idx)
	elif event is InputEventScreenDrag:
		var idx2: int = event.index
		if tmap.has(idx2):
			var t: Dictionary = tmap[idx2]
			if t["role"] == "stick":
				var v: Vector2 = (event.position - stick_center) / (62.0 * u)
				v = v.limit_length(1.0)
				move = Vector2(v.x, -v.y)
			elif t["role"] == "look":
				look_accum += event.relative

func _press(idx: int, pos: Vector2) -> void:
	if paused:
		var r := pause_rects()
		if r[0].has_point(pos):
			set_paused(false)
		elif r[1].has_point(pos):
			main.cycle_quality()
		elif r[2].has_point(pos):
			main.save_game()
			get_tree().quit()
		return
	if pos.distance_to(Vector2(size.x - 50 * u, 50 * u)) < 34 * u:
		set_paused(true)
		return
	if dialog_active() and dlg_rect().has_point(pos):
		_next_line()
		return
	for b in btn_list():
		if pos.distance_to(b["pos"]) <= b["r"] * 1.15:
			tmap[idx] = {"role": "btn", "id": b["id"]}
			if b["id"] == "enter" or b["id"] == "jump" or b["id"] == "swap":
				ev[b["id"]] = true
			return
	if pos.x < size.x * 0.45:
		if stick_idx == -1:
			stick_idx = idx
			stick_center = pos
			tmap[idx] = {"role": "stick"}
	else:
		tmap[idx] = {"role": "look"}

func _release(idx: int) -> void:
	if tmap.has(idx):
		if tmap[idx]["role"] == "stick":
			stick_idx = -1
			move = Vector2.ZERO
		tmap.erase(idx)

func set_paused(p: bool) -> void:
	paused = p
	get_tree().paused = p
	if p:
		tmap.clear()
		stick_idx = -1
		move = Vector2.ZERO

# ---------------------------------------------------------------- update
func _process(delta: float) -> void:
	if main == null:
		return
	position = Vector2.ZERO
	size = get_viewport_rect().size
	u = maxf(0.5, size.y / 720.0)
	b_fire = false
	b_gas = false
	b_brake = false
	b_hand = false
	for t in tmap.values():
		if t["role"] == "btn":
			match t["id"]:
				"fire": b_fire = true
				"gas": b_gas = true
				"brake": b_brake = true
				"hand": b_hand = true
	# keyboard fallback (desktop testing)
	if stick_idx == -1:
		var kx := 0.0
		var ky := 0.0
		if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): kx += 1.0
		if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): kx -= 1.0
		if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): ky += 1.0
		if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): ky -= 1.0
		move = Vector2(kx, ky)
	if Input.is_key_pressed(KEY_SPACE):
		b_fire = true
		b_hand = true
	if Input.is_key_pressed(KEY_E):
		if not ev.has("kE"):
			ev["enter"] = true
			ev["kE"] = true
	else:
		ev.erase("kE")
	# dialogue timing
	if dialog_active():
		dlg_t += delta
		var txt: String = dlg[dlg_i][1]
		if dlg_t > 2.6 + txt.length() * 0.045:
			_next_line()
	title_t = maxf(0.0, title_t - delta)
	flash = maxf(0.0, flash - delta * 2.0)
	banner_t = maxf(0.0, banner_t - delta)
	for t in toasts:
		t[1] -= delta
	while toasts.size() > 0 and toasts[0][1] <= 0.0:
		toasts.pop_front()
	mm.position = Vector2(16 * u, 16 * u)
	mm.size = Vector2(176 * u, 176 * u)
	mm.queue_redraw()
	queue_redraw()

# ---------------------------------------------------------------- drawing helpers
func _txt(s: String, pos: Vector2, fs: float, col: Color, align := HORIZONTAL_ALIGNMENT_LEFT, w := -1.0) -> void:
	draw_string_outline(font, pos, s, align, w, int(fs), int(maxf(2.0, fs * 0.14)), Color(0, 0, 0, 0.85))
	draw_string(font, pos, s, align, w, int(fs), col)

func _star(c: Vector2, r: float, col: Color) -> void:
	var pts := PackedVector2Array()
	for i in range(10):
		var a := -PI * 0.5 + i * PI / 5.0
		var rr := r if i % 2 == 0 else r * 0.45
		pts.append(c + Vector2(cos(a), sin(a)) * rr)
	draw_colored_polygon(pts, col)

func _mp(wp: Vector3, pp: Vector3, yaw: float, c: Vector2, sc: float) -> Vector2:
	var rel := wp - pp
	var rt := rel.x * cos(yaw) - rel.z * sin(yaw)
	var up := -rel.x * sin(yaw) - rel.z * cos(yaw)
	return c + Vector2(rt * sc, -up * sc)

func _draw_map() -> void:
	var s := mm.size
	var c := s * 0.5
	var sc := 0.5 * u
	var yaw: float = main.cam_yaw
	var pp: Vector3 = main.player_pos()
	mm.draw_rect(Rect2(Vector2.ZERO, s), Color(0.05, 0.07, 0.1, 0.8))
	var rw := 15.0 * sc
	for i in range(-Cfg.GRID, Cfg.GRID + 1):
		var x := i * Cfg.P
		mm.draw_line(_mp(Vector3(x, 0, -330), pp, yaw, c, sc), _mp(Vector3(x, 0, 330), pp, yaw, c, sc), Color(0.42, 0.45, 0.5), rw)
		mm.draw_line(_mp(Vector3(-330, 0, x), pp, yaw, c, sc), _mp(Vector3(330, 0, x), pp, yaw, c, sc), Color(0.42, 0.45, 0.5), rw)
	if main.wanted > 0:
		for v in main.vehicles:
			if is_instance_valid(v) and v.mode == "police":
				mm.draw_circle(_mp(v.global_position, pp, yaw, c, sc), 3.5 * u, Color(1.0, 0.2, 0.2) if int(Time.get_ticks_msec() / 250.0) % 2 == 0 else Color(0.3, 0.4, 1.0))
	for t in main.get_targets():
		var p := _mp(t["pos"], pp, yaw, c, sc)
		var off := p - c
		var lim := s.x * 0.5 - 8 * u
		if absf(off.x) > lim or absf(off.y) > lim:
			off = off * (lim / maxf(absf(off.x), absf(off.y)))
		mm.draw_circle(c + off, 6 * u, t["color"])
		mm.draw_arc(c + off, 7.5 * u, 0, TAU, 16, Color(0, 0, 0, 0.8), 1.5 * u)
	var delta_a: float = main.player_heading() - yaw
	var v := Vector2(-sin(delta_a), -cos(delta_a))
	var pr := Vector2(-v.y, v.x)
	mm.draw_colored_polygon(PackedVector2Array([c + v * 10 * u, c - v * 6 * u + pr * 6 * u, c - v * 3 * u, c - v * 6 * u - pr * 6 * u]), Color(1, 1, 1))

func _draw() -> void:
	if main == null:
		return
	var w := size.x
	var h := size.y
	var cam_car = main.cur_car
	# damage flash
	if flash > 0.0:
		draw_rect(Rect2(0, 0, w, h), Color(0.8, 0, 0, flash * 0.35))
	# crosshair
	if cam_car == null and main.player_alive():
		var c := Vector2(w * 0.5, h * 0.5)
		draw_arc(c, 9 * u, 0, TAU, 20, Color(1, 1, 1, 0.8), 1.8 * u)
		draw_circle(c, 1.6 * u, Color(1, 0.3, 0.2))
	# health / armor
	var hb := Rect2(16 * u, 200 * u, 176 * u, 12 * u)
	draw_rect(hb, Color(0, 0, 0, 0.6))
	draw_rect(Rect2(hb.position, Vector2(hb.size.x * clampf(main.player.health / 100.0, 0, 1), hb.size.y)), Color(0.85, 0.15, 0.15))
	if main.player.armor > 0.0:
		var ab := Rect2(16 * u, 216 * u, 176 * u, 8 * u)
		draw_rect(ab, Color(0, 0, 0, 0.6))
		draw_rect(Rect2(ab.position, Vector2(ab.size.x * clampf(main.player.armor / 100.0, 0, 1), ab.size.y)), Color(0.3, 0.55, 1.0))
	# money and wanted
	_txt("$" + str(main.money), Vector2(w - 296 * u, 50 * u), 30 * u, Color(0.55, 0.95, 0.55), HORIZONTAL_ALIGNMENT_RIGHT, 200 * u)
	for i in range(5):
		var on: bool = i < main.wanted
		var flashing: bool = main.wanted > 0 and main.cop_seen_t < 3.0 and int(Time.get_ticks_msec() / 300.0) % 2 == 0
		var col := Color(1, 0.85, 0.1) if on else Color(1, 1, 1, 0.18)
		if on and flashing:
			col = Color(0.4, 0.5, 1.0)
		_star(Vector2(w - 190 * u + i * 30 * u, 82 * u), 12 * u, col)
	# pause button
	draw_circle(Vector2(w - 50 * u, 50 * u), 26 * u, Color(0, 0, 0, 0.45))
	draw_rect(Rect2(w - 58 * u, 38 * u, 6 * u, 24 * u), Color(1, 1, 1, 0.9))
	draw_rect(Rect2(w - 46 * u, 38 * u, 6 * u, 24 * u), Color(1, 1, 1, 0.9))
	# objective
	if main.m_text != "":
		_txt(main.m_title, Vector2(0, 40 * u), 17 * u, Color(1, 0.8, 0.2), HORIZONTAL_ALIGNMENT_CENTER, w)
		_txt(main.m_text, Vector2(0, 66 * u), 22 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, w)
	# speedometer
	if cam_car != null:
		_txt(str(int(cam_car.speed_kmh())) + " km/h", Vector2(w * 0.5 - 150 * u, h - 40 * u), 34 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, 300 * u)
		var cb := Rect2(w * 0.5 - 90 * u, h - 30 * u, 180 * u, 8 * u)
		draw_rect(cb, Color(0, 0, 0, 0.6))
		draw_rect(Rect2(cb.position, Vector2(cb.size.x * clampf(cam_car.health / 100.0, 0, 1), cb.size.y)), Color(0.9, 0.6, 0.15))
	# toasts
	var ty := h * 0.3
	for t in toasts:
		_txt(t[0], Vector2(0, ty), 24 * u, Color(1, 1, 1, clampf(t[1], 0.0, 1.0)), HORIZONTAL_ALIGNMENT_CENTER, w)
		ty += 32 * u
	# dialogue
	if dialog_active():
		var r := dlg_rect()
		draw_rect(r, Color(0.03, 0.04, 0.06, 0.82))
		draw_rect(Rect2(r.position, Vector2(6 * u, r.size.y)), Color(1, 0.8, 0.2))
		var line: Array = dlg[dlg_i]
		_txt(str(line[0]), r.position + Vector2(22 * u, 30 * u), 20 * u, Color(1, 0.8, 0.2))
		draw_multiline_string(font, r.position + Vector2(22 * u, 62 * u), str(line[1]), HORIZONTAL_ALIGNMENT_LEFT, r.size.x - 44 * u, int(22 * u), 3, Color(1, 1, 1))
		_txt("tap", Vector2(r.end.x - 120 * u, r.end.y - 10 * u), 14 * u, Color(1, 1, 1, 0.5), HORIZONTAL_ALIGNMENT_RIGHT, 100 * u)
	# controls
	if not paused:
		if stick_idx != -1:
			draw_circle(stick_center, 62 * u, Color(1, 1, 1, 0.10))
			draw_arc(stick_center, 62 * u, 0, TAU, 32, Color(1, 1, 1, 0.35), 2 * u)
			draw_circle(stick_center + Vector2(move.x, -move.y) * 62 * u, 26 * u, Color(1, 1, 1, 0.4))
		else:
			var hc := Vector2(130 * u, h - 130 * u)
			draw_arc(hc, 62 * u, 0, TAU, 32, Color(1, 1, 1, 0.18), 2 * u)
		for b in btn_list():
			var down := false
			for t in tmap.values():
				if t["role"] == "btn" and t["id"] == b["id"]:
					down = true
			draw_circle(b["pos"], b["r"], Color(1, 1, 1, 0.28 if down else 0.12))
			draw_arc(b["pos"], b["r"], 0, TAU, 28, Color(1, 1, 1, 0.45), 2 * u)
			_txt(b["label"], b["pos"] + Vector2(-b["r"], 6 * u), b["r"] * 0.33, Color(1, 1, 1, 0.9), HORIZONTAL_ALIGNMENT_CENTER, b["r"] * 2.0)
	# banner
	if banner_t > 0.0:
		draw_rect(Rect2(0, h * 0.4, w, 110 * u), Color(0, 0, 0, 0.55 * clampf(banner_t, 0, 1)))
		_txt(banner, Vector2(0, h * 0.4 + 76 * u), 64 * u, Color(0.9, 0.12, 0.12, clampf(banner_t, 0, 1)), HORIZONTAL_ALIGNMENT_CENTER, w)
	# title card
	if title_t > 0.0:
		var a := clampf(title_t, 0.0, 1.0)
		draw_rect(Rect2(0, 0, w, h), Color(0, 0, 0, clampf(title_t - 3.5, 0.0, 1.0) * 0.85))
		_txt("IRON HARBOR", Vector2(0, h * 0.5), 76 * u, Color(0.95, 0.75, 0.15, a), HORIZONTAL_ALIGNMENT_CENTER, w)
		_txt("Harbor City - the debt comes due", Vector2(0, h * 0.5 + 46 * u), 24 * u, Color(1, 1, 1, a), HORIZONTAL_ALIGNMENT_CENTER, w)
	# pause overlay
	if paused:
		draw_rect(Rect2(0, 0, w, h), Color(0, 0, 0, 0.7))
		_txt("PAUSED", Vector2(0, h * 0.5 - 150 * u), 48 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, w)
		var labels := ["RESUME", "GRAPHICS: " + main.quality_name(), "SAVE AND QUIT"]
		var rr := pause_rects()
		for i in range(3):
			draw_rect(rr[i], Color(0.15, 0.17, 0.22, 0.95))
			draw_rect(rr[i], Color(1, 0.8, 0.2, 0.8), false, 2 * u)
			_txt(labels[i], rr[i].position + Vector2(0, rr[i].size.y * 0.66), 26 * u, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, rr[i].size.x)
