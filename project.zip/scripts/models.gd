extends RefCounted
# Procedural models: lofted car bodies, merged pedestrian meshes, procedural audio.
const Sh = preload("res://scripts/shaders.gd")

static var _car := {}
static var _ped := {}
static var _wheel: StandardMaterial3D = null
static var _lights: ShaderMaterial = null
static var _snd := {}

# ---------------------------------------------------------------- helpers
static func _arr() -> Dictionary:
	return {"v": PackedVector3Array(), "n": PackedVector3Array(), "c": PackedColorArray(), "u": PackedVector2Array(), "i": PackedInt32Array()}

static func _add(d: Dictionary, src: Mesh, xf: Transform3D, col: Color, uv: Vector2) -> void:
	var a: Array = src.surface_get_arrays(0)
	var sv: PackedVector3Array = a[Mesh.ARRAY_VERTEX]
	var sn: PackedVector3Array = a[Mesh.ARRAY_NORMAL]
	var si: PackedInt32Array = a[Mesh.ARRAY_INDEX]
	var v: PackedVector3Array = d["v"]
	var n: PackedVector3Array = d["n"]
	var c: PackedColorArray = d["c"]
	var u: PackedVector2Array = d["u"]
	var ii: PackedInt32Array = d["i"]
	var base := v.size()
	for k in range(sv.size()):
		v.append(xf * sv[k])
		n.append((xf.basis * sn[k]).normalized())
		c.append(col)
		u.append(uv)
	for k in range(si.size()):
		ii.append(base + si[k])
	d["v"] = v
	d["n"] = n
	d["c"] = c
	d["u"] = u
	d["i"] = ii

static func _commit(m: ArrayMesh, d: Dictionary) -> void:
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = d["v"]
	arr[Mesh.ARRAY_NORMAL] = d["n"]
	arr[Mesh.ARRAY_COLOR] = d["c"]
	arr[Mesh.ARRAY_TEX_UV] = d["u"]
	arr[Mesh.ARRAY_INDEX] = d["i"]
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)

# ---------------------------------------------------------------- materials
static func wheel_mat() -> StandardMaterial3D:
	if _wheel == null:
		_wheel = StandardMaterial3D.new()
		_wheel.albedo_color = Color(0.05, 0.05, 0.055)
		_wheel.roughness = 0.9
	return _wheel

static func light_mat() -> ShaderMaterial:
	if _lights == null:
		_lights = ShaderMaterial.new()
		_lights.shader = Sh.get_shader("lights")
	return _lights

# ---------------------------------------------------------------- car
static func _stations(kind: int) -> Array:
	# z, half-width, y-bottom, y-belt, y-top, top-width ratio
	var s: Array = [
		[-2.20, 0.72, 0.36, 0.60, 0.60, 0.90],
		[-2.08, 0.82, 0.28, 0.68, 0.70, 0.92],
		[-1.50, 0.90, 0.26, 0.78, 0.80, 0.94],
		[-0.95, 0.93, 0.26, 0.84, 0.88, 0.94],
		[-0.15, 0.93, 0.26, 0.86, 1.36, 0.76],
		[0.60, 0.93, 0.26, 0.86, 1.40, 0.74],
		[1.05, 0.93, 0.26, 0.86, 1.38, 0.74],
		[1.70, 0.93, 0.26, 0.86, 0.96, 0.86],
		[2.05, 0.91, 0.28, 0.86, 0.90, 0.92],
		[2.20, 0.84, 0.34, 0.80, 0.82, 0.92],
		[2.26, 0.72, 0.42, 0.68, 0.68, 0.90],
	]
	if kind == 1:
		for r in s:
			r[4] = r[3] + (r[4] - r[3]) * 0.80
			r[2] -= 0.04
			r[1] *= 1.03
	elif kind == 2:
		s[7][4] = 1.28
		s[8][4] = 1.24
		s[9][4] = 1.12
		s[10][4] = 0.9
		for r in s:
			r[3] += 0.04
			if r[4] > r[3] + 0.3:
				r[4] += 0.12
	return s

static func _ring(r: Array) -> Array:
	var z: float = r[0]
	var hw: float = r[1]
	var yb: float = r[2]
	var ym: float = r[3]
	var yt: float = r[4]
	var tw: float = r[5]
	return [
		Vector3(-hw * 0.88, yb, z), Vector3(hw * 0.88, yb, z),
		Vector3(hw, yb + 0.14, z), Vector3(hw, ym, z),
		Vector3(hw * tw, yt, z), Vector3(-hw * tw, yt, z),
		Vector3(-hw, ym, z), Vector3(-hw, yb + 0.14, z)]

static func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, outward: Vector3, col: Color, grp: int) -> void:
	var n := (b - a).cross(c - a)
	var o := [a, b, c]
	if n.dot(outward) > 0.0:
		o = [a, c, b]
	for v in o:
		st.set_smooth_group(grp)
		st.set_color(col)
		st.add_vertex(v)

static func _quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, col: Color, grp: int) -> void:
	var ctr := (a + b + c + d) * 0.25
	var outward := ctr - Vector3(0.0, 0.7, ctr.z)
	_tri(st, a, b, c, outward, col, grp)
	_tri(st, a, c, d, outward, col, grp)

static func car_mesh(kind: int) -> ArrayMesh:
	if _car.has(kind):
		return _car[kind]
	var s := _stations(kind)
	var rings: Array = []
	for r in s:
		rings.append(_ring(r))
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var paint := Color(1, 1, 1)
	var glass := Color(0.1, 0.12, 0.15)
	var grp := [4, 1, 1, 2, 3, 2, 1, 1]
	for si in range(rings.size() - 1):
		var ra: Array = rings[si]
		var rb: Array = rings[si + 1]
		for e in range(8):
			var e2 := (e + 1) % 8
			var col := paint
			if si >= 3 and si <= 6:
				if e == 3 or e == 5:
					col = glass
				elif e == 4 and (si == 3 or si == 6):
					col = glass
			_quad(st, ra[e], ra[e2], rb[e2], rb[e], col, grp[e])
	# end caps
	for cap in range(2):
		var ring: Array = rings[0] if cap == 0 else rings[rings.size() - 1]
		var ctr := Vector3.ZERO
		for p in ring:
			ctr += p
		ctr /= 8.0
		var outw := Vector3(0, 0, -1) if cap == 0 else Vector3(0, 0, 1)
		for e in range(8):
			_tri(st, ctr, ring[e], ring[(e + 1) % 8], outw, paint, -1)
	st.generate_normals()
	var mesh := ArrayMesh.new()
	st.commit(mesh)
	# wheels
	var wd := _arr()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.34
	cyl.bottom_radius = 0.34
	cyl.height = 0.26
	cyl.radial_segments = 14
	cyl.rings = 1
	var rot := Basis(Vector3(0, 0, 1), PI * 0.5)
	var wz: float = 1.38
	var wy: float = 0.34
	var wx: float = 0.84
	if kind == 1:
		wy = 0.33
	for sx in [-1.0, 1.0]:
		for z in [-wz, wz]:
			_add(wd, cyl, Transform3D(rot, Vector3(sx * wx, wy, z)), Color(1, 1, 1), Vector2.ZERO)
	_commit(mesh, wd)
	# lights
	var ld := _arr()
	var hb := BoxMesh.new()
	hb.size = Vector3(0.32, 0.13, 0.05)
	var tb := BoxMesh.new()
	tb.size = Vector3(0.4, 0.12, 0.05)
	for sx in [-1.0, 1.0]:
		_add(ld, hb, Transform3D(Basis.IDENTITY, Vector3(sx * 0.55, 0.64, -2.205)), Color(1.0, 0.95, 0.8), Vector2.ZERO)
		_add(ld, tb, Transform3D(Basis.IDENTITY, Vector3(sx * 0.6, 0.72, 2.27)), Color(1.0, 0.05, 0.05), Vector2.ZERO)
	_commit(mesh, ld)
	_car[kind] = mesh
	return mesh

# ---------------------------------------------------------------- pedestrian
static func ped_mesh(armed: bool) -> ArrayMesh:
	var key := 1 if armed else 0
	if _ped.has(key):
		return _ped[key]
	var d := _arr()
	var w := Color(1, 1, 1)
	var head := SphereMesh.new()
	head.radius = 0.115
	head.height = 0.23
	head.radial_segments = 12
	head.rings = 6
	_add(d, head, Transform3D(Basis.IDENTITY, Vector3(0, 1.66, 0)), w, Vector2(0, 0))
	var torso := CapsuleMesh.new()
	torso.radius = 0.17
	torso.height = 0.68
	torso.radial_segments = 12
	torso.rings = 4
	_add(d, torso, Transform3D(Basis.from_scale(Vector3(1.0, 1.0, 0.62)), Vector3(0, 1.12, 0)), w, Vector2(1, 0))
	var arm := CapsuleMesh.new()
	arm.radius = 0.055
	arm.height = 0.62
	arm.radial_segments = 8
	arm.rings = 3
	_add(d, arm, Transform3D(Basis.IDENTITY, Vector3(-0.245, 1.12, 0)), w, Vector2(2, 0))
	_add(d, arm, Transform3D(Basis.IDENTITY, Vector3(0.245, 1.12, 0)), w, Vector2(3, 0))
	var leg := CapsuleMesh.new()
	leg.radius = 0.085
	leg.height = 0.92
	leg.radial_segments = 8
	leg.rings = 3
	_add(d, leg, Transform3D(Basis.IDENTITY, Vector3(-0.1, 0.46, 0)), w, Vector2(4, 0))
	_add(d, leg, Transform3D(Basis.IDENTITY, Vector3(0.1, 0.46, 0)), w, Vector2(5, 0))
	if armed:
		var gun := BoxMesh.new()
		gun.size = Vector3(0.05, 0.1, 0.3)
		_add(d, gun, Transform3D(Basis.IDENTITY, Vector3(0.245, 0.98, -0.2)), w, Vector2(6, 0))
	var mesh := ArrayMesh.new()
	_commit(mesh, d)
	_ped[key] = mesh
	return mesh

# ---------------------------------------------------------------- audio
static func _wav(data: PackedByteArray, rate: int, loop: bool) -> AudioStreamWAV:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = data.size() / 2
	return w

static func sound(name: String) -> AudioStreamWAV:
	if _snd.has(name):
		return _snd[name]
	var rate := 22050
	var out: AudioStreamWAV
	if name == "engine":
		var n := 245 * 9
		var data := PackedByteArray()
		data.resize(n * 2)
		for i in range(n):
			var ph := TAU * float(i) / 245.0
			var v := (sin(ph) + 0.6 * sin(2.0 * ph) + 0.45 * sin(3.0 * ph) + 0.25 * sin(5.0 * ph) + 0.15 * sin(7.0 * ph)) * 0.42
			data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 8000.0))
		out = _wav(data, rate, true)
	elif name == "siren":
		var n := rate
		var data := PackedByteArray()
		data.resize(n * 2)
		for i in range(n):
			var t := float(i) / float(rate)
			var ph := TAU * 800.0 * t + 300.0 * (1.0 - cos(TAU * t))
			var v := sin(ph) * 0.6 + sin(ph * 2.0) * 0.2
			data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 6000.0))
		out = _wav(data, rate, true)
	else:
		var dur := 0.3
		var low := 0.0
		if name == "shot":
			dur = 0.22
		elif name == "smg":
			dur = 0.12
		elif name == "enemy":
			dur = 0.2
			low = 0.3
		elif name == "crash":
			dur = 0.45
			low = 1.0
		elif name == "boom":
			dur = 1.2
			low = 1.0
		var n := int(rate * dur)
		var data := PackedByteArray()
		data.resize(n * 2)
		var lp := 0.0
		for i in range(n):
			var t := float(i) / float(rate)
			var nz := randf() * 2.0 - 1.0
			var env := exp(-t * (14.0 if low < 0.5 else 5.0))
			var v := 0.0
			if low > 0.5:
				lp = lp + (nz - lp) * 0.12
				v = lp * 2.2 * env
			else:
				v = nz * env + sin(TAU * 70.0 * t) * exp(-t * 30.0) * 0.8
			data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 14000.0))
		out = _wav(data, rate, false)
	_snd[name] = out
	return out
