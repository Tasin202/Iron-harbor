extends RefCounted
# Procedural models: humans (jointed, lathe-built), detailed cars, tank, helicopters, audio.
const Sh = preload("res://scripts/shaders.gd")

static var _car := {}
static var _ped := {}
static var _misc := {}
static var _trim: StandardMaterial3D = null
static var _lights: ShaderMaterial = null
static var _snd := {}

# ---------------------------------------------------------------- geometry helpers
static func _arr() -> Dictionary:
	return {"v": PackedVector3Array(), "n": PackedVector3Array(), "c": PackedColorArray(), "u": PackedVector2Array(), "i": PackedInt32Array()}

static func _add(d: Dictionary, src: Mesh, xf: Transform3D, col: Color, uv: Vector2) -> void:
	var a: Array = src.surface_get_arrays(0)
	var sv: PackedVector3Array = a[Mesh.ARRAY_VERTEX]
	var sn: PackedVector3Array = a[Mesh.ARRAY_NORMAL]
	var si: PackedInt32Array = a[Mesh.ARRAY_INDEX]
	var v: PackedVector3Array = d["v"]
	var n: PackedVector3Array = d["n"]
	var c: PackedColorArray = d["c"]
	var u: PackedVector2Array = d["u"]
	var ii: PackedInt32Array = d["i"]
	var base := v.size()
	for k in range(sv.size()):
		v.append(xf * sv[k])
		n.append((xf.basis * sn[k]).normalized())
		c.append(col)
		u.append(uv)
	for k in range(si.size()):
		ii.append(base + si[k])
	d["v"] = v
	d["n"] = n
	d["c"] = c
	d["u"] = u
	d["i"] = ii

static func _box(d: Dictionary, pos: Vector3, size: Vector3, col: Color, uv := Vector2.ZERO, rot := Basis.IDENTITY) -> void:
	var bm := BoxMesh.new()
	bm.size = size
	_add(d, bm, Transform3D(rot, pos), col, uv)

static func _cyl_x(d: Dictionary, pos: Vector3, r: float, h: float, col: Color, seg := 14) -> void:
	var cm := CylinderMesh.new()
	cm.top_radius = r
	cm.bottom_radius = r
	cm.height = h
	cm.radial_segments = seg
	cm.rings = 1
	_add(d, cm, Transform3D(Basis(Vector3(0, 0, 1), PI * 0.5), pos), col, Vector2.ZERO)

static func _commit(m: ArrayMesh, d: Dictionary) -> void:
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = d["v"]
	arr[Mesh.ARRAY_NORMAL] = d["n"]
	arr[Mesh.ARRAY_COLOR] = d["c"]
	arr[Mesh.ARRAY_TEX_UV] = d["u"]
	arr[Mesh.ARRAY_INDEX] = d["i"]
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)

# Lathe: elliptical cross-sections stacked along Y. prof = [[y, rx, rz], ...] with ascending y.
static func _lathe(d: Dictionary, cen: Vector3, prof: Array, seg: int, uv: Vector2, col: Color) -> void:
	var v: PackedVector3Array = d["v"]
	var n: PackedVector3Array = d["n"]
	var c: PackedColorArray = d["c"]
	var u: PackedVector2Array = d["u"]
	var ii: PackedInt32Array = d["i"]
	var base := v.size()
	var rings := prof.size()
	for r in range(rings):
		var y: float = prof[r][0]
		var rx: float = prof[r][1]
		var rz: float = prof[r][2]
		var dr := 0.0
		if r < rings - 1:
			dr = (float(prof[r + 1][1]) - rx) / maxf(0.0001, float(prof[r + 1][0]) - y)
		elif rings > 1:
			dr = (rx - float(prof[r - 1][1])) / maxf(0.0001, y - float(prof[r - 1][0]))
		for s in range(seg + 1):
			var a := TAU * float(s) / float(seg)
			var ca := cos(a)
			var sa := sin(a)
			v.append(cen + Vector3(ca * rx, y, sa * rz))
			n.append(Vector3(ca, -dr, sa).normalized())
			c.append(col)
			u.append(uv)
	for r in range(rings - 1):
		for s in range(seg):
			var i0 := base + r * (seg + 1) + s
			var i1 := i0 + 1
			var i2 := i0 + (seg + 1)
			var i3 := i2 + 1
			_idx_tri(v, n, ii, i0, i1, i3)
			_idx_tri(v, n, ii, i0, i3, i2)
	d["v"] = v
	d["n"] = n
	d["c"] = c
	d["u"] = u
	d["i"] = ii

static func _idx_tri(v: PackedVector3Array, n: PackedVector3Array, ii: PackedInt32Array, a: int, b: int, c: int) -> void:
	var cr := (v[b] - v[a]).cross(v[c] - v[a])
	var nn := n[a] + n[b] + n[c]
	if cr.dot(nn) > 0.0:
		ii.append(a)
		ii.append(c)
		ii.append(b)
	else:
		ii.append(a)
		ii.append(b)
		ii.append(c)

static func _ellipsoid(d: Dictionary, cen: Vector3, rx: float, ry: float, rz: float, seg: int, rings: int, uv: Vector2, tmin := -1.0, tmax := 1.0) -> void:
	var prof: Array = []
	var p0 := asin(clampf(tmin, -1.0, 1.0))
	var p1 := asin(clampf(tmax, -1.0, 1.0))
	for i in range(rings + 1):
		var ph := lerpf(p0, p1, float(i) / float(rings))
		prof.append([ry * sin(ph), maxf(rx * cos(ph), 0.003), maxf(rz * cos(ph), 0.003)])
	_lathe(d, cen, prof, seg, uv, Color(1, 1, 1))

# ---------------------------------------------------------------- materials
static func trim_mat() -> StandardMaterial3D:
	if _trim == null:
		_trim = StandardMaterial3D.new()
		_trim.vertex_color_use_as_albedo = true
		_trim.roughness = 0.5
		_trim.metallic = 0.3
	return _trim

static func light_mat() -> ShaderMaterial:
	if _lights == null:
		_lights = ShaderMaterial.new()
		_lights.shader = Sh.get_shader("lights")
	return _lights

# ---------------------------------------------------------------- human
static func ped_mesh(armed: bool) -> ArrayMesh:
	var key := 1 if armed else 0
	if _ped.has(key):
		return _ped[key]
	var d := _arr()
	var w := Color(1, 1, 1)
	# head, neck, face, hair
	_ellipsoid(d, Vector3(0, 1.69, 0), 0.088, 0.114, 0.1, 14, 8, Vector2(0, 0))
	_lathe(d, Vector3(0, 0, 0), [[1.5, 0.06, 0.058], [1.62, 0.05, 0.05]], 10, Vector2(0, 0), w)
	_box(d, Vector3(0, 1.675, -0.105), Vector3(0.026, 0.045, 0.04), w, Vector2(0, 0))
	_box(d, Vector3(-0.036, 1.7, -0.092), Vector3(0.02, 0.012, 0.012), w, Vector2(5, 0))
	_box(d, Vector3(0.036, 1.7, -0.092), Vector3(0.02, 0.012, 0.012), w, Vector2(5, 0))
	_ellipsoid(d, Vector3(0, 1.71, 0.012), 0.097, 0.118, 0.11, 14, 6, Vector2(4, 0), 0.08, 1.0)
	# pelvis and torso
	_lathe(d, Vector3(0, 0, 0), [[0.82, 0.165, 0.11], [0.9, 0.172, 0.118], [0.98, 0.15, 0.108]], 14, Vector2(2, 0), w)
	_lathe(d, Vector3(0, 0, 0), [[0.96, 0.152, 0.106], [1.1, 0.142, 0.1], [1.26, 0.178, 0.116], [1.4, 0.205, 0.122], [1.48, 0.19, 0.104], [1.52, 0.07, 0.065]], 16, Vector2(1, 0), w)
	# legs (group 1,2 = left thigh, shin; 3,4 = right)
	for side in [-1, 1]:
		var x = 0.095 * side
		var gt = 1.0 if side < 0 else 3.0
		_lathe(d, Vector3(x, 0, 0), [[0.47, 0.062, 0.066], [0.68, 0.078, 0.082], [0.92, 0.09, 0.095]], 10, Vector2(2, gt), w)
		_lathe(d, Vector3(x, 0, 0), [[0.1, 0.044, 0.046], [0.3, 0.052, 0.058], [0.49, 0.062, 0.066]], 10, Vector2(2, gt + 1.0), w)
		_box(d, Vector3(x, 0.042, -0.05), Vector3(0.096, 0.085, 0.27), w, Vector2(3, gt + 1.0))
	# arms (group 5,6 left; 7,8 right)
	for side in [-1, 1]:
		var ax = 0.215 * side
		var ga = 5.0 if side < 0 else 7.0
		_lathe(d, Vector3(ax, 0, 0), [[1.14, 0.038, 0.04], [1.3, 0.044, 0.046], [1.45, 0.05, 0.05]], 9, Vector2(1, ga), w)
		_lathe(d, Vector3(ax, 0, 0), [[0.9, 0.028, 0.03], [1.02, 0.034, 0.036], [1.15, 0.038, 0.04]], 9, Vector2(6, ga + 1.0), w)
		_ellipsoid(d, Vector3(ax, 0.86, 0), 0.034, 0.05, 0.026, 8, 4, Vector2(0, ga + 1.0))
	if armed:
		_box(d, Vector3(0.215, 0.8, -0.015), Vector3(0.04, 0.2, 0.06), w, Vector2(5, 8))
		_box(d, Vector3(0.215, 0.74, -0.04), Vector3(0.03, 0.12, 0.05), w, Vector2(5, 8))
	var mesh := ArrayMesh.new()
	_commit(mesh, d)
	_ped[key] = mesh
	return mesh

# ---------------------------------------------------------------- cars
static func _base_stations() -> Array:
	# z, half-width, y-bottom, y-belt, y-top, top-width ratio
	return [
		[-2.20, 0.72, 0.36, 0.60, 0.60, 0.90],
		[-2.08, 0.82, 0.28, 0.68, 0.70, 0.92],
		[-1.50, 0.90, 0.26, 0.78, 0.80, 0.94],
		[-0.95, 0.93, 0.26, 0.84, 0.88, 0.94],
		[-0.15, 0.93, 0.26, 0.86, 1.36, 0.76],
		[0.60, 0.93, 0.26, 0.86, 1.40, 0.74],
		[1.05, 0.93, 0.26, 0.86, 1.38, 0.74],
		[1.70, 0.93, 0.26, 0.86, 0.96, 0.86],
		[2.05, 0.91, 0.28, 0.86, 0.90, 0.92],
		[2.20, 0.84, 0.34, 0.80, 0.82, 0.92],
		[2.26, 0.72, 0.42, 0.68, 0.68, 0.90],
	]

static func _params(kind: int) -> Dictionary:
	var st := _base_stations()
	var gs: Array = [3, 4, 5, 6]
	var gt: Array = [3, 6]
	var wr := 0.34
	var wzf := -1.38
	var wzr := 1.38
	var wx := 0.84
	match kind:
		1:
			for r in st:
				r[4] = r[3] + (r[4] - r[3]) * 0.8
				r[2] -= 0.04
				r[1] *= 1.03
		2:
			st[7][4] = 1.28
			st[8][4] = 1.24
			st[9][4] = 1.12
			st[10][4] = 0.9
			for r in st:
				r[3] += 0.05
				if r[4] > r[3] + 0.3:
					r[4] += 0.18
				r[0] *= 1.04
			wr = 0.39
			wzf = -1.45
			wzr = 1.4
		3:
			for r in st:
				r[0] *= 1.08
				r[4] = r[3] + (r[4] - r[3]) * 0.82
				r[3] += 0.02
				r[1] *= 1.04
			wzf = -1.55
			wzr = 1.5
		4:
			for r in st:
				var cab: float = r[4] - r[3]
				r[0] *= 0.96
				r[3] -= 0.1
				r[2] -= 0.09
				r[4] = r[3] + cab * 0.62
				r[1] *= 1.1
			wr = 0.35
			wzf = -1.35
			wzr = 1.35
			wx = 0.9
		5:
			for r in st:
				r[0] *= 1.12
				r[2] += 0.1
				r[3] += 0.1
				if r[4] > r[3] + 0.3:
					r[4] += 0.1
			for i in range(7, 11):
				st[i][4] = st[i][3]
			wr = 0.4
			wzf = -1.7
			wzr = 1.6
		6:
			st = [[-2.55, 0.78, 0.45, 0.85, 0.85, 0.92], [-2.42, 0.92, 0.32, 0.95, 1.05, 0.94], [-1.5, 0.98, 0.3, 1.05, 2.15, 0.9], [-0.3, 0.98, 0.3, 1.05, 2.2, 0.9], [2.2, 0.98, 0.3, 1.05, 2.2, 0.92], [2.5, 0.96, 0.32, 1.0, 2.0, 0.92], [2.6, 0.88, 0.42, 0.92, 1.1, 0.9]]
			gs = [2]
			gt = [1]
			wr = 0.38
			wzf = -1.8
			wzr = 1.7
			wx = 0.9
		7:
			st = [[-5.1, 0.98, 0.5, 1.1, 1.1, 0.95], [-4.98, 1.22, 0.35, 1.9, 2.0, 0.97], [-4.75, 1.28, 0.3, 1.9, 3.1, 0.97], [-3.6, 1.28, 0.3, 1.9, 3.15, 0.97], [4.7, 1.28, 0.3, 1.9, 3.15, 0.97], [4.95, 1.25, 0.35, 1.85, 3.0, 0.96], [5.1, 1.1, 0.45, 1.3, 1.6, 0.9]]
			gs = [2, 3, 4]
			gt = [1]
			wr = 0.5
			wzf = -3.5
			wzr = 3.3
			wx = 1.2
	return {"st": st, "gs": gs, "gt": gt, "wr": wr, "wzf": wzf, "wzr": wzr, "wx": wx}

static func _ring(r: Array) -> Array:
	var z: float = r[0]
	var hw: float = r[1]
	var yb: float = r[2]
	var ym: float = r[3]
	var yt: float = r[4]
	var tw: float = r[5]
	return [
		Vector3(-hw * 0.88, yb, z), Vector3(hw * 0.88, yb, z),
		Vector3(hw, yb + 0.14, z), Vector3(hw, ym, z),
		Vector3(hw * tw, yt, z), Vector3(-hw * tw, yt, z),
		Vector3(-hw, ym, z), Vector3(-hw, yb + 0.14, z)]

static func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, outward: Vector3, col: Color, grp: int) -> void:
	var n := (b - a).cross(c - a)
	var o := [a, b, c]
	if n.dot(outward) > 0.0:
		o = [a, c, b]
	for v in o:
		st.set_smooth_group(grp)
		st.set_color(col)
		st.add_vertex(v)

static func _quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, col: Color, grp: int) -> void:
	var ctr := (a + b + c + d) * 0.25
	var outward := ctr - Vector3(0.0, 0.7, ctr.z)
	_tri(st, a, b, c, outward, col, grp)
	_tri(st, a, c, d, outward, col, grp)

static func car_mesh(kind: int) -> ArrayMesh:
	if _car.has(kind):
		return _car[kind]
	var P := _params(kind)
	var s: Array = P["st"]
	var rings: Array = []
	for r in s:
		rings.append(_ring(r))
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var paint := Color(1, 1, 1)
	var glass := Color(0.1, 0.12, 0.15)
	var grp := [4, 1, 1, 2, 3, 2, 1, 1]
	var gs: Array = P["gs"]
	var gt: Array = P["gt"]
	for si in range(rings.size() - 1):
		var ra: Array = rings[si]
		var rb: Array = rings[si + 1]
		for e in range(8):
			var e2 := (e + 1) % 8
			var col := paint
			if gs.has(si) and (e == 3 or e == 5):
				col = glass
			elif gt.has(si) and e == 4:
				col = glass
			_quad(st, ra[e], ra[e2], rb[e2], rb[e], col, grp[e])
	for cap in range(2):
		var ring: Array = rings[0] if cap == 0 else rings[rings.size() - 1]
		var ctr := Vector3.ZERO
		for p in ring:
			ctr += p
		ctr /= 8.0
		var outw := Vector3(0, 0, -1) if cap == 0 else Vector3(0, 0, 1)
		for e in range(8):
			_tri(st, ctr, ring[e], ring[(e + 1) % 8], outw, paint, -1)
	st.generate_normals()
	var mesh := ArrayMesh.new()
	st.commit(mesh)
	# ---- trim: tires, rims, arches, mirrors, grille, bumpers, plates, seams
	var td := _arr()
	var wr: float = P["wr"]
	var wx: float = P["wx"]
	var fz: float = s[0][0]
	var rz: float = s[s.size() - 1][0]
	var hw := 0.0
	var roof := 0.0
	for r in s:
		hw = maxf(hw, float(r[1]))
		roof = maxf(roof, float(r[4]))
	var tire_h := 0.26 if kind != 7 else 0.36
	for sx in [-1.0, 1.0]:
		for z in [P["wzf"], P["wzr"]]:
			_cyl_x(td, Vector3(sx * wx, wr, z), wr, tire_h, Color(0.04, 0.04, 0.045))
			_cyl_x(td, Vector3(sx * (wx + tire_h * 0.5 - 0.01), wr, z), wr * 0.62, 0.03, Color(0.72, 0.74, 0.78))
			_cyl_x(td, Vector3(sx * (hw - 0.005), wr, z), wr * 1.3, 0.03, Color(0.02, 0.02, 0.025))
	var belt: float = s[3][3]
	var mir_z: float = s[3][0]
	_box(td, Vector3(-hw - 0.06, belt + 0.14, mir_z), Vector3(0.12, 0.08, 0.14), Color(0.03, 0.03, 0.035))
	_box(td, Vector3(hw + 0.06, belt + 0.14, mir_z), Vector3(0.12, 0.08, 0.14), Color(0.03, 0.03, 0.035))
	_box(td, Vector3(0, 0.46, fz - 0.015), Vector3(0.82, 0.13, 0.03), Color(0.02, 0.02, 0.02))
	_box(td, Vector3(0, 0.34, fz - 0.03), Vector3(hw * 1.7, 0.1, 0.1), Color(0.05, 0.05, 0.06))
	_box(td, Vector3(0, 0.42, rz + 0.03), Vector3(hw * 1.7, 0.1, 0.1), Color(0.05, 0.05, 0.06))
	_box(td, Vector3(0, 0.37, fz - 0.09), Vector3(0.32, 0.09, 0.012), Color(0.92, 0.92, 0.9))
	_box(td, Vector3(0, 0.5, rz + 0.07), Vector3(0.32, 0.09, 0.012), Color(0.92, 0.92, 0.9))
	var seam_h := belt - 0.32
	for sx in [-1.0, 1.0]:
		var zs: Array = [s[4][0] + 0.2, s[4][0] + 1.5] if kind < 5 else [s[3][0] + 0.9, s[3][0] + 1.4]
		for zz in zs:
			_box(td, Vector3(sx * (hw + 0.004), 0.32 + seam_h * 0.5 + 0.12, zz), Vector3(0.01, seam_h, 0.012), Color(0.02, 0.02, 0.02))
		_box(td, Vector3(sx * (hw + 0.012), belt - 0.06, float(zs[0]) + 0.32), Vector3(0.02, 0.03, 0.12), Color(0.7, 0.72, 0.76))
	if kind == 5:
		# pickup bed walls
		var bz0: float = s[7][0]
		var bz1: float = rz
		_box(td, Vector3(-hw + 0.04, belt + 0.18, (bz0 + bz1) * 0.5), Vector3(0.06, 0.36, bz1 - bz0), Color(0.08, 0.08, 0.09))
		_box(td, Vector3(hw - 0.04, belt + 0.18, (bz0 + bz1) * 0.5), Vector3(0.06, 0.36, bz1 - bz0), Color(0.08, 0.08, 0.09))
		_box(td, Vector3(0, belt + 0.18, bz1 - 0.04), Vector3(hw * 1.9, 0.36, 0.06), Color(0.08, 0.08, 0.09))
		_box(td, Vector3(0, belt + 0.18, bz0 + 0.04), Vector3(hw * 1.9, 0.36, 0.06), Color(0.08, 0.08, 0.09))
	if kind == 4:
		_box(td, Vector3(0, roof - 0.28, rz - 0.15), Vector3(hw * 1.8, 0.04, 0.34), Color(0.03, 0.03, 0.04))
		for sx in [-1.0, 1.0]:
			_box(td, Vector3(sx * hw * 0.75, roof - 0.4, rz - 0.15), Vector3(0.04, 0.2, 0.3), Color(0.03, 0.03, 0.04))
	if kind == 7:
		# bus: door panels and destination sign
		_box(td, Vector3(hw + 0.01, 1.3, -3.9), Vector3(0.02, 2.2, 1.1), Color(0.03, 0.03, 0.04))
		_box(td, Vector3(0, 2.85, fz + 0.15), Vector3(1.6, 0.3, 0.03), Color(0.9, 0.55, 0.1))
	_commit(mesh, td)
	# ---- lights
	var ld := _arr()
	var hl := Vector3(hw * 0.6, belt - 0.2, fz - 0.005)
	for sx in [-1.0, 1.0]:
		_box(ld, Vector3(sx * hl.x, hl.y, hl.z), Vector3(0.32, 0.13, 0.05), Color(1.0, 0.95, 0.8))
		_box(ld, Vector3(sx * hw * 0.66, belt - 0.1, rz + 0.01), Vector3(0.4, 0.12, 0.05), Color(1.0, 0.05, 0.05))
	_commit(mesh, ld)
	_car[kind] = mesh
	return mesh

# ---------------------------------------------------------------- tank
static func tank_hull() -> ArrayMesh:
	if _misc.has("hull"):
		return _misc["hull"]
	var d := _arr()
	var ol := Color(0.27, 0.31, 0.2)
	var dk := Color(0.12, 0.13, 0.1)
	_box(d, Vector3(0, 1.1, 0), Vector3(2.7, 0.8, 6.0), ol)
	_box(d, Vector3(0, 1.35, -2.8), Vector3(2.6, 0.5, 1.4), ol, Vector2.ZERO, Basis(Vector3(1, 0, 0), -0.5))
	_box(d, Vector3(0, 0.9, 3.0), Vector3(2.5, 0.8, 0.5), ol)
	for sx in [-1.0, 1.0]:
		_box(d, Vector3(sx * 1.55, 0.65, 0), Vector3(0.9, 1.1, 6.6), dk)
		_box(d, Vector3(sx * 1.55, 1.25, 0), Vector3(1.0, 0.12, 6.9), ol)
		for i in range(7):
			_cyl_x(d, Vector3(sx * 1.55, 0.5, -2.7 + i * 0.9), 0.42, 0.95, Color(0.07, 0.07, 0.07), 10)
	var m := ArrayMesh.new()
	_commit(m, d)
	_misc["hull"] = m
	return m

static func tank_turret() -> ArrayMesh:
	if _misc.has("turret"):
		return _misc["turret"]
	var d := _arr()
	var ol := Color(0.3, 0.34, 0.22)
	_box(d, Vector3(0, 0.0, 0.2), Vector3(2.3, 0.8, 2.8), ol)
	_box(d, Vector3(0, 0.1, -1.3), Vector3(1.0, 0.6, 0.6), ol)
	_box(d, Vector3(0.6, 0.55, 0.5), Vector3(0.6, 0.3, 0.6), Color(0.15, 0.17, 0.12))
	var cm := CylinderMesh.new()
	cm.top_radius = 0.11
	cm.bottom_radius = 0.13
	cm.height = 4.2
	cm.radial_segments = 10
	cm.rings = 1
	_add(d, cm, Transform3D(Basis(Vector3(1, 0, 0), PI * 0.5), Vector3(0, 0.1, -3.1)), Color(0.14, 0.15, 0.12), Vector2.ZERO)
	var m := ArrayMesh.new()
	_commit(m, d)
	_misc["turret"] = m
	return m

# ---------------------------------------------------------------- helicopter
static func heli_body(police: bool) -> ArrayMesh:
	var key := "heli_p" if police else "heli"
	if _misc.has(key):
		return _misc[key]
	var bd := _arr()
	var white := Color(1, 1, 1)
	var glass := Color(0.08, 0.12, 0.16)
	var sph := SphereMesh.new()
	sph.radius = 1.0
	sph.height = 2.0
	sph.radial_segments = 14
	sph.rings = 8
	_add(bd, sph, Transform3D(Basis.from_scale(Vector3(1.15, 1.1, 2.3)), Vector3(0, 1.5, 0)), white, Vector2.ZERO)
	_add(bd, sph, Transform3D(Basis.from_scale(Vector3(1.0, 0.85, 1.25)), Vector3(0, 1.62, -1.3)), glass, Vector2.ZERO)
	_box(bd, Vector3(0, 1.7, 3.5), Vector3(0.3, 0.38, 4.2), white)
	_box(bd, Vector3(0, 2.3, 5.4), Vector3(0.12, 1.1, 0.7), white)
	_box(bd, Vector3(0, 2.05, 0.6), Vector3(0.6, 0.35, 0.9), white)
	var m := ArrayMesh.new()
	_commit(m, bd)
	var td := _arr()
	var dk := Color(0.1, 0.1, 0.12)
	for sx in [-1.0, 1.0]:
		_box(td, Vector3(sx * 1.05, 0.35, 0), Vector3(0.1, 0.1, 3.4), dk)
		_box(td, Vector3(sx * 0.95, 0.75, -0.9), Vector3(0.08, 0.8, 0.08), dk)
		_box(td, Vector3(sx * 0.95, 0.75, 0.9), Vector3(0.08, 0.8, 0.08), dk)
	_box(td, Vector3(0, 2.3, 0.6), Vector3(0.2, 0.3, 0.2), dk)
	if police:
		_box(td, Vector3(0, 0.85, -1.9), Vector3(0.5, 0.3, 0.5), Color(0.8, 0.8, 0.85))
	_commit(m, td)
	_misc[key] = m
	return m

static func rotor_mesh() -> ArrayMesh:
	if _misc.has("rotor"):
		return _misc["rotor"]
	var d := _arr()
	var c := Color(0.05, 0.05, 0.06)
	for k in range(2):
		_box(d, Vector3.ZERO, Vector3(10.5, 0.05, 0.28), c, Vector2.ZERO, Basis(Vector3.UP, k * PI * 0.5))
	var m := ArrayMesh.new()
	_commit(m, d)
	_misc["rotor"] = m
	return m

static func tail_rotor_mesh() -> ArrayMesh:
	if _misc.has("trotor"):
		return _misc["trotor"]
	var d := _arr()
	_box(d, Vector3.ZERO, Vector3(0.05, 1.7, 0.14), Color(0.05, 0.05, 0.06))
	_box(d, Vector3.ZERO, Vector3(0.05, 0.14, 1.7), Color(0.05, 0.05, 0.06))
	var m := ArrayMesh.new()
	_commit(m, d)
	_misc["trotor"] = m
	return m

# ---------------------------------------------------------------- audio
static func _wav(data: PackedByteArray, rate: int, loop: bool) -> AudioStreamWAV:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = int(data.size() / 2)
	return w

static func sound(name: String) -> AudioStreamWAV:
	if _snd.has(name):
		return _snd[name]
	var rate := 22050
	var out: AudioStreamWAV
	if name == "engine":
		var n := 245 * 9
		var data := PackedByteArray()
		data.resize(n * 2)
		for i in range(n):
			var ph := TAU * float(i) / 245.0
			var v := (sin(ph) + 0.6 * sin(2.0 * ph) + 0.45 * sin(3.0 * ph) + 0.25 * sin(5.0 * ph) + 0.15 * sin(7.0 * ph)) * 0.42
			data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 8000.0))
		out = _wav(data, rate, true)
	elif name == "heli":
		var n := 2205
		var data := PackedByteArray()
		data.resize(n * 2)
		var lp := 0.0
		for i in range(n):
			var t := float(i) / float(rate)
			var nz := randf() * 2.0 - 1.0
			lp = lp + (nz - lp) * 0.25
			var chop := 0.55 + 0.45 * sin(TAU * 20.0 * t)
			var v := (lp * 1.4 + sin(TAU * 110.0 * t) * 0.3) * chop
			data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 9000.0))
		out = _wav(data, rate, true)
	elif name == "siren":
		var n := rate
		var data := PackedByteArray()
		data.resize(n * 2)
		for i in range(n):
			var t := float(i) / float(rate)
			var ph := TAU * 800.0 * t + 300.0 * (1.0 - cos(TAU * t))
			var v := sin(ph) * 0.6 + sin(ph * 2.0) * 0.2
			data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 6000.0))
		out = _wav(data, rate, true)
	else:
		var dur := 0.3
		var low := 0.0
		if name == "shot":
			dur = 0.22
		elif name == "smg":
			dur = 0.12
		elif name == "shotgun":
			dur = 0.35
			low = 0.5
		elif name == "enemy":
			dur = 0.2
			low = 0.3
		elif name == "crash":
			dur = 0.45
			low = 1.0
		elif name == "boom":
			dur = 1.2
			low = 1.0
		elif name == "buy":
			dur = 0.25
			low = 2.0
		var n := int(rate * dur)
		var data := PackedByteArray()
		data.resize(n * 2)
		var lp := 0.0
		for i in range(n):
			var t := float(i) / float(rate)
			var nz := randf() * 2.0 - 1.0
			var v := 0.0
			if low > 1.5:
				v = (sin(TAU * 880.0 * t) + sin(TAU * 1320.0 * t) * 0.6) * exp(-t * 14.0) * 0.5
			elif low > 0.5:
				lp = lp + (nz - lp) * 0.12
				v = lp * 2.2 * exp(-t * 5.0)
			else:
				v = nz * exp(-t * 14.0) + sin(TAU * 70.0 * t) * exp(-t * 30.0) * 0.8
			data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 14000.0))
		out = _wav(data, rate, false)
	_snd[name] = out
	return out
