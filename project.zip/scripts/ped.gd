extends CharacterBody3D
# Pedestrians (civilians walking sidewalks) and armed enemies.
const Cfg = preload("res://scripts/cfg.gd")
const Models = preload("res://scripts/models.gd")
const Sh = preload("res://scripts/shaders.gd")

var main
var kind := "civ"
var health := 40.0
var dead := false
var armed := false
var walk_speed := 1.4
var path_s := 0.0
var dirn := 1.0
var bi := 0
var bj := 0
var inset := 0.0
var panic := 0.0
var mat: ShaderMaterial
var shoot_cd := 1.0
var dead_t := 0.0
var cash := 0
var last_walk := -1.0
var mission_ped := false

func setup(m, k: String, pos: Vector3) -> void:
	main = m
	kind = k
	armed = k != "civ"
	collision_layer = 4
	collision_mask = 1
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
	var mi := MeshInstance3D.new()
	mi.mesh = Models.ped_mesh(armed)
	mat = ShaderMaterial.new()
	mat.shader = Sh.get_shader("ped")
	var skins := [Color(0.85, 0.66, 0.52), Color(0.62, 0.44, 0.32), Color(0.45, 0.3, 0.22), Color(0.93, 0.78, 0.66), Color(0.7, 0.52, 0.4)]
	mat.set_shader_parameter("skin", skins[randi() % skins.size()])
	if kind == "civ":
		mat.set_shader_parameter("shirt", Color.from_hsv(randf(), randf_range(0.2, 0.7), randf_range(0.3, 0.9)))
		mat.set_shader_parameter("pants", Color.from_hsv(randf_range(0.55, 0.7), randf_range(0.1, 0.5), randf_range(0.12, 0.4)))
		health = 40.0
		walk_speed = randf_range(1.1, 1.7)
		mat.set_shader_parameter("speed", walk_speed * 4.6)
	elif kind == "boss":
		mat.set_shader_parameter("shirt", Color(0.85, 0.85, 0.82))
		mat.set_shader_parameter("pants", Color(0.08, 0.08, 0.1))
		health = 420.0
		cash = 2000
	else:
		mat.set_shader_parameter("shirt", Color(0.08, 0.08, 0.1))
		mat.set_shader_parameter("pants", Color(0.14, 0.15, 0.17))
		health = 70.0
		cash = randi_range(80, 220)
	mat.set_shader_parameter("phase", randf() * 6.0)
	mi.material_override = mat
	mi.visibility_range_end = 140.0
	add_child(mi)
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.32
	cap.height = 1.75
	cs.shape = cap
	cs.position.y = 0.88
	add_child(cs)
	global_position = pos
	if kind == "civ":
		bi = randi_range(-Cfg.GRID, Cfg.GRID - 1)
		bj = randi_range(-Cfg.GRID, Cfg.GRID - 1)
		inset = randf_range(-1.1, 1.1)
		path_s = randf() * 240.0
		dirn = 1.0 if randf() < 0.5 else -1.0
		global_position = path_pos(path_s)

func path_pos(sv: float) -> Vector3:
	var x0 := bi * Cfg.P + 9.5 + inset
	var x1 := (bi + 1) * Cfg.P - 9.5 - inset
	var z0 := bj * Cfg.P + 9.5 + inset
	var z1 := (bj + 1) * Cfg.P - 9.5 - inset
	var w := x1 - x0
	var h := z1 - z0
	var t := fposmod(sv, 2.0 * (w + h))
	if t < w:
		return Vector3(x0 + t, 0, z0)
	t -= w
	if t < h:
		return Vector3(x1, 0, z0 + t)
	t -= h
	if t < w:
		return Vector3(x1 - t, 0, z1)
	t -= w
	return Vector3(x0, 0, z1 - t)

func set_walk(v: float) -> void:
	if absf(v - last_walk) > 0.05:
		last_walk = v
		mat.set_shader_parameter("walk", v)

func _physics_process(delta: float) -> void:
	if main == null:
		return
	if dead:
		dead_t += delta
		if dead_t > 12.0 and not mission_ped:
			queue_free()
		return
	var pl: Vector3 = main.player_pos()
	var dist := global_position.distance_to(pl)
	if kind == "civ":
		if dist > 200.0:
			return
		var spd := walk_speed * (3.2 if panic > 0.0 else 1.0)
		panic = maxf(0.0, panic - delta)
		path_s += dirn * spd * delta
		var np := path_pos(path_s)
		var d := np - global_position
		global_position = np
		if d.length() > 0.0005:
			rotation.y = lerp_angle(rotation.y, atan2(-d.x, -d.z), minf(1.0, 9.0 * delta))
		set_walk(1.0 if panic <= 0.0 else 1.6)
		mat.set_shader_parameter("speed", 7.0 if panic <= 0.0 else 14.0)
	else:
		gun_step(delta, dist, pl)

func gun_step(delta: float, dist: float, pl: Vector3) -> void:
	if dist > 60.0 or not main.player_alive():
		set_walk(0.0)
		return
	var to := pl - global_position
	to.y = 0.0
	rotation.y = lerp_angle(rotation.y, atan2(-to.x, -to.z), minf(1.0, 8.0 * delta))
	var mv := Vector3.ZERO
	if dist > 13.0:
		mv = to.normalized() * 3.8
	elif dist < 6.0:
		mv = -to.normalized() * 2.2
	velocity = mv
	move_and_slide()
	global_position.y = 0.0
	set_walk(1.0 if mv.length() > 0.1 else 0.0)
	shoot_cd -= delta
	if shoot_cd <= 0.0 and dist < 34.0:
		shoot_cd = randf_range(0.8, 1.5) if kind == "gun" else randf_range(0.35, 0.7)
		main.enemy_shoot(self, dist)

func hit(dmg: float, by_player: bool) -> void:
	if dead:
		return
	health -= dmg
	panic = 8.0
	if by_player and kind == "civ":
		main.crime(5.0)
	if kind != "civ":
		# aggro boost: shooting an enemy makes it return fire quickly
		shoot_cd = minf(shoot_cd, 0.3)
	if health <= 0.0:
		die(by_player)

func die(by_player: bool) -> void:
	if dead:
		return
	dead = true
	set_walk(0.0)
	rotation = Vector3(-PI * 0.5, rotation.y, 0.0)
	global_position.y = 0.18
	collision_layer = 0
	main.ped_died(self, by_player)
