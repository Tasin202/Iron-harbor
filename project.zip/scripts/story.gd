extends RefCounted
# Story missions for Iron Harbor.
const Cfg = preload("res://scripts/cfg.gd")

static func _n(i: int, j: int) -> Vector3:
	return Cfg.nd(i, j)

static func missions() -> Array:
	return [
		{
			"title": "BACK ON THE BLOCK", "start": Cfg.ic(0, 0), "reward": 400,
			"steps": [
				{"t": "talk", "lines": [
					["MO", "Kane! Four years inside and you still walk like you own the street."],
					["KANE", "Feels louder out here, Mo. Where's my ride?"],
					["MO", "Blue sedan, down the block. Bring it to the garage. We need to talk."]]},
				{"t": "getcar", "p": Vector3(-6.5, 0, 36), "yaw": 0.0, "kind": 0, "color": Color(0.1, 0.22, 0.55), "text": "Get in the blue sedan", "heat": 0},
				{"t": "goto", "p": _n(2, 1), "car": true, "text": "Drive to Mo's garage"},
				{"t": "talk", "lines": [
					["MO", "Salazar knows you're out. He says you owe him for the fall you took."],
					["KANE", "I took the fall. He owes ME."],
					["MO", "Tell him that. He'll call. Just... be careful, kid."]]},
			]},
		{
			"title": "THE DEBT", "start": _n(2, 1), "reward": 1500,
			"steps": [
				{"t": "talk", "lines": [
					["SALAZAR", "Kane. Welcome home. A red Veloce is parked outside the Grand Casino."],
					["SALAZAR", "A client forgot to pay me. Bring the car to the docks."],
					["KANE", "And then we're square?"],
					["SALAZAR", "Then we talk about square."]]},
				{"t": "getcar", "p": Vector3(-153.5, 0, 116), "yaw": 0.0, "kind": 1, "color": Color(0.75, 0.05, 0.06), "text": "Steal the red Veloce", "heat": 30},
				{"t": "goto", "p": _n(3, 4), "car": true, "text": "Deliver the Veloce to the docks"},
				{"t": "talk", "lines": [
					["SALAZAR", "Clean work. Now, a pawn shop owner thinks he's untouchable."],
					["SALAZAR", "Go and remind him who runs Iron Harbor."]]},
			]},
		{
			"title": "COLLECTIONS", "start": _n(3, 4), "reward": 2000, "weapon": 1,
			"steps": [
				{"t": "goto", "p": _n(-1, -2), "car": false, "text": "Go to the pawn shop"},
				{"t": "talk", "lines": [
					["VIC", "Salazar's dog! Tell him the Harbor belongs to the Reyes brothers now."],
					["KANE", "You set me up."]]},
				{"t": "kill", "p": _n(-1, -2), "n": 3, "boss": false, "text": "Survive the ambush"},
				{"t": "talk", "lines": [
					["KANE", "Rival crews, hired guns... this is bigger than a pawn shop."],
					["KANE", "(You found a submachine gun. Tap the swap button.)"]]},
			]},
		{
			"title": "HEAT", "start": _n(-1, -2), "reward": 3000,
			"steps": [
				{"t": "talk", "lines": [
					["LENA", "Mr. Rowe? Lena Park, Harbor Ledger. Salazar's money runs through Captain Dalton."],
					["LENA", "The proof is in the evidence room at Harbor Precinct."],
					["KANE", "You want me to rob a police station?"],
					["LENA", "I want you to save this city."]]},
				{"t": "goto", "p": _n(1, 3), "car": false, "text": "Go to Harbor Precinct"},
				{"t": "wanted", "lv": 3, "text": "Lose the cops!"},
				{"t": "goto", "p": _n(-3, -3), "car": false, "text": "Deliver the ledger to the safehouse"},
				{"t": "talk", "lines": [
					["LENA", "This is it. Names, dates, accounts. Dalton's finished."],
					["LENA", "But Salazar will know by morning."]]},
			]},
		{
			"title": "BETRAYAL", "start": _n(-3, -3), "reward": 4000,
			"steps": [
				{"t": "talk", "lines": [
					["MO", "Kane, it's Mo. Salazar moves a shipment tonight at the warehouses."],
					["MO", "Dalton's men will be there. They know about the ledger."],
					["KANE", "Then I'll meet them there."]]},
				{"t": "goto", "p": _n(3, 3), "car": false, "text": "Drive to the warehouse district"},
				{"t": "kill", "p": _n(3, 3), "n": 5, "boss": false, "text": "Clear the warehouse"},
				{"t": "talk", "lines": [
					["KANE", "Salazar's crew, Dalton's badge... same men."],
					["LENA", "He's holed up at the Iron Harbor pier. End it, Kane."]]},
			]},
		{
			"title": "IRON HARBOR", "start": _n(3, 3), "reward": 10000,
			"steps": [
				{"t": "goto", "p": _n(0, 4), "car": false, "text": "Head to the Iron Harbor pier"},
				{"t": "kill", "p": _n(0, 4), "n": 4, "boss": true, "text": "Take down Salazar"},
				{"t": "talk", "lines": [
					["SALAZAR", "You think the city changes when I fall?"],
					["KANE", "No. But it gets a chance."],
					["LENA", "The Ledger runs the story at dawn. Iron Harbor is yours to rebuild, Kane."],
					["KANE", "Let's keep the lights on."]]},
			]},
	]

static func courier() -> Dictionary:
	var a := Cfg.nd(randi_range(-3, 3), randi_range(-3, 3))
	var b := Cfg.nd(randi_range(-3, 3), randi_range(-3, 3))
	var tries := 0
	while a.distance_to(b) < 200.0 and tries < 20:
		b = Cfg.nd(randi_range(-3, 3), randi_range(-3, 3))
		tries += 1
	var pay := 300 + int(a.distance_to(b) * 2.0)
	return {
		"title": "COURIER RUN", "start": Cfg.nd(0, 0), "reward": pay,
		"steps": [
			{"t": "goto", "p": a, "car": false, "text": "Pick up the package"},
			{"t": "goto", "p": b, "car": false, "text": "Deliver the package"},
		]}
