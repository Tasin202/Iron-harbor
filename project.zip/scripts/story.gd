extends RefCounted
# Story missions for Iron Harbor. Dialogue is short subtitles that play while you act.
const Cfg = preload("res://scripts/cfg.gd")

static func _n(i: int, j: int) -> Vector3:
	return Cfg.nd(i, j)

static func missions() -> Array:
	return [
		{
			"title": "BACK ON THE BLOCK", "start": Cfg.ic(0, 0), "reward": 400,
			"steps": [
				{"t": "talk", "lines": [["MO", "Kane! Blue sedan down the street. Bring it to my garage."]]},
				{"t": "getcar", "p": Vector3(-6.5, 0, 36), "yaw": 0.0, "kind": 0, "color": Color(0.1, 0.22, 0.55), "text": "Get in the blue sedan", "heat": 0},
				{"t": "goto", "p": _n(2, 1), "car": true, "text": "Drive to Mo's garage (follow the arrow)"},
				{"t": "talk", "lines": [["MO", "Salazar knows you're out. He'll call."]]},
			]},
		{
			"title": "THE DEBT", "start": _n(2, 1), "reward": 1500,
			"steps": [
				{"t": "talk", "lines": [["SALAZAR", "Red Veloce outside the casino. Bring it to the docks."]]},
				{"t": "getcar", "p": Vector3(-153.5, 0, 116), "yaw": 0.0, "kind": 1, "color": Color(0.75, 0.05, 0.06), "text": "Steal the red Veloce", "heat": 30},
				{"t": "goto", "p": _n(3, 4), "car": true, "text": "Deliver the Veloce to the docks"},
				{"t": "talk", "lines": [["SALAZAR", "Clean. A pawn shop owes me. Go collect."]]},
			]},
		{
			"title": "COLLECTIONS", "start": _n(3, 4), "reward": 2000, "weapon": 1,
			"steps": [
				{"t": "goto", "p": _n(-1, -2), "car": false, "text": "Go to the pawn shop"},
				{"t": "talk", "lines": [["VIC", "The Reyes crew runs this harbor now!"]]},
				{"t": "kill", "p": _n(-1, -2), "n": 3, "boss": false, "text": "Survive the ambush"},
				{"t": "talk", "lines": [["KANE", "SMG acquired. Tap GUN to switch."]]},
			]},
		{
			"title": "FAST MONEY", "start": _n(-1, -2), "reward": 2500,
			"steps": [
				{"t": "talk", "lines": [["MO", "Street race! Hit every checkpoint before time runs out."]]},
				{"t": "race", "pts": [_n(0, -2), _n(1, -2), _n(1, 0), _n(-1, 0), _n(-2, 1), _n(0, 1)], "time": 110.0, "text": "RACE"},
				{"t": "talk", "lines": [["MO", "Not bad. Spend some of it - the Ammu-Nation sells real guns."]]},
			]},
		{
			"title": "HEAT", "start": _n(0, 1), "reward": 3000,
			"steps": [
				{"t": "talk", "lines": [["LENA", "Evidence room at Harbor Precinct. Get the ledger."]]},
				{"t": "goto", "p": _n(1, 3), "car": false, "text": "Go to Harbor Precinct"},
				{"t": "wanted", "lv": 3, "text": "Lose the cops! (hide, or use Pay and Spray)"},
				{"t": "goto", "p": _n(-3, -3), "car": false, "text": "Deliver the ledger to the safehouse"},
				{"t": "talk", "lines": [["LENA", "Names, dates, accounts. Dalton is finished."]]},
			]},
		{
			"title": "BETRAYAL", "start": _n(-3, -3), "reward": 4000,
			"steps": [
				{"t": "talk", "lines": [["MO", "Dalton's running in a black muscle car! Stop him!"]]},
				{"t": "chase", "p": _n(1, 3), "kind": 3, "color": Color(0.05, 0.05, 0.07), "text": "Wreck Dalton's car"},
				{"t": "talk", "lines": [["KANE", "One down. Salazar's men are at the warehouses."]]},
				{"t": "kill", "p": _n(3, 3), "n": 5, "boss": false, "text": "Clear the warehouse"},
			]},
		{
			"title": "IRON HARBOR", "start": _n(3, 3), "reward": 10000,
			"steps": [
				{"t": "talk", "lines": [["LENA", "Salazar is at the pier. Armed to the teeth."]]},
				{"t": "goto", "p": _n(0, 4), "car": false, "text": "Head to the Iron Harbor pier"},
				{"t": "kill", "p": _n(0, 4), "n": 4, "boss": true, "text": "Take down Salazar's guards"},
				{"t": "talk", "lines": [["SALAZAR", "You'll never touch me! My chopper's coming!"]]},
				{"t": "killheli", "p": _n(0, 3), "text": "Shoot down the helicopter with the RPG"},
				{"t": "talk", "lines": [["LENA", "It's over. The Ledger runs the story at dawn."], ["KANE", "Let's keep the lights on."]]},
			]},
	]

static func courier() -> Dictionary:
	var a := Cfg.nd(randi_range(-3, 3), randi_range(-3, 3))
	var b := Cfg.nd(randi_range(-3, 3), randi_range(-3, 3))
	var tries := 0
	while a.distance_to(b) < 200.0 and tries < 20:
		b = Cfg.nd(randi_range(-3, 3), randi_range(-3, 3))
		tries += 1
	var pay := 300 + int(a.distance_to(b) * 2.0)
	return {
		"title": "COURIER RUN", "start": Cfg.nd(0, 0), "reward": pay,
		"steps": [
			{"t": "goto", "p": a, "car": false, "text": "Pick up the package"},
			{"t": "goto", "p": b, "car": false, "text": "Deliver the package"},
		]}
