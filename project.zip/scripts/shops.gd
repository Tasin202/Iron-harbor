extends RefCounted
# Shop interiors, phone and shop menus (rows + purchase logic).
const Cfg = preload("res://scripts/cfg.gd")
const Models = preload("res://scripts/models.gd")

const PAINTS := [
	["Matte Black", Color(0.05, 0.05, 0.06)], ["Racing Red", Color(0.75, 0.05, 0.06)], ["Pearl White", Color(0.92, 0.92, 0.95)],
	["Ocean Blue", Color(0.08, 0.25, 0.6)], ["Lime", Color(0.45, 0.8, 0.1)], ["Gold", Color(0.85, 0.65, 0.15)]]

# ---------------------------------------------------------------- interiors
static func _wallbox(root: Node3D, sb: StaticBody3D, pos: Vector3, size: Vector3, col: Color) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	var mt := StandardMaterial3D.new()
	mt.albedo_color = col
	mt.roughness = 0.8
	mi.material_override = mt
	root.add_child(mi)
	if sb != null:
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = size
		cs.shape = bs
		cs.position = pos
		sb.add_child(cs)

static func _disc(root: Node3D, pos: Vector3, col: Color) -> void:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.1
	cm.bottom_radius = 1.1
	cm.height = 0.05
	mi.mesh = cm
	mi.position = pos + Vector3(0, 0.05, 0)
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.albedo_color = col
	mi.material_override = mt
	root.add_child(mi)

static func build_interior(m, idx: int) -> Dictionary:
	var sd: Dictionary = Cfg.SHOPS[idx]
	var id: String = sd["id"]
	var o := Vector3(1200.0 + idx * 60.0, 0.0, 0.0)
	var root := Node3D.new()
	root.position = o
	m.add_child(root)
	var sb := StaticBody3D.new()
	sb.collision_layer = 1
	sb.collision_mask = 0
	root.add_child(sb)
	var W := 18.0
	var D := 14.0
	var H := 4.2
	var base: Color = sd["col"]
	var floor_c := Color(0.55, 0.55, 0.55)
	if id == "burger":
		floor_c = Color(0.75, 0.7, 0.55)
	elif id == "apt" or id == "apt2":
		floor_c = Color(0.45, 0.32, 0.22)
	_wallbox(root, sb, Vector3(0, -0.1, 0), Vector3(W, 0.2, D), floor_c)
	_wallbox(root, null, Vector3(0, H + 0.1, 0), Vector3(W, 0.2, D), Color(0.85, 0.85, 0.85))
	_wallbox(root, sb, Vector3(0, H * 0.5, -D * 0.5), Vector3(W, H, 0.3), base.lightened(0.55))
	_wallbox(root, sb, Vector3(0, H * 0.5, D * 0.5), Vector3(W, H, 0.3), base.lightened(0.55))
	_wallbox(root, sb, Vector3(-W * 0.5, H * 0.5, 0), Vector3(0.3, H, D), base.lightened(0.5))
	_wallbox(root, sb, Vector3(W * 0.5, H * 0.5, 0), Vector3(0.3, H, D), base.lightened(0.5))
	# counter + clerk
	_wallbox(root, sb, Vector3(0, 0.55, -3.4), Vector3(7.0, 1.1, 1.2), Color(0.25, 0.17, 0.1))
	_wallbox(root, null, Vector3(0, 1.12, -3.4), Vector3(7.2, 0.06, 1.3), Color(0.8, 0.8, 0.82))
	# lights
	var li := OmniLight3D.new()
	li.position = Vector3(0, 3.6, 0)
	li.omni_range = 24.0
	li.light_energy = 1.5
	root.add_child(li)
	# decor per type
	var rng := RandomNumberGenerator.new()
	rng.seed = idx * 77 + 5
	if id == "ammu":
		for i in range(8):
			_wallbox(root, null, Vector3(-W * 0.5 + 0.4, 2.0 - (i % 2) * 0.8, -4.5 + (i / 2) * 2.4), Vector3(0.2, 0.12, 1.4), Color(0.08, 0.08, 0.09))
			_wallbox(root, null, Vector3(W * 0.5 - 0.4, 2.0 - (i % 2) * 0.8, -4.5 + (i / 2) * 2.4), Vector3(0.2, 0.12, 1.4), Color(0.2, 0.15, 0.1))
	elif id == "burger":
		for i in range(4):
			_wallbox(root, null, Vector3(-6.0 + i * 4.0, 0.5, 3.0), Vector3(1.8, 0.1, 1.2), Color(0.9, 0.9, 0.9))
			_wallbox(root, null, Vector3(-6.0 + i * 4.0, 0.25, 3.0), Vector3(0.3, 0.5, 0.3), Color(0.5, 0.5, 0.5))
			_wallbox(root, null, Vector3(-6.0 + i * 4.0, 0.3, 4.2), Vector3(1.8, 0.6, 0.5), Color(0.8, 0.15, 0.1))
	elif id == "clothes":
		for i in range(6):
			var o2: Dictionary = Cfg.OUTFITS[i]
			_wallbox(root, null, Vector3(-W * 0.5 + 1.0, 1.4, -4.5 + i * 1.6), Vector3(0.5, 0.9, 0.9), o2["shirt"])
			_wallbox(root, null, Vector3(W * 0.5 - 1.0, 1.4, -4.5 + i * 1.6), Vector3(0.5, 0.9, 0.9), o2["pants"])
	elif id == "dealer":
		var kinds := [0, 1, 4]
		for i in range(3):
			var mi := MeshInstance3D.new()
			mi.mesh = Models.car_mesh(kinds[i])
			var mt := StandardMaterial3D.new()
			mt.albedo_color = PAINTS[(i * 2 + 1) % PAINTS.size()][1]
			mt.vertex_color_use_as_albedo = true
			mt.metallic = 0.6
			mt.roughness = 0.25
			mi.set_surface_override_material(0, mt)
			mi.set_surface_override_material(1, Models.trim_mat())
			mi.set_surface_override_material(2, Models.light_mat())
			mi.position = Vector3(-5.0 + i * 5.0, 0.0, 2.5)
			mi.rotation.y = 0.5 - i * 0.5
			root.add_child(mi)
	elif id == "apt" or id == "apt2":
		_wallbox(root, null, Vector3(-6.0, 0.35, 4.0), Vector3(2.2, 0.7, 3.2), Color(0.9, 0.9, 0.92))
		_wallbox(root, null, Vector3(-6.0, 0.9, 5.4), Vector3(2.2, 0.8, 0.3), Color(0.9, 0.9, 0.92))
		_wallbox(root, null, Vector3(5.5, 0.4, 4.5), Vector3(4.0, 0.8, 1.4), Color(0.2, 0.25, 0.4))
		_wallbox(root, null, Vector3(7.0, 1.4, -6.0), Vector3(0.1, 1.1, 2.2), Color(0.02, 0.02, 0.03))
		if id == "apt2":
			_wallbox(root, null, Vector3(0, 2.0, -6.85), Vector3(12.0, 2.2, 0.1), Color(0.35, 0.6, 0.9))
	var label := Label3D.new()
	label.text = sd["name"]
	label.pixel_size = 0.03
	label.font_size = 64
	label.position = Vector3(0, 3.3, -D * 0.5 + 0.25)
	label.modulate = Color(1, 1, 1)
	label.outline_size = 8
	root.add_child(label)
	var spawn := o + Vector3(0, 0, D * 0.5 - 3.0)
	var exit_p := o + Vector3(0, 0, D * 0.5 - 1.2)
	var service := o + Vector3(0, 0, -1.4)
	_disc(root, exit_p - o, Color(0.2, 1.0, 0.4))
	_disc(root, service - o, Color(1.0, 0.85, 0.1))
	if id != "apt" and id != "apt2":
		var clerk = m.spawn_ped(o + Vector3(0, 0, -4.4), "clerk")
		clerk.rotation.y = PI
	return {"origin": o, "spawn": spawn, "exit": exit_p, "service": service, "root": root}

# ---------------------------------------------------------------- menus
static func money_s(v: int) -> String:
	return "$" + str(v)

static func menu(m, ctx: String) -> Dictionary:
	var rows: Array = []
	var title := ""
	var sub = "Cash: $" + str(m.money)
	if ctx == "phone":
		title = "PHONE"
		rows.append({"t": "Contacts", "id": "contacts"})
		rows.append({"t": "Map and GPS waypoint", "id": "map"})
		rows.append({"t": "Stats", "id": "stats"})
		if m.waypoint_on:
			rows.append({"t": "Clear waypoint", "id": "clearwp"})
	elif ctx == "contacts":
		title = "CONTACTS"
		rows.append({"t": "Mechanic - deliver my car", "r": "$100", "id": "garage"})
		rows.append({"t": "Taxi - ride to waypoint", "r": "$60", "id": "taxi", "dis": not m.waypoint_on})
		rows.append({"t": "Pegasus - special vehicles", "id": "pegasus"})
		rows.append({"t": "Lester - erase wanted level", "r": "$4000", "id": "lester", "dis": m.wanted == 0})
		rows.append({"t": "Armored courier - body armor", "r": "$250", "id": "armor_call"})
	elif ctx == "garage":
		title = "GARAGE"
		if m.owned.is_empty():
			rows.append({"t": "You own no vehicles yet - visit Premier Auto", "id": "none", "hdr": true})
		for i in range(m.owned.size()):
			var o: Dictionary = m.owned[i]
			rows.append({"t": Cfg.ki(int(o["kind"]))["n"], "r": "$100", "id": "gv" + str(i)})
	elif ctx == "pegasus":
		title = "PEGASUS"
		rows.append({"t": "Skylark Helicopter", "r": money_s(20000), "id": "pv20"})
		rows.append({"t": "Rhino Tank", "r": money_s(40000), "id": "pv10"})
		rows.append({"t": "Zenith Supercar", "r": money_s(75000), "id": "pv4"})
	elif ctx == "stats":
		title = "STATS"
		sub = "Chapter " + str(m.chapter + 1) + " | Cash $" + str(m.money) + " | Cars owned " + str(m.owned.size())
		rows.append({"t": "Story progress", "r": str(mini(m.chapter, 6)) + " / 6", "id": "x", "hdr": true})
		rows.append({"t": "Home", "r": ("none" if m.home_idx < 0 else Cfg.SHOPS[m.home_idx]["name"]), "id": "x", "hdr": true})
		rows.append({"t": "Weapons owned", "r": str(m.weapons_count()), "id": "x", "hdr": true})
	elif ctx == "mod":
		title = "AUTO MODS"
		var car = m.cur_car
		var nm = "" if car == null else str(car.info["n"])
		sub = nm + " | Cash $" + str(m.money)
		rows.append({"t": "Repair", "r": "$150", "id": "repair"})
		for i in range(PAINTS.size()):
			rows.append({"t": "Respray: " + PAINTS[i][0], "r": "$250", "id": "paint" + str(i)})
		var cl: int = car.eng_lvl if car != null else 0
		rows.append({"t": "Engine tuning (lvl " + str(cl) + "/3)", "r": ("MAX" if cl >= 3 else money_s(2000 * (cl + 1))), "id": "eng", "dis": cl >= 3})
		var bl: int = car.brk_lvl if car != null else 0
		rows.append({"t": "Race brakes (lvl " + str(bl) + "/3)", "r": ("MAX" if bl >= 3 else money_s(700 * (bl + 1))), "id": "brk", "dis": bl >= 3})
		var al: int = car.arm_lvl if car != null else 0
		rows.append({"t": "Armor plating (lvl " + str(al) + "/3)", "r": ("MAX" if al >= 3 else money_s(1800 * (al + 1))), "id": "arm", "dis": al >= 3})
	elif ctx.begins_with("shop:"):
		var id := ctx.substr(5)
		match id:
			"ammu":
				title = "AMMU-NATION"
				for w in range(2, 5):
					var wd: Dictionary = Cfg.WEAPONS[w]
					var owned: bool = m.weapons_owned[w]
					rows.append({"t": wd["n"], "r": ("OWNED" if owned else money_s(int(wd["price"]))), "id": "w" + str(w), "dis": owned})
				rows.append({"t": "Body armor", "r": "$350", "id": "armor"})
			"burger":
				title = "BURGER SHOT"
				rows.append({"t": "Burger  (+25 health)", "r": "$12", "id": "b25"})
				rows.append({"t": "Fries meal  (+60 health)", "r": "$30", "id": "b60"})
				rows.append({"t": "Mega feast  (full health)", "r": "$60", "id": "b100"})
			"clothes":
				title = "URBAN CLOTHES"
				for i in range(Cfg.OUTFITS.size()):
					var has: bool = m.owned_outfits.has(i)
					var worn: bool = m.player.outfit == i
					rows.append({"t": Cfg.OUTFITS[i]["n"], "r": ("WORN" if worn else ("OWNED - wear" if has else "$80")), "id": "o" + str(i), "dis": worn})
			"dealer":
				title = "PREMIER AUTO"
				for k in [0, 6, 5, 2, 3, 1, 4]:
					rows.append({"t": Cfg.ki(k)["n"], "r": money_s(int(Cfg.ki(k)["price"])), "id": "c" + str(k)})
			"apt", "apt2":
				var idx := 4 if id == "apt" else 5
				title = Cfg.SHOPS[idx]["name"]
				var price := 12000 if id == "apt" else 60000
				if m.has_property(idx):
					sub = "You own this place"
					rows.append({"t": "Sleep until morning and save", "id": "sleep"})
					rows.append({"t": "Set as my respawn home", "id": "sethome", "dis": m.home_idx == idx})
					for i in range(m.owned_outfits.size()):
						var oi: int = m.owned_outfits[i]
						rows.append({"t": "Wear: " + str(Cfg.OUTFITS[oi]["n"]), "id": "o" + str(oi), "dis": m.player.outfit == oi})
				else:
					rows.append({"t": "Buy this property", "r": money_s(price), "id": "buyprop"})
					if id == "apt2":
						rows.append({"t": "Includes a free Skylark helicopter", "id": "x", "hdr": true})
	return {"title": title, "rows": rows, "sub": sub}

# returns true if the menu should be refreshed
static func pick(m, ctx: String, id: String) -> void:
	if ctx == "phone":
		match id:
			"contacts": m.menu_go("contacts")
			"map":
				m.menu_ctx = ""
				m.hud.open_map()
			"stats": m.menu_go("stats")
			"clearwp":
				m.waypoint_on = false
				m.menu_go("phone", false)
	elif ctx == "contacts":
		match id:
			"garage": m.menu_go("garage")
			"pegasus": m.menu_go("pegasus")
			"taxi":
				if m.waypoint_on and m.spend(60):
					m.hud.close_menu()
					m.menu_ctx = ""
					m.fast_travel(m.waypoint)
			"lester":
				if m.spend(4000):
					m.heat = 0.0
					m.hud.toast("Lester: your record is clean")
					m.menu_go("contacts", false)
			"armor_call":
				if m.spend(250):
					m.player.armor = 100.0
					m.hud.toast("Body armor delivered")
					m.menu_go("contacts", false)
	elif ctx == "garage":
		if id.begins_with("gv"):
			if m.spend(100):
				m.hud.close_menu()
				m.menu_ctx = ""
				m.spawn_owned(int(id.substr(2)))
	elif ctx == "pegasus":
		if id.begins_with("pv"):
			var k := int(id.substr(2))
			var price := int(Cfg.ki(k)["price"])
			if m.spend(price):
				m.add_owned(k, Color(0.12, 0.13, 0.16) if k != 4 else Color(0.9, 0.7, 0.1))
				m.hud.close_menu()
				m.menu_ctx = ""
				m.spawn_owned(m.owned.size() - 1)
	elif ctx == "mod":
		var car = m.cur_car
		if car == null:
			return
		if id == "repair":
			if m.spend(150):
				car.repair()
		elif id.begins_with("paint"):
			if m.spend(250):
				car.set_paint(PAINTS[int(id.substr(5))][1])
		elif id == "eng" and car.eng_lvl < 3:
			if m.spend(2000 * (car.eng_lvl + 1)):
				car.eng_lvl += 1
				car.apply_upgrades()
		elif id == "brk" and car.brk_lvl < 3:
			if m.spend(700 * (car.brk_lvl + 1)):
				car.brk_lvl += 1
		elif id == "arm" and car.arm_lvl < 3:
			if m.spend(1800 * (car.arm_lvl + 1)):
				car.arm_lvl += 1
		m.sync_owned(car)
		m.menu_go("mod", false)
	elif ctx.begins_with("shop:"):
		var sid := ctx.substr(5)
		match sid:
			"ammu":
				if id.begins_with("w"):
					var wi := int(id.substr(1))
					if not m.weapons_owned[wi] and m.spend(int(Cfg.WEAPONS[wi]["price"])):
						m.weapons_owned[wi] = true
						m.weapon = wi
				elif id == "armor":
					if m.spend(350):
						m.player.armor = 100.0
			"burger":
				var amt := int(id.substr(1))
				var cost := {"b25": 12, "b60": 30, "b100": 60}[id] as int
				if m.player.health >= 100.0:
					m.hud.toast("You are not hungry")
				elif m.spend(cost):
					m.player.health = minf(100.0, m.player.health + amt)
			"clothes":
				var oi2 := int(id.substr(1))
				if m.owned_outfits.has(oi2):
					m.player.set_outfit(oi2)
				elif m.spend(80):
					m.owned_outfits.append(oi2)
					m.player.set_outfit(oi2)
			"dealer":
				var k2 := int(id.substr(1))
				if m.spend(int(Cfg.ki(k2)["price"])):
					m.add_owned(k2, PAINTS[randi() % PAINTS.size()][1])
					m.hud.toast("Delivered outside - call the mechanic any time")
					m.spawn_owned_at_dealer(m.owned.size() - 1)
			"apt", "apt2":
				var pidx := 4 if sid == "apt" else 5
				if id == "buyprop":
					var price2 := 12000 if sid == "apt" else 60000
					if m.spend(price2):
						m.properties.append(pidx)
						m.home_idx = pidx
						if sid == "apt2":
							m.add_owned(20, Color(0.9, 0.9, 0.92))
							m.hud.toast("A Skylark helicopter is parked on your roof pad (garage)")
						m.save_game()
				elif id == "sleep":
					m.sleep_and_save()
				elif id == "sethome":
					m.home_idx = pidx
					m.hud.toast("Home set")
				elif id.begins_with("o"):
					m.player.set_outfit(int(id.substr(1)))
		m.menu_go(ctx, false)
